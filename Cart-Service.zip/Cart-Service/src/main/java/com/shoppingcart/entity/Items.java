package com.shoppingcart.entity;

import com.shoppingcart.dto.ProductDto;

public class Items {
	
	private ProductDto product;
	private int quantity;
	
	public Items() {
		super();
	}
	public Items(ProductDto product, int quantity) {
		super();
		this.product = product;
		this.quantity = quantity;
	}
	public ProductDto getProduct() {
		return product;
	}
	public void setProduct(ProductDto product) {
		this.product = product;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
}
