package com.shoppingcart.serviceproxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.shoppingcart.dto.RegistrationDto;

@FeignClient(url="http://localhost:9093/customer",name="registry-service")
public interface IServiceProxy_customer {
	
	@GetMapping("/getCustomerById/{customerId}")
	public ResponseEntity<RegistrationDto> getCustomerById(@PathVariable String customerId) ;

}
