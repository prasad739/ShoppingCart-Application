package com.shoppingcart.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.shoppingcart.dto.CartDto;
import com.shoppingcart.service.CartServiceImpl;

@RestController
@RequestMapping("/cart")
@CrossOrigin("*")
public class CartController {
	
	@Autowired
	CartServiceImpl cartImpl;
	
	private static final Logger logger=LogManager.getLogger();
	
	@PostMapping("/addToCart")
	public ResponseEntity<CartDto> addToCart(@RequestParam(name="cartId") String cartId,@RequestParam(name = "customerId") String customerId,@RequestParam(name = "productId") String productId,@RequestParam(name ="quantity") int quantity) {
		logger.info("Sending request to add a product to a cart");
		CartDto cart2=cartImpl.addToCart(cartId,customerId, productId, quantity);
		logger.info("Product added to cart successfully!");
		
		return new ResponseEntity<>(cart2,HttpStatus.CREATED);
	}
	
	@PutMapping("/updateCart/decreaseQuantity")
	public ResponseEntity<String> decreaseProductQuantity(@RequestParam(name="decreaseBy") int decreaseBy,@RequestParam(name = "customerId") String customerId,@RequestParam(name = "productId") String productId) {
		logger.info("Sending request to decrease product quantity in the cart");
		String isUpdated=cartImpl.decreaseProductQuantity(customerId, productId, decreaseBy);
		logger.info("quantity updated successfully!");
		
		return new ResponseEntity<>(isUpdated,HttpStatus.OK);
	}
	
	@PutMapping("/updateCart/deleteProduct")
	public ResponseEntity<String> deleteProductFromCart(@RequestParam(name = "customerId") String customerId,@RequestParam(name = "productId") String productId) {
		logger.info("Sending request to delete product from the cart");
		String deleted=cartImpl.deleteProductFromCart(customerId, productId);
		logger.info("Product deleted successfully!");
		
		return new ResponseEntity<>(deleted,HttpStatus.OK);
	}
	
	@DeleteMapping("/updateCart/deleteCart/{customerId}")
	public ResponseEntity<String> deleteCart(@PathVariable String customerId) {
		logger.info("Sending request to delete the entire cart");
		String deleted=cartImpl.deleteCart(customerId);
		logger.info("Cart deleted successfully!");
		
		return new ResponseEntity<>(deleted,HttpStatus.OK);
	}
	
	@GetMapping("/getTotalPrice/{customerId}")
	public ResponseEntity<Double> calculateTotalPrice(@PathVariable String customerId) {
		logger.info("Sending request to calculate the price of all the items in the cart");
		double totalPrice = cartImpl.calculateTotalPrice(customerId);
		logger.info("Price calculated successfully!");
		
		return new ResponseEntity<>(totalPrice,HttpStatus.OK);
	}
	
	@GetMapping("/getCartItems/{customerId}")
	public ResponseEntity<CartDto> getCartItemsByCustomerId(@PathVariable String customerId) {
		logger.info("Sending request to view cart items of the customer");
		 CartDto cart = cartImpl.getCartItemsByCustomerId(customerId);
		logger.info("Fetched cart items successfully!");
		
		return new ResponseEntity<>(cart,HttpStatus.OK);
	}

}
