package com.shoppingcart.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.shoppingcart.entity.Cart;

public interface ICartRepository extends MongoRepository<Cart,String>{
	
	Optional<Cart> findByCustomerId(String customerId);

	Optional<Cart> findByCartId(String cartId);
	
	void deleteByCustomerId(String cartId);

}
