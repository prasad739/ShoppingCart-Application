package com.shoppingcart.dto;

import java.util.List;

import com.shoppingcart.entity.Items;

public class CartDto {

	private String cartId;
	private String customerId;

	private List<Items> itemList;

	public CartDto() {
		super();
	}

	public CartDto(String cartId, String customerId, List<Items> itemList) {
		super();
		this.cartId = cartId;
		this.customerId = customerId;
		this.itemList = itemList;
	}

	public String getCartId() {
		return cartId;
	}

	public void setCartId(String cartId) {
		this.cartId = cartId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public List<Items> getItemList() {
		return itemList;
	}

	public void setItemList(List<Items> itemList) {
		this.itemList = itemList;
	}

}
