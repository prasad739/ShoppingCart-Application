package com.shoppingcart.exception;

public class ProductDoesNotExistException extends RuntimeException {
	
	public ProductDoesNotExistException(String msg) {
		super(msg);
	}

}
