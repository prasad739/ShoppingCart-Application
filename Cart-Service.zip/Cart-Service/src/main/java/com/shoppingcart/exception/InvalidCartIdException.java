package com.shoppingcart.exception;

public class InvalidCartIdException extends RuntimeException {
	
	public InvalidCartIdException(String msg) {
		super(msg);
	}

}
