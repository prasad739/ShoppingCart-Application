package com.shoppingcart.exception;

public class InvalidQuantityException extends RuntimeException {
	
	public InvalidQuantityException(String msg) {
		super(msg);
	}

}
