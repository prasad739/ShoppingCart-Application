package com.shoppingcart.exception;

public class IdMissmatchException extends RuntimeException {
	
	public IdMissmatchException(String msg) {
		super(msg);
	}
}
