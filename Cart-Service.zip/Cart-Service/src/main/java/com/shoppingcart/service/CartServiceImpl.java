package com.shoppingcart.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.shoppingcart.dto.CartDto;
import com.shoppingcart.dto.ProductDto;
import com.shoppingcart.entity.Cart;
import com.shoppingcart.entity.Items;
import com.shoppingcart.exception.CustomerNotFoundException;
import com.shoppingcart.exception.EmptyCartException;
import com.shoppingcart.exception.IdMissmatchException;
import com.shoppingcart.exception.InvalidQuantityException;
import com.shoppingcart.exception.ProductDoesNotExistException;
import com.shoppingcart.repository.ICartRepository;
import com.shoppingcart.serviceproxy.IServiceProxy_customer;
import com.shoppingcart.serviceproxy.IServiceProxy_product;

@Service
public class CartServiceImpl implements ICartService {

	@Autowired
	ICartRepository cartRepo;

	@Autowired
	IServiceProxy_product sp;

	@Autowired
	IServiceProxy_customer sc;

	@Autowired
	ModelMapper modelMapper;

	public CartDto addToCart(String cartId, String customerId, String productId, int quantity) {

		// customer validation.
		try {
			sc.getCustomerById(customerId);
		} catch (Exception ex) {
			throw new CustomerNotFoundException("Customer not found with the given id: " + customerId);
		}

		if (cartRepo.findByCartId(cartId).isPresent()) {
			if (!cartRepo.findByCartId(cartId).get().getCustomerId().equals(customerId)) {
				throw new IdMissmatchException("CardId does not match for the given customer id");

			}

		} else {
			if (cartRepo.findByCustomerId(customerId).isPresent()) {
				throw new IdMissmatchException("CardId does not match for the given customer id");
			}
		}

		ResponseEntity<ProductDto> productById;

		// product validation.
		try {
			productById = sp.getProductById(productId);
		} catch (Exception ex) {
			throw new ProductDoesNotExistException("Product not found with the given id: " + productId);
		}

		// quantity validation.
		if (quantity <= 0) {
			throw new InvalidQuantityException("Quantity should be a positive value");
		}

		Cart newCart = null;

		// finding the customer cart
		Optional<Cart> cart = cartRepo.findByCustomerId(customerId);

		// if cart is empty
		if (!cart.isPresent()) {
			newCart = new Cart();
			newCart.setCartId(cartId);
			newCart.setCustomerId(customerId);

			List<Items> list = new ArrayList<>();

			Items items = new Items();
			items.setProduct(productById.getBody());
			items.setQuantity(quantity);
			list.add(items);

			newCart.setItemList(list);

			// return cartRepo.save(newCart);
		} else {
			newCart = cart.get();

			List<Items> itemList = cart.get().getItemList();
			boolean flag = false;
			for (Items item : itemList) {
				if (item.getProduct().getProductId().equals(productId)) {
					int quant = item.getQuantity();
					item.setQuantity(quantity + quant);
					flag = true;
					break;
				}
			}
			if (!flag) {
				Items items = new Items();
				items.setProduct(productById.getBody());
				items.setQuantity(quantity);
				itemList.add(items);
			}
			newCart.setItemList(itemList);

		}

		cartRepo.save(newCart);
		
		return modelMapper.map(newCart, CartDto.class);

	}

	public String decreaseProductQuantity(String customerId, String productId, int decreaseBy) {

		try {
			sc.getCustomerById(customerId);
		} catch (Exception ex) {
			throw new CustomerNotFoundException("Customer not found with the given id: " + customerId);
		}

		ResponseEntity<ProductDto> productById;
		// product validation.
		try {
			productById = sp.getProductById(productId);
		} catch (Exception ex) {
			throw new ProductDoesNotExistException("Product not found with the given id: " + productId);
		}

		if (decreaseBy < 0) {
			throw new InvalidQuantityException("Quantity cannot be negative");
		}

		Optional<Cart> customerCart = cartRepo.findByCustomerId(customerId);
		Cart cart = null;
		if (!customerCart.isPresent()) {
			throw new EmptyCartException("Customer do not have items in the cart");
		} else {
			cart = customerCart.get();
			List<Items> itemList = cart.getItemList();
			Items item = null;
			boolean productFound = false;
			for (Items i : itemList) {
				if (i.getProduct().getProductId().equals(productId)) {
					// in cart
					int itemQuantity = i.getQuantity();
					if (itemQuantity >= decreaseBy) {
						i.setQuantity(itemQuantity - decreaseBy);
						item = i;
						productFound = true;
						break;
					} else {
						throw new InvalidQuantityException("Quantity of the product is only " + itemQuantity);
					}

				}
			}
			if (!productFound) {
				throw new ProductDoesNotExistException("You dont have the product in the cart!");
			}
			if (item.getQuantity() == 0) {
				itemList.remove(item);
			}

			if (itemList.isEmpty()) {
				cartRepo.delete(customerCart.get());
				cart = null;
			} else {
				cartRepo.save(cart);
			}
		}

		if (cart == null) {
			return "Quantity decreased successfully and Cart is empty now";
		} else {
			return "Quantity decreased successfully!";
		}

	}

	public String deleteProductFromCart(String customerId, String productId) {
		
		try {
			sc.getCustomerById(customerId);
		} catch (Exception ex) {
			throw new CustomerNotFoundException("Customer not found with the given id: " + customerId);
		}

		ResponseEntity<ProductDto> productById;
		// product validation.
		try {
			productById = sp.getProductById(productId);
		} catch (Exception ex) {
			throw new ProductDoesNotExistException("Product not found with the given id: " + productId);
		}
		
		Optional<Cart> customerCart = cartRepo.findByCustomerId(customerId);
		
		if(!customerCart.isPresent()) {
			throw new EmptyCartException("Customer do not have items in the cart");
		}else {
			Cart cart=customerCart.get();
			List<Items> itemList = cart.getItemList();
			Items item=null;
			boolean flag=false;
			for(Items i:itemList) {
				if(i.getProduct().getProductId().equals(productId)) {
					item=i;
					flag=true;
					break;
				}
			}
			if(!flag) {
				throw new ProductDoesNotExistException("There is no such product in the cart");
			}else {
				itemList.remove(item);
				if(itemList.isEmpty()) {
					cartRepo.delete(cart);
					return "Product deleted from cart and cart is now empty!";   
				}else {
					cartRepo.save(cart);
				}
				
			}
		}

		return "Product Deleted successfully!";
	}

	public String deleteCart(String customerId) {
		try {
			sc.getCustomerById(customerId);
		} catch (Exception ex) {
			throw new CustomerNotFoundException("Customer not found with the given id: " + customerId);
		}
		Optional<Cart> customerCart = cartRepo.findByCustomerId(customerId);
		if(!customerCart.isPresent()) {
			throw new EmptyCartException("Customer do not have items in the cart");
		}
		cartRepo.deleteByCustomerId(customerId);
		return "Removed all items from the cart!";
	}

	
	public double calculateTotalPrice(String customerId) {
		
		try {
			sc.getCustomerById(customerId);
		} catch (Exception ex) {
			throw new CustomerNotFoundException("Customer not found with the given id: " + customerId);
		}
		double totalPrice=0;
		Optional<Cart> customerCart = cartRepo.findByCustomerId(customerId);
		if(customerCart.isPresent()) {
			Cart cart = customerCart.get();
			for(Items item:cart.getItemList()) {
				totalPrice+=item.getProduct().getPrice()*item.getQuantity();
			}
		}
		return totalPrice;
	}

	public CartDto getCartItemsByCustomerId(String customerId) {
		try {
			sc.getCustomerById(customerId);
		} catch (Exception ex) {
			throw new CustomerNotFoundException("Customer not found with the given id: " + customerId);
		}
		
		Optional<Cart> customerCart = cartRepo.findByCustomerId(customerId);
		if(customerCart.isPresent()) {
			return modelMapper.map(customerCart.get(), CartDto.class);
		}
		throw new EmptyCartException("Customer doesn't have any items in the cart");
		
	}

}
