package com.shoppingcart.service;

import com.shoppingcart.dto.CartDto;

public interface ICartService {

	CartDto addToCart(String cartId, String customerId, String productId, int quantity);
	
	String decreaseProductQuantity(String customerId, String productId,int decreaseBy);
	
	String deleteProductFromCart(String customerId, String productId);
	
	String deleteCart(String customerId);
	
	double calculateTotalPrice(String customerId);
	
	CartDto getCartItemsByCustomerId(String customerId);
	


}
