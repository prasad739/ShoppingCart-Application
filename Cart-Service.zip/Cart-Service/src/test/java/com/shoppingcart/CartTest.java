package com.shoppingcart;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.context.request.WebRequest;

import com.shoppingcart.controller.CartController;
import com.shoppingcart.dto.CartDto;
import com.shoppingcart.dto.ProductDto;
import com.shoppingcart.dto.RegistrationDto;
import com.shoppingcart.entity.Cart;
import com.shoppingcart.entity.Items;
import com.shoppingcart.exception.CustomerNotFoundException;
import com.shoppingcart.exception.EmptyCartException;
import com.shoppingcart.exception.ExceptionResponse;
import com.shoppingcart.exception.GlobalExceptionHandler;
import com.shoppingcart.exception.IdMissmatchException;
import com.shoppingcart.exception.InvalidCartIdException;
import com.shoppingcart.exception.InvalidQuantityException;
import com.shoppingcart.exception.ProductDoesNotExistException;

class CartTest {

	Cart cart;
	List<Items> itemsList;
	ProductDto product;
	Items items;
	ExceptionResponse exceptionResponse;

	@InjectMocks
	CartController cartController;

	GlobalExceptionHandler globalExceptionHandler;
	WebRequest webRequest;

	// Product Dto
	@BeforeEach
	void setUp() {
		Map<String, String> specification = new HashMap<>();
		specification.put("color", "red");
		specification.put("size", "medium");
		product = new ProductDto("123", "Product1", "Category1", 10.0f, "Description", specification, "image1");
		items = new Items(product, 120);
		itemsList = new ArrayList<>();
		itemsList.add(items);
		cart = new Cart("3475", "1126", itemsList);
		exceptionResponse = new ExceptionResponse();
		globalExceptionHandler = new GlobalExceptionHandler();
		webRequest = Mockito.mock(WebRequest.class);
	}

	@Test
	void testGetProductId() {
		assertEquals("123", product.getProductId());
	}

	@Test
	void testSetProductId() {
		product.setProductId("456");
		assertEquals("456", product.getProductId());
	}
	

	@Test
	void testGetProductName() {
		assertEquals("Product1", product.getProductName());
	}

	@Test
	void testSetProductName() {
		product.setProductName("Product2");
		assertEquals("Product2", product.getProductName());
	}

	@Test
	void testGetCategory() {
		assertEquals("Category1", product.getCategory());
	}

	@Test
	void testSetCategory() {
		product.setCategory("Category2");
		assertEquals("Category2", product.getCategory());
	}

	@Test
	void testGetPrice() {
		assertEquals(10, product.getPrice());
	}

	@Test
	void testSetPrice() {
		product.setPrice(20);
		assertEquals(20, product.getPrice());
	}

	@Test
	void testGetDescription() {
		assertEquals("Description", product.getDescription());
	}

	@Test
	void testSetDescription() {
		product.setDescription("New Description");
		assertEquals("New Description", product.getDescription());
	}

	@Test
	void testGetSpecification() {
		assertNotNull(product.getSpecification());
		assertEquals("red", product.getSpecification().get("color"));
	}

	@Test
	void testSetSpecification() {
		Map<String, String> newSpecification = new HashMap<>();
		newSpecification.put("size", "large");
		product.setSpecification(newSpecification);
		assertNotNull(product.getSpecification());
		assertEquals("large", product.getSpecification().get("size"));
	}

	@Test
	void testGetImage() {
		assertEquals("image1", product.getImage());
	}

	@Test
	void testSetImage() {
		product.setImage("image2");
		assertEquals("image2", product.getImage());
	}

	@Test
	void testNoArgConstructor_productDto() {
		ProductDto productDto = new ProductDto();
		assertNull(productDto.getProductId());
		assertNull(productDto.getProductName());
		assertNull(productDto.getCategory());
		assertNull(productDto.getDescription());
		assertNull(productDto.getImage());
		assertNull(productDto.getSpecification());
		assertEquals(0, productDto.getPrice());

	}
	// Product Dto

	// Items
	@Test
	void testNoArgConstructor_Items() {
		Items items2 = new Items();
		assertNull(items2.getProduct());
		assertEquals(0, items2.getQuantity());
	}

	@Test
	void testGetProduct() {
		assertEquals(product, items.getProduct());
	}

	@Test
	void testSetProduct() {
		ProductDto prod = new ProductDto();
		items.setProduct(prod);
		assertEquals(prod, items.getProduct());
	}

	@Test
	void testGetQuantity() {
		assertEquals(120, items.getQuantity());
	}

	@Test
	void testSetQuantity() {
		items.setQuantity(130);
		assertEquals(130, items.getQuantity());
	}

	// Items

	// Cart

	@Test
	void testNoArgConstructor_Cart() {
		Cart newCart = new Cart();
		assertNull(newCart.getCartId());
		assertNull(newCart.getCustomerId());
		assertNull(newCart.getItemList());
	}

	@Test
	void testGetCartId() {
		assertEquals("3475", cart.getCartId());
	}

	@Test
	void testSetCartId() {
		cart.setCartId("3359");
		assertEquals("3359", cart.getCartId());
	}

	@Test
	void testGetCustomerId() {
		assertEquals("1126", cart.getCustomerId());
	}

	@Test
	void testSetCustomerId() {
		cart.setCustomerId("7654");
		assertEquals("7654", cart.getCustomerId());
	}

	@Test
	void testGetItemList() {
		assertNotNull(cart.getItemList());
		assertEquals(1, cart.getItemList().size());
	}

	@Test
	void testSetItemList() {
		ProductDto product2 = new ProductDto("765", "Product2", "Category2", 100.0f, "Description2", null, "image2");
		Items items2 = new Items(product2, 176);
		itemsList.add(items2);
		cart.setItemList(itemsList);

		assertNotNull(cart.getItemList());
		assertEquals(2, cart.getItemList().size());
	}

	// Items

	// CartDto

	@Test
	void testCartDto_GetterSetters() {
		CartDto cartDto = new CartDto();
		cartDto.setCartId("cart_123");
		cartDto.setCustomerId("customer_123");
		List<Items> list = new ArrayList<>();
		list.add(new Items(new ProductDto("1788", "KitKat", "Food", 20f, "Have a break, Have a kitkat", null, "img"),
				2));
		cartDto.setItemList(list);

		assertEquals("cart_123", cartDto.getCartId());
		assertEquals("customer_123", cartDto.getCustomerId());
		assertNotNull(cartDto.getItemList());
		assertEquals(cartDto.getItemList().size(), 1);

	}

	@Test
	void testCartDto_ArgConstructor() {
		List<Items> list = new ArrayList<>();
		list.add(new Items(new ProductDto("1788", "KitKat", "Food", 20f, "Have a break, Have a kitkat", null, "img"),
				2));
		CartDto cartDto = new CartDto("cart_123", "customer_123", list);

		assertEquals("cart_123", cartDto.getCartId());
		assertEquals("customer_123", cartDto.getCustomerId());
		assertNotNull(cartDto.getItemList());
		assertEquals(cartDto.getItemList().size(), 1);

	}

	// cartDto

	// RegistrationDto

	@Test
	void testRegistrationDto_GetterSetters() {
		RegistrationDto registration = new RegistrationDto();
		registration.setRegistrationId("R1");
		registration.setName("Lavanya");
		registration.setMobileNumber("9877898787");
		registration.setGender("Female");
		registration.setEmail("lavanya@gmail.com");
		registration.setPassword("Lavanya#2");
		registration.setRole("Customer");

		assertEquals("R1", registration.getRegistrationId());
		assertEquals("Lavanya", registration.getName());
		assertEquals("9877898787", registration.getMobileNumber());
		assertEquals("Female", registration.getGender());
		assertEquals("lavanya@gmail.com", registration.getEmail());
		assertEquals("Lavanya#2", registration.getPassword());
		assertEquals("Customer", registration.getRole());
	}

	@Test
	void testRegistrationDto_ArgConstructor() {
		RegistrationDto registration = new RegistrationDto("R1", "Lavanya", "Female", "lavanya@gmail.com", "Lavanya#2",
				"9877898787", "Customer");

		assertEquals("R1", registration.getRegistrationId());
		assertEquals("Lavanya", registration.getName());
		assertEquals("9877898787", registration.getMobileNumber());
		assertEquals("Female", registration.getGender());
		assertEquals("lavanya@gmail.com", registration.getEmail());
		assertEquals("Lavanya#2", registration.getPassword());
		assertEquals("Customer", registration.getRole());
	}

	// RegistrationDto

	@Test
	void testExceptions() {
		CustomerNotFoundException cExp = new CustomerNotFoundException("No customer Found");
		EmptyCartException eExp = new EmptyCartException("Cart is Empty..");
		IdMissmatchException iExp = new IdMissmatchException("Id didn't match");
		InvalidCartIdException icExp = new InvalidCartIdException("Cart id is invalid");
		InvalidQuantityException iqExp = new InvalidQuantityException("Invalid quantity");
		ProductDoesNotExistException pExp = new ProductDoesNotExistException("No product exists");

		assertEquals("No customer Found", cExp.getMessage());
		assertEquals("Cart is Empty..", eExp.getMessage());
		assertEquals("Id didn't match", iExp.getMessage());
		assertEquals("Cart id is invalid", icExp.getMessage());
		assertEquals("Invalid quantity", iqExp.getMessage());
		assertEquals("No product exists", pExp.getMessage());

	}

	// Exception response

	@Test
	void testConstructor() {
		LocalDate timestamp = LocalDate.now();
		String message = "Test Message";
		String details = "Test Details";
		String httpCodeMessage = "HTTP 404 - Not Found";

		exceptionResponse = new ExceptionResponse(timestamp, message, details, httpCodeMessage);

		assertEquals(timestamp, exceptionResponse.getTimestamp());
		assertEquals(message, exceptionResponse.getMessage());
		assertEquals(details, exceptionResponse.getDetails());
		assertEquals(httpCodeMessage, exceptionResponse.getHttpCodeMessage());
	}

	@Test
	void testGetTimestamp() {
		LocalDate timestamp = LocalDate.now();
		exceptionResponse.setTimestamp(timestamp);
		assertEquals(timestamp, exceptionResponse.getTimestamp());
	}

	@Test
	void testGetMessage() {
		String message = "Test Message";
		exceptionResponse.setMessage(message);
		assertEquals(message, exceptionResponse.getMessage());
	}

	@Test
	void testGetDetails() {
		String details = "Test Details";
		exceptionResponse.setDetails(details);
		assertEquals(details, exceptionResponse.getDetails());
	}

	@Test
	void testGetHttpCodeMessage() {
		String httpCodeMessage = "HTTP 404 - Not Found";
		exceptionResponse.setHttpCodeMessage(httpCodeMessage);
		assertEquals(httpCodeMessage, exceptionResponse.getHttpCodeMessage());
	}

	@Test
	void testDefaultConstructor() {
		// Test the default constructor for the correctness of initialization
		ExceptionResponse defaultResponse = new ExceptionResponse();
		assertEquals(null, defaultResponse.getTimestamp());
		assertEquals(null, defaultResponse.getMessage());
		assertEquals(null, defaultResponse.getDetails());
		assertEquals(null, defaultResponse.getHttpCodeMessage());
	}

	// Exception response

	@Test
	void testHandleAllException() {
		ExceptionResponse response = globalExceptionHandler
				.handleAllException(new Exception("Test exception"), webRequest).getBody();
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR,
				globalExceptionHandler.handleAllException(new Exception("Test exception"), webRequest).getStatusCode());
		assertEquals("Internal Server Error", response.getHttpCodeMessage());
		assertEquals("Test exception", response.getMessage());
	}

	@Test
	void testHandleCustomerNotFoundException() {
		ExceptionResponse response = globalExceptionHandler
				.handleCustomerNotFoundException(new CustomerNotFoundException("Customer not found"), webRequest)
				.getBody();
		assertEquals(HttpStatus.NOT_FOUND, globalExceptionHandler
				.handleCustomerNotFoundException(new CustomerNotFoundException("Customer not found"), webRequest)
				.getStatusCode());
		assertEquals("Not Found", response.getHttpCodeMessage());
		assertEquals("Customer not found", response.getMessage());
	}

	@Test
	void testHandleEmptyCartException() {
		ExceptionResponse response = globalExceptionHandler
				.handleEmptyCartException(new EmptyCartException("Empty cart"), webRequest).getBody();
		assertEquals(HttpStatus.BAD_REQUEST, globalExceptionHandler
				.handleEmptyCartException(new EmptyCartException("Empty cart"), webRequest).getStatusCode());
		assertEquals("Bad Request", response.getHttpCodeMessage());
		assertEquals("Empty cart", response.getMessage());
	}

	@Test
	void testHandleIdMissmatchException() {
		ExceptionResponse response = globalExceptionHandler
				.handleIdMissmatchException(new IdMissmatchException("ID mismatch"), webRequest).getBody();
		assertEquals(HttpStatus.BAD_REQUEST, globalExceptionHandler
				.handleIdMissmatchException(new IdMissmatchException("ID mismatch"), webRequest).getStatusCode());
		assertEquals("Not Found", response.getHttpCodeMessage());
		assertEquals("ID mismatch", response.getMessage());
	}

	@Test
	void testHandleInvalidCartIdException() {
		ExceptionResponse response = globalExceptionHandler
				.handleInvalidCartIdException(new InvalidCartIdException("Invalid cart ID"), webRequest).getBody();
		assertEquals(HttpStatus.BAD_REQUEST,
				globalExceptionHandler
						.handleInvalidCartIdException(new InvalidCartIdException("Invalid cart ID"), webRequest)
						.getStatusCode());
		assertEquals("Not Found", response.getHttpCodeMessage());
		assertEquals("Invalid cart ID", response.getMessage());
	}

	@Test
	void testHandleInvalidQuantityException() {
		ExceptionResponse response = globalExceptionHandler
				.handleInvalidQuantityException(new InvalidQuantityException("Invalid quantity"), webRequest).getBody();
		assertEquals(HttpStatus.BAD_REQUEST,
				globalExceptionHandler
						.handleInvalidQuantityException(new InvalidQuantityException("Invalid quantity"), webRequest)
						.getStatusCode());
		assertEquals("Not Found", response.getHttpCodeMessage());
		assertEquals("Invalid quantity", response.getMessage());
	}

	@Test
	void testHandleProductDoesNotExistException() {
		ExceptionResponse response = globalExceptionHandler
				.handleProductDoesNotExistException(new ProductDoesNotExistException("Product not found"), webRequest)
				.getBody();
		assertEquals(HttpStatus.NOT_FOUND, globalExceptionHandler
				.handleProductDoesNotExistException(new ProductDoesNotExistException("Product not found"), webRequest)
				.getStatusCode());
		assertEquals("Not Found", response.getHttpCodeMessage());
		assertEquals("Product not found", response.getMessage());
	}

//----------------------
	@Test
	void testHandleMethodArgumentNotValid() {
		GlobalExceptionHandler handler = new GlobalExceptionHandler(); // Instantiate your exception handler

		MethodArgumentNotValidException ex = mock(MethodArgumentNotValidException.class);
		BindingResult bindingResult = mock(BindingResult.class);
		FieldError fieldError1 = new FieldError("objectName", "field1", "Error message 1");
		FieldError fieldError2 = new FieldError("objectName", "field2", "Error message 2");

		when(ex.getBindingResult()).thenReturn(bindingResult);
		when(bindingResult.getFieldErrors()).thenReturn(List.of(fieldError1, fieldError2));

		WebRequest request = mock(WebRequest.class);

		ResponseEntity<Object> responseEntity = handler.handleMethodArgumentNotValid(ex, null, null, request);

		assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());

		ExceptionResponse exceptionResponse = (ExceptionResponse) responseEntity.getBody();
		assertEquals("Validation fails", exceptionResponse.getMessage());
		assertEquals("Bad Request", exceptionResponse.getHttpCodeMessage());

		String expectedDetails = "field1: Error message 1. field2: Error message 2. ";
		assertEquals(expectedDetails, exceptionResponse.getDetails());

	}

}
