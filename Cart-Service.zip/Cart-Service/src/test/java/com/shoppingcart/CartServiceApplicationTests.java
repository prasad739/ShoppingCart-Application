package com.shoppingcart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CartServiceApplicationTests {

	@Test
	void contextLoads() {
	}
	
//	@Test
//    void testMain() {
//        // You can simply call the main method to ensure it doesn't throw exceptions
//        CartServiceApplication.main(new String[]{});
//    }

}
