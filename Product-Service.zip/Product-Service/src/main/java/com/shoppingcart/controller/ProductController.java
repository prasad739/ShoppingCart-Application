package com.shoppingcart.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.shoppingcart.entity.Product;
import com.shoppingcart.entity.ProductDto;
import com.shoppingcart.service.ProductServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/product")
@CrossOrigin("*")
public class ProductController {

	@Autowired
	ProductServiceImpl serviceImpl;

// Constructor Injection
//	public ProductController(ProductServiceImpl serviceImpl) {
//		 System.out.println("in set");
//		this.serviceImpl=serviceImpl;
//	}

// Setter Injection
//	public void setServiceImpl(ProductServiceImpl serviceImpl) {
//		System.out.println("in set");
//		this.serviceImpl=serviceImpl;
//	}

	private static Logger logger = LogManager.getLogger();

	@PostMapping("/addProduct")
	public ResponseEntity<ProductDto> addProduct(@RequestBody @Valid Product product) {
		logger.info("Sending request to add a product");
		ProductDto prod = serviceImpl.addProduct(product);
		logger.info("Product added successfully!");
		return new ResponseEntity<>(prod, HttpStatus.OK);
	}

	@PutMapping("/updateProduct")
	public ResponseEntity<ProductDto> updateProduct(@RequestBody @Valid Product product) {
		logger.info("Sending request to update a product");
		ProductDto prod = serviceImpl.updateProduct(product);
		logger.info("Product updated successfully!");
		return new ResponseEntity<>(prod, HttpStatus.OK);
	}

	@DeleteMapping("/deleteProductById/{productId}")
	public ResponseEntity<String> deleteProductById(@PathVariable String productId) {
		logger.info("Sending request to delete a product");
		String message = serviceImpl.deleteProductById(productId);
		logger.info("Product deleted successfully!");
		return new ResponseEntity<>(message, HttpStatus.OK);
	}

	@GetMapping("/getAllProducts")
	public ResponseEntity<List<ProductDto>> getAllProducts() {
		logger.info("Sending request to view all products");
		List<ProductDto> list = serviceImpl.getAllProducts();
		logger.info("All Products fetched successfully!");
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	@GetMapping("/getProductById/{productId}")
	public ResponseEntity<ProductDto> getProductById(@PathVariable String productId) {
		logger.info("Sending request to view a product by id");
		ProductDto prod = serviceImpl.getProductById(productId);
		logger.info("Product fetched successfully!");
		return new ResponseEntity<>(prod, HttpStatus.OK);
	}

	@GetMapping("/getProductByName/{productName}")
	public ResponseEntity<ProductDto> getProductByName(@PathVariable String productName) {
		logger.info("Sending request to view a product by name");
		ProductDto prod = serviceImpl.getProductByName(productName);
		logger.info("Product fetched successfully!");
		return new ResponseEntity<>(prod, HttpStatus.OK);
	}

	@GetMapping("/getProductByCategory/{category}")
	public ResponseEntity<List<ProductDto>> getProductByCategory(@PathVariable String category) {
		logger.info("Sending request to view all products by category");
		List<ProductDto> list = serviceImpl.getProductByCategory(category);
		logger.info("Products fetched successfully!");
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	@GetMapping("/productsInBetweenRange/{minPrice}/{maxPrice}")
	public ResponseEntity<List<ProductDto>> productsInBetweenRange(@PathVariable float minPrice,
			@PathVariable float maxPrice) {
		logger.info("Sending request to view all products in between the range");
		List<ProductDto> list = serviceImpl.productsInBetweenRange(minPrice, maxPrice);
		logger.info("Products fetched successfully!");
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	@GetMapping("/productsUnderPrice/{price}")
	public ResponseEntity<List<ProductDto>> productsUnderPrice(@PathVariable float price) {
		logger.info("Sending request to view all products under the price");
		List<ProductDto> list = serviceImpl.productsUnderPrice(price);
		logger.info("Products fetched successfully!");
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	@GetMapping("/productsOverPrice/{price}")
	public ResponseEntity<List<ProductDto>> productsOverPrice(@PathVariable float price) {
		logger.info("Sending request to view all products over the price");
		List<ProductDto> list = serviceImpl.productsOverPrice(price);
		logger.info("Products fetched successfully!");
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

}
