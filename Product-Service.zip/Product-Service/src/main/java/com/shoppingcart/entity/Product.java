package com.shoppingcart.entity;

import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Positive;

@Document
public class Product {

	@Id
	@NotEmpty(message="Product Id should not be empty!")
	private String productId;
	
	@NotEmpty(message="Product name should not be empty!")
	private String productName;
	
	@NotEmpty(message="Category should not be empty!")
	private String category;
	
	
	@Positive(message="Enter a valid price.")
	private float price;
	
	@NotEmpty(message="Product Description should not be empty!")
	private String description;
	
	@NotEmpty(message="Product Specification should not be empty!")
	private Map<String, String> specification;
	
	@NotEmpty(message="Image should not be empty!")
	private String image;

	public Product() {
		super();
	}

	public Product(String productId, String productName, String category, float price, String description,
			Map<String, String> specification,String image) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.category = category;
		this.price = price;
		this.description = description;
		this.specification = specification;
		this.image=image;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Map<String, String> getSpecification() {
		return specification;
	}

	public void setSpecification(Map<String, String> specification) {
		this.specification = specification;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

}
