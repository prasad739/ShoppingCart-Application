package com.shoppingcart.service;

import java.util.List;

import com.shoppingcart.entity.Product;
import com.shoppingcart.entity.ProductDto;
import com.shoppingcart.exception.ProductAlreadyExistsException;
import com.shoppingcart.exception.ProductDoesNotExistException;

public interface IProductService {
	
	ProductDto addProduct(Product product) throws ProductAlreadyExistsException;
	ProductDto updateProduct(Product product) throws ProductDoesNotExistException;
	String deleteProductById(String productId) throws ProductDoesNotExistException;
	List<ProductDto> getAllProducts();
	
	ProductDto getProductById(String productId) throws ProductDoesNotExistException;
	ProductDto getProductByName(String productName) throws ProductDoesNotExistException;
	List<ProductDto> getProductByCategory(String category);
	
	List<ProductDto> productsInBetweenRange(float minPrice,float maxPrice);
	List<ProductDto> productsUnderPrice(float price);
	List<ProductDto> productsOverPrice(float price);
	
}
