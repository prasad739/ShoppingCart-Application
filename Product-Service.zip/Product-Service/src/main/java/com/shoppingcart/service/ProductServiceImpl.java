package com.shoppingcart.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shoppingcart.entity.Product;
import com.shoppingcart.entity.ProductDto;
import com.shoppingcart.exception.ProductAlreadyExistsException;
import com.shoppingcart.exception.ProductDoesNotExistException;
import com.shoppingcart.repository.IProductRepository;

@Service
public class ProductServiceImpl implements IProductService {

	@Autowired
	IProductRepository productRepo;

	@Autowired
	ModelMapper modelMapper;

	String exceptionMsgId = "Product do not exist with the given product id: ";

	public ProductDto addProduct(Product product) throws ProductAlreadyExistsException {
		Optional<Product> existingProduct = productRepo.findByProductName(product.getProductName());
		if (existingProduct.isPresent()) {
			throw new ProductAlreadyExistsException("Product already exits.");
		}
		productRepo.save(product);
		return modelMapper.map(product, ProductDto.class);
	}

	public ProductDto updateProduct(Product product) throws ProductDoesNotExistException {
		Optional<Product> prod = productRepo.findByProductId(product.getProductId());
		if (prod.isPresent()) {
			Product existingProduct = prod.get();
			existingProduct.setProductName(product.getProductName());
			existingProduct.setPrice(product.getPrice());
			existingProduct.setCategory(product.getCategory());
			existingProduct.setDescription(product.getDescription());
			existingProduct.setSpecification(product.getSpecification());
			existingProduct.setImage(product.getImage());
			productRepo.save(existingProduct);
			return modelMapper.map(product, ProductDto.class);
		}
		throw new ProductDoesNotExistException(exceptionMsgId + product.getProductId());
	}

	public String deleteProductById(String productId) throws ProductDoesNotExistException {
		Optional<Product> prod = productRepo.findByProductId(productId);
		if (prod.isPresent()) {
			productRepo.delete(prod.get());
			return "Product Deleted Successfully!";
		}
		throw new ProductDoesNotExistException(exceptionMsgId + productId);
	}

	public List<ProductDto> getAllProducts() {
		List<ProductDto> list = new ArrayList<>();
		for (Product p : productRepo.findAll()) {
			list.add(modelMapper.map(p, ProductDto.class));
		}
		return list;
	}

	public ProductDto getProductById(String productId) throws ProductDoesNotExistException {
		Optional<Product> prod = productRepo.findByProductId(productId);
		if (prod.isPresent()) {
			Product pro = prod.get();
			return modelMapper.map(pro, ProductDto.class);
		}
		throw new ProductDoesNotExistException(exceptionMsgId + productId);
	}

	public ProductDto getProductByName(String productName) throws ProductDoesNotExistException {
		Optional<Product> existingProduct = productRepo.findByProductName(productName);
		if (existingProduct.isPresent()) {
			Product prod = existingProduct.get();
			return modelMapper.map(prod, ProductDto.class);
		}
		throw new ProductDoesNotExistException("Product do not exist with the given product name: " + productName);
	}

	public List<ProductDto> getProductByCategory(String category) {

		List<ProductDto> list = new ArrayList<>();
		for (Product p : productRepo.findByCategory(category)) {
			list.add(modelMapper.map(p, ProductDto.class));
		}
		return list;
	}

	public List<ProductDto> productsInBetweenRange(float minPrice, float maxPrice) {
		List<Product> products = productRepo.findByPriceBetween(minPrice, maxPrice);
		List<ProductDto> list = new ArrayList<>();
		for (Product product : products) {
			list.add(modelMapper.map(product, ProductDto.class));
		}
		return list;
	}

	public List<ProductDto> productsUnderPrice(float price) {
		List<Product> products = productRepo.findByPriceLessThanEqual(price);
		List<ProductDto> list = new ArrayList<>();
		for (Product product : products) {
			list.add(modelMapper.map(product, ProductDto.class));
		}
		return list;
	}

	public List<ProductDto> productsOverPrice(float price) {
		List<Product> products = productRepo.findByPriceGreaterThanEqual(price);
		List<ProductDto> list = new ArrayList<>();
		for (Product product : products) {
			list.add(modelMapper.map(product, ProductDto.class));
		}
		return list;
	}
}
