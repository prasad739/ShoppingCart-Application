package com.shoppingcart;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.mongo.DataMongoTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.request.WebRequest;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.shoppingcart.controller.ProductController;
import com.shoppingcart.entity.Product;
import com.shoppingcart.entity.ProductDto;
import com.shoppingcart.exception.ExceptionResponse;
import com.shoppingcart.exception.GlobalExceptionHandler;
import com.shoppingcart.exception.ProductAlreadyExistsException;
import com.shoppingcart.exception.ProductDoesNotExistException;
import com.shoppingcart.repository.IProductRepository;
import com.shoppingcart.service.ProductServiceImpl;

@DataMongoTest
@AutoConfigureMockMvc
@ExtendWith(MockitoExtension.class)
public class ProductTest {

    @InjectMocks
    private ProductController productController;

    @Mock
    private ProductServiceImpl productService;

    MockMvc mockMvc;
    ObjectMapper objectMapper;

    @Autowired
    private IProductRepository productRepository;

    @InjectMocks
    private GlobalExceptionHandler globalExceptionHandler;

    @Mock
    private WebRequest webRequest;

    @Mock
    ModelMapper modelMapper;

    Product product = new Product();

    @BeforeEach
     void setUp() {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(productController).build();
        objectMapper = new ObjectMapper();
        modelMapper = new ModelMapper();
    }

    

    @Test
     void testProductId() {
        product.setProductId("123");
        assertEquals("123", product.getProductId());
    }

    @Test
     void testProductName() {
        product.setProductName("DELL Laptop");
        assertEquals("DELL Laptop", product.getProductName());
    }

    @Test
     void testCategory() {
        product.setCategory("Electronics");
        assertEquals("Electronics", product.getCategory());
    }

    @Test
     void testPrice() {
        product.setPrice(100.0f);
        assertEquals(100.0f, product.getPrice(), 0.001); // Use a delta for float comparison
    }

    @Test
     void testDescription() {
        product.setDescription("This is a test product");
        assertEquals("This is a test product", product.getDescription());
    }

    @Test
     void testSpecification() {
        Map<String, String> specification = new HashMap<>();
        specification.put("Color", "Red");
        specification.put("Size", "Medium");

        product.setSpecification(specification);
        assertNotNull(product.getSpecification());
        assertEquals(2, product.getSpecification().size());
        assertEquals("Red", product.getSpecification().get("Color"));
        assertEquals("Medium", product.getSpecification().get("Size"));
    }

    @Test
     void testImage() {
        product.setImage("product-image.jpg");
        assertEquals("product-image.jpg", product.getImage());
    }

    @Test
     void testProductConstructor() {
        String productId = "123";
        String productName = "Test Product";
        String category = "Electronics";
        float price = 100.0f;
        String description = "This is a test product";
        Map<String, String> specification = new HashMap<>();
        specification.put("Color", "Red");
        specification.put("Size", "Medium");
        String image = "product-image.jpg";

        Product product = new Product(productId, productName, category, price, description, specification, image);

        assertEquals(productId, product.getProductId());
        assertEquals(productName, product.getProductName());
        assertEquals(category, product.getCategory());
        assertEquals(price, product.getPrice(), 0.001); // Use a delta for float comparison
        assertEquals(description, product.getDescription());
        assertEquals(specification, product.getSpecification());
        assertEquals(image, product.getImage());
    }

    @Test
     void testValidInput() {
        ProductDto product = new ProductDto("12345", "Product Name", "Category", 49.99f, "Description", null,
                "image.jpg");
        assertNotNull(product);
        assertEquals("12345", product.getProductId());
        assertEquals("Product Name", product.getProductName());
        assertEquals("Category", product.getCategory());
        assertEquals(49.99f, product.getPrice(), 0.001);
        assertEquals("Description", product.getDescription());
        assertNull(product.getSpecification());
        assertEquals("image.jpg", product.getImage());
    }

    @Test
     void testNullDescription() {
        ProductDto product = new ProductDto("12345", "Product Name", "Category", 49.99f, null, null, "image.jpg");
        assertNotNull(product);
        assertEquals(null, product.getDescription());
    }

    @Test
     void testNegativePrice() {
        ProductDto product = new ProductDto("12345", "Product Name", "Category", -10.0f, "Description", null,
                "image.jpg");
        assertNotNull(product);
        assertEquals(-10.0f, product.getPrice(), 0.001);
    }

    @Test
     void testNullImage() {
        ProductDto product = new ProductDto("12345", "Product Name", "Category", 49.99f, "Description", null, null);
        assertNotNull(product);
        assertEquals(null, product.getImage());
    }

    @Test
     void testValidInput2() {
        LocalDate timestamp = LocalDate.now();
        String message = "An error occurred";
        String details = "This is a test error.";
        String httpCodeMessage = "Internal Server Error";

        ExceptionResponse response = new ExceptionResponse(timestamp, message, details, httpCodeMessage);

        assertNotNull(response);
        assertEquals(timestamp, response.getTimestamp());
        assertEquals(message, response.getMessage());
        assertEquals(details, response.getDetails());
        assertEquals(httpCodeMessage, response.getHttpCodeMessage());
    }

    @Test
     void testNullTimestamp() {
        String message = "An error occurred";
        String details = "This is a test error.";
        String httpCodeMessage = "Internal Server Error";

        ExceptionResponse response = new ExceptionResponse(null, message, details, httpCodeMessage);

        assertNotNull(response);
        assertNull(response.getTimestamp());
        assertEquals(message, response.getMessage());
        assertEquals(details, response.getDetails());
        assertEquals(httpCodeMessage, response.getHttpCodeMessage());
    }

    @Test
     void testEmptyMessage() {
        LocalDate timestamp = LocalDate.now();
        String details = "This is a test error.";
        String httpCodeMessage = "Internal Server Error";

        ExceptionResponse response = new ExceptionResponse(timestamp, "", details, httpCodeMessage);

        assertNotNull(response);
        assertEquals(timestamp, response.getTimestamp());
        assertEquals("", response.getMessage());
        assertEquals(details, response.getDetails());
        assertEquals(httpCodeMessage, response.getHttpCodeMessage());
    }

    @Test
     void testEmptyDetails() {
        LocalDate timestamp = LocalDate.now();
        String message = "An error occurred";
        String httpCodeMessage = "Internal Server Error";

        ExceptionResponse response = new ExceptionResponse(timestamp, message, "", httpCodeMessage);

        assertNotNull(response);
        assertEquals(timestamp, response.getTimestamp());
        assertEquals(message, response.getMessage());
        assertEquals("", response.getDetails());
        assertEquals(httpCodeMessage, response.getHttpCodeMessage());
    }

    @Test
     void testEmptyHttpCodeMessage() {
        LocalDate timestamp = LocalDate.now();
        String message = "An error occurred";
        String details = "This is a test error.";

        ExceptionResponse response = new ExceptionResponse(timestamp, message, details, "");

        assertNotNull(response);
        assertEquals(timestamp, response.getTimestamp());
        assertEquals(message, response.getMessage());
        assertEquals(details, response.getDetails());
        assertEquals("", response.getHttpCodeMessage());
    }

    // Repository Checking
    @Test
     void testFindByProductId() {
        Product product = new Product("1", "Test Product", "Electronics", 100.0f, "Description", null, "image.jpg");
        productRepository.save(product);

        Optional<Product> foundProduct = productRepository.findByProductId("1");

        assertTrue(foundProduct.isPresent());
        assertEquals("1", foundProduct.get().getProductId());
    }

    @Test
     void testFindByProductName() {
        Product product = new Product("2", "Camera", "Electronics", 100.0f, "Description", null, "image.jpg");
        productRepository.save(product);

        Optional<Product> foundProduct = productRepository.findByProductName("Camera");

        assertTrue(foundProduct.isPresent());
        assertEquals("Camera", foundProduct.get().getProductName());
    }

    @Test
     void testFindByCategory() {
        Product product1 = new Product("3", "Product 1", "Grocery", 100.0f, "Description", null, "image1.jpg");
        productRepository.save(product1);

        assertEquals("Grocery", product1.getCategory());
    }

    // Controller 

    @Test
     void testAddProduct() {
        Product product = new Product();
        ProductDto productDto = new ProductDto();
        when(productService.addProduct(any(Product.class))).thenReturn(productDto);
        ResponseEntity<ProductDto> response = productController.addProduct(product);
        assertEquals(response.getStatusCode(), HttpStatus.OK);
        ProductDto returnedProductDto = response.getBody();
        assertEquals(returnedProductDto, productDto);
    }

    @Test
     void testUpdateProduct() {
        Product product = new Product();
        ProductDto productDto = new ProductDto();
        when(productService.updateProduct(any(Product.class))).thenReturn(productDto);
        ResponseEntity<ProductDto> response = productController.updateProduct(product);
        assertEquals(response.getStatusCode(), HttpStatus.OK);
        ProductDto returnedProductDto = response.getBody();
        assertEquals(returnedProductDto, productDto);
    }

    @Test
     void testDeleteProductById() throws Exception {
        String productId = "1";
        String message = "Product deleted successfully";
        when(productService.deleteProductById(productId)).thenReturn(message);
        mockMvc.perform(delete("/product/deleteProductById/{productId}", productId)).andExpect(status().isOk())
                .andExpect(content().string(message));
    }

    @Test
     void testGetAllProducts() {
        List<ProductDto> productList = new ArrayList<>();
        when(productService.getAllProducts()).thenReturn(productList);
        ResponseEntity<List<ProductDto>> response = productController.getAllProducts();
        assertEquals(response.getStatusCode(), HttpStatus.OK);
        List<ProductDto> returnedList = response.getBody();
        assertEquals(returnedList, productList);
    }

    @Test
     void testGetProductById() throws Exception {
        String productId = "1";
        ProductDto productDto = new ProductDto();
        productDto.setProductId(productId);
        when(productService.getProductById(productId)).thenReturn(productDto);
        mockMvc.perform(get("/product/getProductById/{productId}", productId)).andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.productId").value(productId));
    }

    @Test
     void testGetProductByName() throws Exception {
        String productName = "Test Product";
        ProductDto productDto = new ProductDto();
        productDto.setProductName(productName);
        when(productService.getProductByName(productName)).thenReturn(productDto);
        mockMvc.perform(get("/product/getProductByName/{productName}", productName)).andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.productName").value(productDto.getProductName()));
    }

    @Test
     void testGetProductByCategory() throws Exception {
        String category = "Electronics";
        List<ProductDto> products = Arrays.asList(new ProductDto(), new ProductDto());

        when(productService.getProductByCategory(category)).thenReturn(products);

        mockMvc.perform(get("/product/getProductByCategory/{category}", category)).andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON)).andExpect(jsonPath("$").isArray());
    }

    @Test
     void testProductsInBetweenRange() throws Exception {
        float minPrice = 10.0f;
        float maxPrice = 50.0f;
        List<ProductDto> products = Arrays.asList(new ProductDto(), new ProductDto());

        when(productService.productsInBetweenRange(minPrice, maxPrice)).thenReturn(products);

        mockMvc.perform(get("/product/productsInBetweenRange/{minPrice}/{maxPrice}", minPrice, maxPrice))
                .andExpect(status().isOk()).andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$").isArray());
    }

    @Test
     void testProductsUnderPrice() throws Exception {
        float price = 30.0f;
        List<ProductDto> products = Arrays.asList(new ProductDto(), new ProductDto());

        when(productService.productsUnderPrice(price)).thenReturn(products);

        mockMvc.perform(get("/product/productsUnderPrice/{price}", price)).andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON)).andExpect(jsonPath("$").isArray());
    }

    @Test
     void testProductsOverPrice() throws Exception {
        float price = 70.0f;
        List<ProductDto> products = Arrays.asList(new ProductDto(), new ProductDto());

        when(productService.productsOverPrice(price)).thenReturn(products);

        mockMvc.perform(get("/product/productsOverPrice/{price}", price)).andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON)).andExpect(jsonPath("$").isArray());
    }

    @Test
     void testHandleAllException() {

        Exception exception = new Exception("Test Exception");
        ResponseEntity<ExceptionResponse> response = globalExceptionHandler.handleAllException(exception, webRequest);

        ExceptionResponse exceptionResponse = response.getBody();
        assertEquals(exceptionResponse.getHttpCodeMessage(), "Internal Server Error");
        assertEquals(exceptionResponse.getMessage(), "Test Exception");

        assertEquals(response.getStatusCode(), HttpStatus.INTERNAL_SERVER_ERROR);
        assertEquals(response.getBody().getHttpCodeMessage(), "Internal Server Error");
    }

    @Test
     void testHandleProductAlreadyExistsException() {
        ProductAlreadyExistsException exception = new ProductAlreadyExistsException("Product already exists");
        ResponseEntity<ExceptionResponse> response = globalExceptionHandler
                .handleProductAlreadyExistsException(exception, webRequest);

        assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
        assertEquals(response.getBody().getHttpCodeMessage(), "Bad Request");
    }

    @Test
     void testHandleProductDoesNotExistException() {
        ProductDoesNotExistException exception = new ProductDoesNotExistException("Product not found");

        ResponseEntity<ExceptionResponse> response = globalExceptionHandler
                .handleProductDoesNotExistException(exception, webRequest);

        assertEquals(response.getStatusCode(), HttpStatus.NOT_FOUND);

        ExceptionResponse exceptionResponse = response.getBody();
        assertEquals(exceptionResponse.getHttpCodeMessage(), "Not Found");
        assertEquals(exceptionResponse.getMessage(), "Product not found");

    }

    // service class testing

    @Test

     void testServiceGetProductByCategory() {

        Product p = new Product();
        String category = "Electronics";
        p.setCategory(category);

        List<Product> products = new ArrayList<>();
        products.add(p);

        when(productRepository.findByCategory(category)).thenReturn(products);

        List<ProductDto> result = productService.getProductByCategory(category);

        List<ProductDto> expectedProductDtos = new ArrayList<>();
        assertEquals(result, expectedProductDtos);
    }

    @Test
     void testSetPrice() {
        ProductDto productDto = new ProductDto();
        productDto.setPrice(100.0f);
        assertEquals(100.0f, productDto.getPrice(), 0.001);
    }

    @Test
     void testSetDescription() {
        ProductDto productDto = new ProductDto();
        productDto.setDescription("This is a test product");
        assertEquals("This is a test product", productDto.getDescription());
    }

    @Test
     void testSetSpecification() {
        ProductDto productDto = new ProductDto();
        Map<String, String> specification = new HashMap<>();
        specification.put("Color", "Red");
        specification.put("Size", "Medium");
        productDto.setSpecification(specification);
        assertEquals(specification, productDto.getSpecification());
    }

    @Test
     void testSetImage() {
        ProductDto productDto = new ProductDto();
        productDto.setImage("product-image.jpg");
        assertEquals("product-image.jpg", productDto.getImage());
    }

    @Test
     void testGetProductId() {
        ProductDto productDto = new ProductDto();
        productDto.setProductId("123");
        assertEquals("123", productDto.getProductId());
    }

    @Test
     void testGetProductName() {
        ProductDto productDto = new ProductDto();
        productDto.setProductName("Test Product");
        assertEquals("Test Product", productDto.getProductName());
    }

    @Test
     void testGetCategory() {
        ProductDto productDto = new ProductDto();
        productDto.setCategory("Electronics");
        assertEquals("Electronics", productDto.getCategory());
    }

}