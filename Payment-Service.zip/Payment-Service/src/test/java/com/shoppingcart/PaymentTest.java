package com.shoppingcart;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.shoppingcart.dto.CartDto;
import com.shoppingcart.dto.CustomerDto;
import com.shoppingcart.dto.PaymentDto;
import com.shoppingcart.dto.ProductDto;
import com.shoppingcart.entity.Items;
import com.shoppingcart.entity.Payment;
import com.shoppingcart.entity.TransactionDetails;

public class PaymentTest {

    Payment payment;
    TransactionDetails transactionDetails;
    Items items;
    CartDto cartDto;
    CustomerDto customerDto;
    ProductDto productDto;
    PaymentDto paymentDto;

    @BeforeEach
    public void setUp() {
        payment = new Payment("12345", "PAY123", "CUST123", new CartDto(), new Date(), 500.0, "123 Main St");
        transactionDetails = new TransactionDetails("12345", "USD", 100);
        items = new Items(new ProductDto(), 5);
        List<Items> itemList = new ArrayList<>();
        cartDto = new CartDto("12345", "CUST123", itemList);
        customerDto = new CustomerDto("12345", "John Doe", "Male", "john@example.com", "password", "1234567890");

        Map<String, String> specification = new HashMap<>();
        specification.put("Color", "Red");
        specification.put("Size", "Medium");
        productDto = new ProductDto("12345", "ProductA", "CategoryA", 100.0f, "DescriptionA", specification,
                "image.jpg");
         paymentDto = new PaymentDto("12345", "PAY123", "CUST123", new CartDto(), new Date(), 500.0, "123 Main St");
    }

    @Test
    public void testGettersAndSetters() {
        payment.setOrderId("54321");
        assertEquals("54321", payment.getOrderId());

        payment.setPaymentId("NEWPAY");
        assertEquals("NEWPAY", payment.getPaymentId());

        payment.setCustomerId("NEWCUST");
        assertEquals("NEWCUST", payment.getCustomerId());

        CartDto newCart = new CartDto();
        payment.setCart(newCart);
        assertEquals(newCart, payment.getCart());

        Date newDate = new Date();
        payment.setDate(newDate);
        assertEquals(newDate, payment.getDate());

        payment.setPrice(750.0);
        assertEquals(750.0, payment.getPrice(), 0.001);

        payment.setAddress("456 Another St");
        assertEquals("456 Another St", payment.getAddress());
    }

    @Test
    public void testDefaultConstructor() {
        Payment payment = new Payment();
        assertNotNull(payment);
    }

    @Test
    public void testTransactionDetailsDefaultConstructor() {
        TransactionDetails defaultTransactionDetails = new TransactionDetails();

    }

    @Test
    public void testTransactionDetailsParameterizedConstructor() {
        assertEquals("12345", transactionDetails.getOrderId());
        assertEquals("USD", transactionDetails.getCurrency());
        assertEquals(100, transactionDetails.getAmount());
    }

    @Test
    public void testTransactionDetailsGettersAndSetters() {
        transactionDetails.setOrderId("54321");
        assertEquals("54321", transactionDetails.getOrderId());

        transactionDetails.setCurrency("EUR");
        assertEquals("EUR", transactionDetails.getCurrency());

        transactionDetails.setAmount(200);
        assertEquals(200, transactionDetails.getAmount());
    }

    @Test
    public void testItemsDefaultConstructor() {
        Items defaultItems = new Items();
    }

    @Test
    public void testItemsParameterizedConstructor() {
        assertNotNull(items.getProduct()); // Ensure the product is not null
        assertEquals(5, items.getQuantity());
    }

    @Test
    public void testItemsGettersAndSetters() {
        ProductDto newProduct = new ProductDto();
        items.setProduct(newProduct);
        assertEquals(newProduct, items.getProduct());

        items.setQuantity(10);
        assertEquals(10, items.getQuantity());
    }

    @Test
    public void testParameterizedConstructor() {
        assertEquals("12345", cartDto.getCartId());
        assertEquals("CUST123", cartDto.getCustomerId());
        assertNotNull(cartDto.getItemList()); // Ensure itemList is not null
    }

    @Test
    public void testCartGettersAndSetters() {
        cartDto.setCartId("54321");
        assertEquals("54321", cartDto.getCartId());

        cartDto.setCustomerId("NEWCUST");
        assertEquals("NEWCUST", cartDto.getCustomerId());

        List<Items> newItems = new ArrayList<>();
        cartDto.setItemList(newItems);
        assertEquals(newItems, cartDto.getItemList());
    }

    @Test
    public void testCustomerDtoParameterizedConstructor() {
        assertEquals("12345", customerDto.getCustomerId());
        assertEquals("John Doe", customerDto.getCustomerName());
        assertEquals("Male", customerDto.getGender());
        assertEquals("john@example.com", customerDto.getEmail());
        assertEquals("password", customerDto.getPassword());
        assertEquals("1234567890", customerDto.getMobileNumber());
        assertEquals("ROLE_CUSTOMER", customerDto.getRole());
    }

    @Test
    public void testCustomerDtoGettersAndSetters() {
        customerDto.setCustomerId("54321");
        assertEquals("54321", customerDto.getCustomerId());

        customerDto.setCustomerName("Jane Doe");
        assertEquals("Jane Doe", customerDto.getCustomerName());

        customerDto.setGender("Female");
        assertEquals("Female", customerDto.getGender());

        customerDto.setEmail("jane@example.com");
        assertEquals("jane@example.com", customerDto.getEmail());

        customerDto.setPassword("newpassword");
        assertEquals("newpassword", customerDto.getPassword());

        customerDto.setMobileNumber("9876543210");
        assertEquals("9876543210", customerDto.getMobileNumber());

        customerDto.setRole("ROLE_ADMIN");
        assertEquals("ROLE_ADMIN", customerDto.getRole());
    }

    @Test
    public void testProductDtoParameterizedConstructor() {
        assertEquals("12345", productDto.getProductId());
        assertEquals("ProductA", productDto.getProductName());
        assertEquals("CategoryA", productDto.getCategory());
        assertEquals(100.0f, productDto.getPrice(), 0.001);
        assertEquals("DescriptionA", productDto.getDescription());
        assertEquals("image.jpg", productDto.getImage());

        Map<String, String> specification = productDto.getSpecification();
        assertEquals("Red", specification.get("Color"));
        assertEquals("Medium", specification.get("Size"));
    }

    @Test
    public void testProductDtoGettersAndSetters() {
        productDto.setProductId("54321");
        assertEquals("54321", productDto.getProductId());

        productDto.setProductName("ProductB");
        assertEquals("ProductB", productDto.getProductName());

        productDto.setCategory("CategoryB");
        assertEquals("CategoryB", productDto.getCategory());

        productDto.setPrice(200.0f);
        assertEquals(200.0f, productDto.getPrice(), 0.001);

        productDto.setDescription("DescriptionB");
        assertEquals("DescriptionB", productDto.getDescription());

        Map<String, String> newSpecification = new HashMap<>();
        newSpecification.put("Weight", "5kg");
        productDto.setSpecification(newSpecification);
        assertEquals("5kg", productDto.getSpecification().get("Weight"));

        productDto.setImage("newimage.jpg");
        assertEquals("newimage.jpg", productDto.getImage());
    }
    
    @Test
    public void testPaymentDtoParameterizedConstructor() {
        assertEquals("12345", paymentDto.getOrderId());
        assertEquals("PAY123", paymentDto.getPaymentId());
        assertEquals("CUST123", paymentDto.getCustomerId());
        assertNotNull(paymentDto.getCart());
        assertEquals(500.0, paymentDto.getPrice(), 0.001);
        assertEquals("123 Main St", paymentDto.getAddress());
    }

    @Test
    public void testPaymentDtoGettersAndSetters() {
        paymentDto.setOrderId("54321");
        assertEquals("54321", paymentDto.getOrderId());

        paymentDto.setPaymentId("NEWPAY");
        assertEquals("NEWPAY", paymentDto.getPaymentId());

        paymentDto.setCustomerId("NEWCUST");
        assertEquals("NEWCUST", paymentDto.getCustomerId());

        CartDto newCart = new CartDto();
        paymentDto.setCart(newCart);
        assertNotNull(paymentDto.getCart());

        Date newDate = new Date();
        paymentDto.setDate(newDate);
        assertEquals(newDate, paymentDto.getDate());

        paymentDto.setPrice(750.0);
        assertEquals(750.0, paymentDto.getPrice(), 0.001);

        paymentDto.setAddress("456 Another St");
        assertEquals("456 Another St", paymentDto.getAddress());
    }

}