package com.shoppingcart.dto;

import java.util.Date;

public class PaymentDto {

	private String orderId;
	private String paymentId;
	private String customerId;
	private CartDto cart;
	private Date date;
	private double price;
	private String address;

	public PaymentDto() {
		super();
	}

	public PaymentDto(String orderId, String paymentId, String customerId, CartDto cart, Date date, double price,String address) {
		super();
		this.orderId = orderId;
		this.paymentId = paymentId;
		this.customerId = customerId;
		this.cart = cart;
		this.date = date;
		this.price = price;
		this.setAddress(address);
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public CartDto getCart() {
		return cart;
	}

	public void setCart(CartDto cart) {
		this.cart = cart;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

}

