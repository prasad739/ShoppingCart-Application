package com.shoppingcart.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.shoppingcart.dto.PaymentDto;
import com.shoppingcart.entity.Payment;
import com.shoppingcart.entity.TransactionDetails;
import com.shoppingcart.service.PaymentServiceImpl;


@RestController
@RequestMapping("/payment")
@CrossOrigin("*")
public class PaymentController {
	
	private static final Logger logger=LogManager.getLogger();
	
	@Autowired
	PaymentServiceImpl paymentImpl;
	
	@PostMapping("/addPayment")
	public ResponseEntity<PaymentDto> addPayment(@RequestBody Payment payment){
		logger.info("Sending request to add payment");
		PaymentDto returnedPayment = paymentImpl.addPayment(payment);
		logger.info("Payment added successfully");
		return new ResponseEntity<>(returnedPayment,HttpStatus.OK);
	}
	
	@GetMapping("/getPayments/{customerId}")
	public ResponseEntity<List<PaymentDto>> getPayments(@PathVariable String customerId){
		logger.info("Sending request to get payments of a customer");
		 List<PaymentDto> paymentsByCustomerId = paymentImpl.getPaymentsByCustomerId(customerId);
		logger.info("Payments retrived successfully");
		return new ResponseEntity<>(paymentsByCustomerId,HttpStatus.OK);
	}
	
	@GetMapping("/createTransaction/{amount}")
	public ResponseEntity<TransactionDetails> createTransaction(@PathVariable int amount){
		logger.info("Sending request to create transaction");
		TransactionDetails transaction = paymentImpl.createTransaction(amount);
		logger.info("Transaction created successfully");
		return new ResponseEntity<>(transaction,HttpStatus.OK);
	}

}
