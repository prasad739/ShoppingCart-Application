package com.shoppingcart.service;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import com.shoppingcart.dto.PaymentDto;
import com.shoppingcart.entity.Payment;
import com.shoppingcart.entity.TransactionDetails;
import com.shoppingcart.repository.IPaymentRepository;

@Service
public class PaymentServiceImpl implements IPaymentService {

	// @Value("${razorpayKey}")
	//String razorpayKey = "rzp_test_VM8Xkkd1wi5HN9";
	String razorpayKey = "rzp_test_W98ynmCs68Aee6";

	// @Value("${razorpaySecretKey}")
//	String razorpaySecretKey = "6hJ0EUyCAxTgFGiFk8bXaAgu";
	String razorpaySecretKey = "TEDe1XH5mr2mC1huMwtB96Mx";

	// @Value("${currency}")
	String currency = "INR";

	@Autowired
	IPaymentRepository paymentRepo;

	@Autowired
	ModelMapper modelMapper;

	public PaymentDto addPayment(Payment payment) {
		paymentRepo.save(payment);
		return modelMapper.map(payment, PaymentDto.class);
	}

	public List<PaymentDto> getPaymentsByCustomerId(String customerId) {
		List<Payment> customerPayments = paymentRepo.findByCustomerId(customerId);
		List<PaymentDto> list = new ArrayList<>();
		for (Payment p : customerPayments) {
			list.add(modelMapper.map(p, PaymentDto.class));
		}
		return list;
	}

	public TransactionDetails createTransaction(int amount) {
		try {

			RazorpayClient razorpayClient = new RazorpayClient(razorpayKey, razorpaySecretKey);
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("amount", amount);
			jsonObj.put("currency", currency);

			Order order = razorpayClient.orders.create(jsonObj);
			
			return preTransactionDetails(order);

		} catch (RazorpayException e) {
			e.getMessage();
		}

		return null;
	}

	public TransactionDetails preTransactionDetails(Order order) {
		String orderId = order.get("id");
		String currency = order.get("currency");
		int amount = order.get("amount");
		
		return new TransactionDetails(orderId, currency, amount);

	}

}

//rzp_test_W98ynmCs68Aee6
//TEDe1XH5mr2mC1huMwtB96Mx