package com.shoppingcart.service;

import java.util.List;

import com.shoppingcart.dto.PaymentDto;
import com.shoppingcart.entity.Payment;
import com.shoppingcart.entity.TransactionDetails;

public interface IPaymentService {
	
	PaymentDto addPayment(Payment payment);
	
	List<PaymentDto> getPaymentsByCustomerId(String customerId);
	
	TransactionDetails createTransaction(int amount);

}
