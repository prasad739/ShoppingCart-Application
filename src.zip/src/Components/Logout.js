import React from 'react';
import { useNavigate } from 'react-router-dom';
import NavbarAdmin from '../Admin/NavbarAdmin';
import NavbarCustomer from '../Customer/NavbarCustomer';
import NavbarHome from './NavbarHome';


function Logout() {

    const navigate = useNavigate();
    const token=localStorage.getItem('token')
    const roles=localStorage.getItem('roles')

    const handleLogout = () => {
        localStorage.removeItem('username');
        localStorage.removeItem('token');
        localStorage.removeItem('roles');

        navigate('/');
    };

    return (
        <div>
            {token===null?(<NavbarHome/>):(roles==='ROLE_CUSTOMER'?(<NavbarCustomer/>):(<NavbarAdmin/>))}
       
            <div className='container'>
                {/* <h2>Log Out</h2> */}
                <h3>Are you sure you want to log out?</h3>
                <button className='product-button' onClick={() => navigate(-1)}>No</button>{' '}<button className='product-button' onClick={handleLogout}>Yes</button>
            </div>

        </div>
    );
}

export default Logout;