import React from 'react';
import '../Styles/NavbarHome.css';



function NavbarHome() {
  return (
    <div className="navbar">
      <div className="side-menu">
        <ul>
          <li ><a href="/">Home</a></li>
          <li><a href="/about">About</a></li>
          <li><a href="/contact">Contact</a></li>
        </ul>
      </div>
      <div className="heading">
        <h1>Online Shopping Cart</h1>
      </div>
      <div className="login-button">
        <a href="/login">Login</a>
      </div>
    </div>
  );
}

export default NavbarHome;
