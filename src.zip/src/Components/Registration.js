// import React, { useState, useEffect } from 'react';
// import { useNavigate } from 'react-router-dom';
// import axios from 'axios';
// import NavbarHome from './NavbarHome';
// import '../Styles/Registration.css'


// function Registration() {
//     const [inputFields, setInputFields] = useState({
//         registrationId: "",
//         name: "",
//         gender: "Male",
//         email: "",
//         password: "",
//         mobileNumber: "",
//         role: "ROLE_CUSTOMER"
//     })

//     const [confirmPassword,setConfirmPassword]=useState('')

//     const [errors, setErrors] = useState({});
//     const [submitting, setSubmitting] = useState(false);
//     const navigate = useNavigate();

//     useEffect(() => {
//         if (Object.keys(errors).length === 0 && submitting) {
//             finishSubmit();
//         }

//     }, [errors])

//     const finishSubmit = () => {

//         let apiUrl = null;
//         if (inputFields.role === 'ROLE_ADMIN') {
//             apiUrl = "http://localhost:9093/admin/addAdmin"
//         }
//         else {
//             apiUrl = "http://localhost:9093/customer/addCustomer"
//         }

//         axios.post(apiUrl, inputFields)
//             .then(response => {
//                 // after successfull registration.
//                 alert("Registered successfully")
//                 setInputFields({
//                     registrationId: "",
//                     name: "",
//                     gender: "",
//                     email: "",
//                     password: "",
//                     mobileNumber: "",
//                     role: ""
//                 })
//                 navigate('/login');

//             })
//             .catch(error => {
//                 // If the registration fails.
//                 alert(error.response.data.message);
//             });

//     }

//     const updateFields = (e) => {
//         setErrors({ ...errors, [e.target.name]: '' });
//         setInputFields({ ...inputFields, [e.target.name]: e.target.value });
//     }
//     const updateConfirmPassword = (e) => {
//         setErrors({ ...errors, [e.target.name]: '' });
//         setConfirmPassword(e.target.value)
//     }

//     const submithandler = (e) => {
//         e.preventDefault();
//         setErrors(validation(inputFields,confirmPassword));
//         setSubmitting(true);
//     }
//     const validation = (formValues,confirmPassword) => {
//         let err = {};
//         if (formValues.registrationId.length === 0) {
//             err.registrationId = "Id cannot be blank";
//         }

//         if (formValues.name.length === 0) {
//             err.name = "Username cannot be blank";
//         }

//         let emailPattern = /^[a-zA-z0-9!#$%^&*_.]+@[a-zA-z0-9]+\.[a-zA-Z]{2,}$/
//         if (!RegExp(emailPattern).test(formValues.email)) {
//             err.email = "Email doesn't meet the requirments...Email should be of the pattern abc@example.com";
//         }

//         let passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*_.]).{8,}$/
//         if (!RegExp(passwordPattern).test(formValues.password)) {
//             err.password = "Password doesn't meet the requirments...Password must Contain Atleast One spl character, One uppercase, One lowercase letter and must be of atleast 8characters!";
//         }

//         let mobilePattern = /^[6-9][0-9]{9}$/
//         if (!RegExp(mobilePattern).test(formValues.mobileNumber)) {
//             err.mobileNumber = "MobileNo. doesn't meet the requirments...Should start with any number between 6 to 9(both inclusive) and must be of 10 digits";
//         }

//         if(confirmPassword!==formValues.password || confirmPassword.length===0){
//             console.log(formValues.confirmPassword);
//             console.log(formValues.password);
//             err.confirmPassword="Passwords do not match";
//         }

//         return err;
//     }

//     return (
//         <div>
//             <NavbarHome />
//             <div className="registration-container">
//                 <h2>Register Now!</h2>
//                 <form style={{ textAlign: 'center' }} onSubmit={submithandler}>
//                     <div className="form-field">
//                     <div className="input-container">
//                         <label><b>Id</b></label><br></br>
//                         <input type="text" name="registrationId" value={inputFields.registrationId} onChange={updateFields} ></input><br></br>
//                         {errors.registrationId ? <p className="error">{errors.registrationId}</p> : null}
//                     </div>

//                     <div className="input-container">
//                         <label><b>Name</b></label><br></br>
//                         <input type="text" name="name" value={inputFields.name} onChange={updateFields} ></input><br></br>
//                         {errors.name ? <p className="error">{errors.name}</p> : null}
//                     </div>
//                     </div>
//                     <div className="form-filed">
//                     <div className="input-container">
//                         <label><b>Gender</b></label><br></br>
//                         <input type="radio" name="gender" value="Male" onChange={updateFields} id="Male" checked="checked"></input>
//                         <label for="Male">Male</label>
//                         <input type="radio" name="gender" value="Female" onChange={updateFields} id="Female"></input>
//                         <label for="Female">Female</label><br></br>
//                     </div>
//                     <div className="input-container">
//                         <label><b>Email</b></label><br></br>
//                         <input type="text" name="email" value={inputFields.email} onChange={updateFields} ></input><br></br>
//                         {errors.email ? <p className="error">{errors.email}</p> : null}
//                     </div>
//                     </div>
//                     <div className="form-filed">
//                     <div className="input-container">
//                         <label><b>Password</b></label><br></br>
//                         <input type="password" name="password" value={inputFields.password} onChange={updateFields} ></input><br></br>
//                         {errors.password ? <p className="error">{errors.password}</p> : null}
//                     </div>
                    
//                     <div className="input-container">
//                         <label><b>Re-Enter Password</b></label><br></br>
//                         <input type="password" name="confirmPassword" value={confirmPassword} onChange={updateConfirmPassword} ></input><br></br>
//                         {errors.confirmPassword ? <p className="error">{errors.confirmPassword}</p> : null}
//                     </div>
//                     </div>

//                     <div className="form-field">
//                     <div className="input-container">
//                         <label><b>MobileNumber</b></label><br></br>
//                         <input type="tel" name="mobileNumber" value={inputFields.mobileNumber} onChange={updateFields}></input><br></br>
//                         {errors.mobileNumber ? <p className="error">{errors.mobileNumber}</p> : null}
//                     </div>

//                     <div className="input-container">
//                         <label><b>Role</b></label><br></br>
//                         <input type="radio" name="role" value="ROLE_CUSTOMER" onChange={updateFields} id="ROLE_CUSTOMER" checked="checked" ></input>
//                         <label for="ROLE_CUSTOMER">Customer</label>
//                         <input type="radio" name="role" value="ROLE_ADMIN" onChange={updateFields} id="ROLE_ADMIN"></input>
//                         <label for="ROLE_ADMIN">Admin</label>
//                     </div>
//                     </div>
                    
                   
                    
                     
                    

//                     <br></br>

//                     <input type="submit" name="submit" value="Register"></input><br></br>
//                     <p>Already have an account?<br></br><a href="/login">Click here to login</a></p>

//                 </form>
//             </div>
//         </div>



//     );
// }
// export default Registration;


import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import NavbarHome from './NavbarHome';
import '../Styles/Registration.css'

function Registration() {
    const [inputFields, setInputFields] = useState({
        registrationId: "",
        name: "",
        gender: "Male",
        email: "",
        password: "",
        mobileNumber: "",
        role: "ROLE_CUSTOMER"
    });

    const [confirmPassword, setConfirmPassword] = useState('');
    const [errors, setErrors] = useState({});
    const [submitting, setSubmitting] = useState(false);
    const navigate = useNavigate();

    useEffect(() => {
        if (Object.keys(errors).length === 0 && submitting) {
            finishSubmit();
        }
    }, [errors]);

    const finishSubmit = () => {
        let apiUrl = null;
        if (inputFields.role === 'ROLE_ADMIN') {
            apiUrl = "http://localhost:9093/admin/addAdmin";
        } else {
            apiUrl = "http://localhost:9093/customer/addCustomer";
        }

        axios.post(apiUrl, inputFields)
            .then(response => {
                alert("Registered successfully");
                setInputFields({
                    registrationId: "",
                    name: "",
                    gender: "",
                    email: "",
                    password: "",
                    mobileNumber: "",
                    role: ""
                });
                navigate('/login');
            })
            .catch(error => {
                alert(error.response.data.message);
            });
    };

    const updateFields = (e) => {
        setErrors({ ...errors, [e.target.name]: '' });
        setInputFields({ ...inputFields, [e.target.name]: e.target.value });
    };

    const updateConfirmPassword = (e) => {
        setErrors({ ...errors, [e.target.name]: '' });
        setConfirmPassword(e.target.value);
    };

    const submithandler = (e) => {
        e.preventDefault();
        setErrors(validation(inputFields, confirmPassword));
        setSubmitting(true);
    };

    const validation = (formValues, confirmPassword) => {
        let err = {};
        if (formValues.registrationId.length === 0) {
            err.registrationId = "FirstName cannot be blank";
        }

        if (formValues.name.length === 0) {
            err.name = "LastName cannot be blank";
        }

        let emailPattern = /^[a-zA-z0-9!#$%^&*_.]+@[a-zA-z0-9]+\.[a-zA-Z]{2,}$/;
        if (!RegExp(emailPattern).test(formValues.email)) {
            err.email = "Email doesn't meet the requirements...Email should be of the pattern abc@example.com";
        }

        let passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*_.]).{8,}$/;
        if (!RegExp(passwordPattern).test(formValues.password)) {
            err.password = "Password doesn't meet the requirements...Password must contain at least one special character, one uppercase, one lowercase letter and must be of at least 8 characters!";
        }

        let mobilePattern = /^[6-9][0-9]{9}$/;
        if (!RegExp(mobilePattern).test(formValues.mobileNumber)) {
            err.mobileNumber = "Mobile number doesn't meet the requirements...Should start with any number between 6 to 9 (both inclusive) and must be of 10 digits";
        }

        if (confirmPassword !== formValues.password || confirmPassword.length === 0) {
            err.confirmPassword = "Passwords do not match";
        }

        return err;
    };

    return (
        <div>
            <NavbarHome />
            <div className="registration-container">
                <h2>Register Now!</h2>
                <form style={{ textAlign: 'center' }} onSubmit={submithandler}>
                    <div className="form-field">
                        <div className="input-container">
                            <label><b>First Name</b></label><br></br>
                            <input type="text" name="registrationId" value={inputFields.registrationId} onChange={updateFields} ></input><br></br>
                            {errors.registrationId ? <p className="error">{errors.registrationId}</p> : null}
                        </div>

                        <div className="input-container">
                            <label><b>Last Name</b></label><br></br>
                            <input type="text" name="name" value={inputFields.name} onChange={updateFields} ></input><br></br>
                            {errors.name ? <p className="error">{errors.name}</p> : null}
                        </div>
                    </div>

                    <div className="form-field">
                    
                        <div className="input-container">
                            <label><b>Email</b></label><br></br>
                            <input type="text" name="email" value={inputFields.email} onChange={updateFields} ></input><br></br>
                            {errors.email ? <p className="error">{errors.email}</p> : null}
                        </div>

                        <div className="input-container">
                            <label><b>Mobile Number</b></label><br></br>
                            <input type="tel" name="mobileNumber" value={inputFields.mobileNumber} onChange={updateFields}></input><br></br>
                            {errors.mobileNumber ? <p className="error">{errors.mobileNumber}</p> : null}
                        </div>
                    </div>

                    <div className="form-field">
                        <div className="input-container">
                            <label><b>Password</b></label><br></br>
                            <input type="password" name="password" value={inputFields.password} onChange={updateFields} ></input><br></br>
                            {errors.password ? <p className="error">{errors.password}</p> : null}
                        </div>
                        
                        <div className="input-container">
                            <label><b>Re-Enter Password</b></label><br></br>
                            <input type="password" name="confirmPassword" value={confirmPassword} onChange={updateConfirmPassword} ></input><br></br>
                            {errors.confirmPassword ? <p className="error">{errors.confirmPassword}</p> : null}
                        </div>
                    </div>

                    <div className="form-field">
                        <div className="input-container">
                            <label><b>Gender</b></label><br></br>
                            <input type="radio" name="gender" value="Male" onChange={updateFields} id="Male" checked="checked"></input>
                            <label htmlFor="Male">Male</label>
                            <input type="radio" name="gender" value="Female" onChange={updateFields} id="Female"></input>
                            <label htmlFor="Female">Female</label><br></br>
                        </div>

                        <div className="input-container">
                            <label><b>Role</b></label><br></br>
                            <input type="radio" name="role" value="ROLE_CUSTOMER" onChange={updateFields} id="ROLE_CUSTOMER" checked="checked" ></input>
                            <label htmlFor="ROLE_CUSTOMER">Customer</label>
                            <input type="radio" name="role" value="ROLE_ADMIN" onChange={updateFields} id="ROLE_ADMIN"></input>
                            <label htmlFor="ROLE_ADMIN">Admin</label>
                        </div>
                    </div>

                    <br></br>

                    <input type="submit" name="submit" value="Register"></input><br></br>
                     <p>Already have an account?<br></br><a href="/login">Click here to login</a></p>

                 </form>
             </div>
        </div>



    );
}
export default Registration;
