import axios from 'axios';
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import NavbarHome from './NavbarHome';
import '../Styles/Registration.css'

function Login() {
    const navigate = useNavigate();

    const [inputFields, setInputFields] = useState({
        username: '',
        password: '',
    });

    const [errors, setErrors] = useState({});
    const [submitting, setSubmitting] = useState(false);

    useEffect(() => {
        if (Object.keys(errors).length === 0 && submitting) {
            finishSubmit();
        }
    }, [errors]);

    const finishSubmit = () => {
        let apiUrl = 'http://localhost:9093/auth/generateToken';

        axios
            .post(apiUrl, inputFields)
            .then(response => {
                const { username, roles, accessToken } = response.data;
                
                // Saving token in local storage
                localStorage.setItem('username', username);
                localStorage.setItem('token', accessToken);
                localStorage.setItem('roles', roles);
                const role = localStorage.getItem('roles');
                if (role === 'ROLE_CUSTOMER') {
                    navigate('/customerhome');
                } else {
                    navigate('/adminHome');
                }

            })
            .catch(error => {
                console.error('Error:', error);
                alert('Bad Credentials: Login Failed! Please Try again.');
            });
    };

    const updateFields = e => {
        setErrors({ ...errors, [e.target.name]: '' });
        setInputFields({ ...inputFields, [e.target.name]: e.target.value });
    };

    const submithandler = e => {
        e.preventDefault();
        setErrors(validation(inputFields));
        setSubmitting(true);
    };

    const validation = formValues => {
        let err = {};
        if (formValues.username.length === 0) {
            err.username = 'Username cannot be blank';
        }
        if (formValues.password.length === 0) {
            err.password = 'Password cannot be blank';
        }
        return err;
    };

    return (
        <div>
            <NavbarHome />
            <div className="login-container">
                <h2>Login to your Account!</h2>

                <form style={{ textAlign: 'center' }} onSubmit={submithandler}>
                    <div className="input-container">
                        <label>
                            <b>Username</b>
                        </label>
                        <br></br>
                        <input
                            type="text"
                            name="username"
                            value={inputFields.username}
                            onChange={updateFields}

                        ></input>
                        <br></br>
                        {errors.username ? <p className="error">{errors.username}</p> : null}
                    </div>
                    <div className="input-container">
                        <label>
                            <b>Password</b>
                        </label>
                        <br></br>
                        <input
                            type="password"
                            name="password"
                            value={inputFields.password}
                            onChange={updateFields}

                        ></input>
                        <br></br>
                        {errors.password ? <p className="error">{errors.password}</p> : null}
                    </div>
                    <input type="submit" name="submit" value="Login"></input>
                    <br></br>

                    <p>Don't have an account?</p>
                    <Link to="/register">
                        <p>Click here to Register!</p>
                    </Link>
                </form>
            </div>
        </div>
    );
}
export default Login;
