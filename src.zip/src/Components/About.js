import NavbarAdmin from "../Admin/NavbarAdmin";
import NavbarCustomer from "../Customer/NavbarCustomer";
import NavbarHome from "./NavbarHome";
import Shop from "../Images/Shop.jpg"
import '../Styles/About.css';


function About() {
    const token = localStorage.getItem('token')
    const roles = localStorage.getItem('roles');
    return (
        <div>
            {token === null ? (<NavbarHome />) : (roles === "ROLE_CUSTOMER" ? <NavbarCustomer /> : <NavbarAdmin />)}

            <h2 style={{ marginTop: "50px" }}>About Us</h2>
            <div className="about-container">
                <div className="left-about">
                    <img src="https://www.royalcyber.com/wp-content/uploads/2022/12/share-your-cart.jpg" height="200px" />
                </div>
                <div className="right-about" style={{ textAlign: "center" }}>
                    <p>
                        <b >Welcome to our Online Shopping Cart application, <br></br> where convenience meets choice.</b> <br></br>
                        We're here to redefine your shopping experience by offering a seamless, user-friendly platform that brings the mall to your fingertips.
                        Browse a vast array of products, from the latest fashion trends to must-have tech gadgets, and effortlessly add them to your cart with just a few clicks.
                        Our commitment to customer satisfaction, secure transactions, and swift deliveries ensures that your shopping journey is not only enjoyable but worry-free.
                        Join us in this digital shopping adventure, and let us be your trusted companion in the world of online retail.
                    </p>

                </div>
            </div>

            <h2 style={{ textAlign: "center" }}>Happy Shopping..</h2>

        </div>);
}
export default About;