import NavbarHome from "./NavbarHome";
import DisplayCategories from "./DisplayCategories";
import '../Styles/Images.css';
import '../Styles/NavbarHome.css';

function Home() {
  return (
    <div>
      <NavbarHome />
      <DisplayCategories />
    </div>


  );
}

export default Home;

