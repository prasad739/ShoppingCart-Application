import NavbarCustomer from "../Customer/NavbarCustomer";
import NavbarHome from "./NavbarHome";
import NavbarAdmin from "../Admin/NavbarAdmin";
import '../Styles/Contact.css'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faInstagram, faFacebook } from '@fortawesome/free-brands-svg-icons';
import { faEnvelope, faPhone } from '@fortawesome/free-solid-svg-icons'; // Use free-solid-svg-icons for email and phone




function Contact() {
    const token = localStorage.getItem('token')
    const roles = localStorage.getItem('roles');
    return (
        <div>
            {token === null ? (<NavbarHome />) : (roles === "ROLE_CUSTOMER" ? <NavbarCustomer /> : <NavbarAdmin />)}
            {/* <h2>Contact Page</h2> */}

            <div className="contact-container">
                <b><p>
                    We value your feedback and are here to assist you with any questions or concerns. <br></br>
                    Please feel free to reach out to us through the following channels:
                </p></b>

                <div>
                    <FontAwesomeIcon icon={faEnvelope} size="1x" /> onlineshoppingcart@gmail.com
                </div>
                <div>
                    <FontAwesomeIcon icon={faPhone} size="1x" /> +91-6305695429
                </div>
                <div>
                    Follow us on:
                    <a href="https://www.instagram.com/OnlineShoppingCart" className="icon-container">
                        <FontAwesomeIcon icon={faInstagram} size="2x" />
                    </a>
                    <a href="https://www.facebook.com/OnlineShoppingCart" className="icon-container">
                        <FontAwesomeIcon icon={faFacebook} size="2x" />
                    </a>
                </div>

            </div>


        </div>);
}
export default Contact;








{/* Instagram: 
                <a href="https://www.instagram.com/OnlineShoppingCart" >
                    <FontAwesomeIcon icon={faInstagram} size="2x" />
                </a><br></br>
                Facebook:
                <a href="https://www.facebook.com/OnlineShoppingCart" target="_blank" rel="noopener noreferrer">
                    <FontAwesomeIcon icon={faFacebook} size="2x" />
                </a><br></br>
                Mail us at:
                <a href="mailto:shoppingcart@gmail.com">
                    <FontAwesomeIcon icon={faEnvelope} size="2x" />
                </a><br></br>
                Call us at:
                <a href="tel:+916305695429">
                    <FontAwesomeIcon icon={faPhone} size="2x" />
                </a> */}