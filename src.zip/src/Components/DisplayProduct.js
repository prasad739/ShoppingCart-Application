import { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';
import NavbarHome from './NavbarHome';
import '../Styles/Product.css';
import NavbarCustomer from '../Customer/NavbarCustomer';
import NavbarAdmin from '../Admin/NavbarAdmin';

function DisplayProduct() {
  const { category } = useParams();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const navigate = useNavigate();
  const customerName=localStorage.getItem('username');
  const token=localStorage.getItem('token')
  const roles=localStorage.getItem('roles');
  let customer_Id=null;
  

  const fetchProductsByCategory = async () => {
    try {
      const response = await axios.get(`http://localhost:9091/product/getProductByCategory/${category}`);
      setProducts(response.data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching products:', error);
      setLoading(false);
    }
  };

  const fetchProductsInPriceRange = async () => {
    try {
      const response = await axios.get(`http://localhost:9091/productsInBetweenRange/${minPrice}/${maxPrice}`);
      setProducts(response.data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching products within the price range:', error);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProductsByCategory();
  }, [category]);

  useEffect(() => {
    fetchProductsInPriceRange();
  }, [minPrice, maxPrice]);

  const handleSearchChange = (event) => {
    setSearchQuery(event.target.value);
  };

  const handleMinPriceChange = (event) => {
    setMinPrice(event.target.value);
  };

  const handleMaxPriceChange = (event) => {
    setMaxPrice(event.target.value);
  };

  const filteredProducts = products.filter(product => {
    const productPrice = parseFloat(product.price);
    const minPriceValue = parseFloat(minPrice);
    const maxPriceValue = parseFloat(maxPrice);

    return (
      (!minPrice || productPrice >= minPriceValue) &&
      (!maxPrice || productPrice <= maxPriceValue)
    ) && product.productName.toLowerCase().includes(searchQuery.toLowerCase());
  });

  async function handleWishlist(productId) {
    if (token === null) {
      navigate("/login");
    } else {
      try {
        const response = await axios.get(`http://localhost:9093/customer/getCustomerByName/${customerName}`);
         customer_Id = response.data.registrationId;
      } catch (error) {
        console.error('Error fetching Customer:', error);
      }

      try {
        const response2 = await axios.post(`http://localhost:9093/customer/addToWishlist/${customer_Id}/${productId}`, null, {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });
        alert("Added to wishlist successfully!");
      } catch (error) {
        if(error.response.status===500){
          alert("Product already in wishlist!")
        }
        console.error('Error fetching Customer:', error);
      }
    }
  }

  async function handleCart(product_Id) {
    if (token === null) {
      navigate("/login")
    } else {
      try {
        const response = await axios.get(`http://localhost:9093/customer/getCustomerByName/${customerName}`);
        customer_Id = response.data.registrationId;
      } catch (error) {
        console.error('Error fetching Customer:', error);
      }

      let cart_Id = customer_Id;
      const apiUrl = 'http://localhost:9093/customer/addToCart'; 
      const queryParams = {
        cartId: cart_Id,
        customerId: customer_Id,
        productId: product_Id,
        quantity: 1
      };
      const urlWithParams = `${apiUrl}?cartId=${queryParams.cartId}&customerId=${queryParams.customerId}&productId=${queryParams.productId}&quantity=${queryParams.quantity}`;

      const response = await axios.post(urlWithParams,null, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      })
        .then(response => {
          alert("Product added to cart successfully!")
        })
        .catch(error => {
          console.error('Error:', error);
        });

    }
  }


  return (
    <div>
       {token===null?(<NavbarHome/>):(roles==='ROLE_CUSTOMER'?(<NavbarCustomer/>):(<NavbarAdmin/>))}
       
      
      <h1 style={{ textAlign: "center" }}>Products for Category: {category}</h1>

      <div className="search-container">
        <input
          type="text"
          placeholder="Search products.."
          value={searchQuery}
          onChange={handleSearchChange}
        />
        </div>
        
        <div className="search-container">
          <h4>Search By Price: </h4>
          <div className="min-price">
        <input
          type="number"
          placeholder="Enter Min Price.."
          value={minPrice}
          onChange={handleMinPriceChange}
        />
        </div>
        <div className="max-price">

        <input
          type="number"
          placeholder="Enter Max Price.."
          value={maxPrice}
          onChange={handleMaxPriceChange}
        />
        </div>
      </div>

      {loading ? <p>Loading products...</p> : (
        <div className="product-card-container">
          {filteredProducts.map((product) => (
            <div className="product-card" key={product.productId}>
              <img src={product.image} alt={product.productName} />
              {/* <p><b>Product id:</b> {product.productId}</p> */}
              <p><b>Product:</b> {product.productName}</p>
              <p><b>Price:</b> Rs.{product.price}</p>
              <p><b>Description:</b> {product.description}</p>

              <div className="button-container">
                <button className="product-button" onClick={() => handleWishlist(product.productId)}>Add to Wishlist</button>
                <span className="button-spacer"></span>
                <button className="product-button" onClick={() => handleCart(product.productId)}>Add to Cart</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default DisplayProduct;
