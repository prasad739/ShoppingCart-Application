import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import useRazorpay from 'react-razorpay';
import NavbarCustomer from '../Customer/NavbarCustomer'
import axios from 'axios';
import '../Styles/Payment.css'


const Payment = () => {
  const [amount, setAmount] = useState(1000);
  const [userName, setUserName] = useState('');
  const [address, setAddress] = useState('');
  const [email, setEmail] = useState('');
  const [contact, setContact] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [Razorpay, initializeRazorpay] = useRazorpay();
  const [cart, setCart] = useState({})
  
  const navigate = useNavigate();
 
 

  const customerName = localStorage.getItem('username');
  const token = localStorage.getItem('token')
  let customer_Id = null;

  useEffect(() => {
    const fetchAmount = async () => {
      try {
        const response = await fetch(`http://localhost:9093/customer/getCustomerByName/${customerName}`);
        const customerResponse = await response.json();
        customer_Id = customerResponse.registrationId;
        setEmail(customerResponse.email);
        setContact(customerResponse.mobileNumber);

        const response2 = await axios.get(`http://localhost:9095/cart/getCartItems/${customer_Id}`)
        setCart(response2.data)

        const cartResponse = await fetch(`http://localhost:9095/cart/getTotalPrice/${customer_Id}`);
        const cartData = await cartResponse.json();
        setAmount(cartData * 100);
        setUserName(customerName);
      } catch (error) {
        console.error('Error fetching customer data:', error);
      }
    };

    fetchAmount();
  }, [customerName]);

  const deleteCart = async () => {
    try {
      const response = await fetch(`http://localhost:9093/customer/getCustomerByName/${customerName}`);
      const customerResponse = await response.json();

      customer_Id = customerResponse.registrationId;

      const response2 = await axios.delete(`http://localhost:9095/cart/updateCart/deleteCart/${customer_Id}`);

    } catch (error) {
      console.error('Error deleting customer cart:', error);
    }
  };

  const createOrder = async () => {
    
    try {
      setLoading(true);
      console.log("am"+amount);
      const response = await fetch(`http://localhost:9097/payment/createTransaction/${amount}`, {
        method: 'GET',
      });
      console.log("res",response);
      
      if (response.status === 200) {
        const orderData = await response.json();
        setLoading(false);
        return orderData.orderId;
      } else {
        throw new Error('Failed to create the order');
      }
    } catch (error) {
      setLoading(false);
      setError('Error creating order. Please try again.');
      console.error('Error creating order:', error);
      throw error;
    }
  };

  const addPayment = async (orderid,paymentid) => {

    const response = await fetch(`http://localhost:9093/customer/getCustomerByName/${customerName}`);
    const customerResponse = await response.json();
    customer_Id = customerResponse.registrationId;

    let paymentDetails={
      "orderId":orderid,
      "paymentId":paymentid,
      "customerId":customer_Id,
      "cart":cart,
      "date":new Date,
      "price":amount,
      "address":address

    }

    try{
      const response2=await axios.post(`http://localhost:9097/payment/addPayment`,paymentDetails)
      console.log("payment details posted");

    }
    catch(error){
      console.log("An error occured"+error);
    }

  }

  const handleCancelPayment=()=>{
    navigate("/cart")
  }

  const handlePayment = async () => {
    const order = await createOrder();
    if (!order) return;

    const options = {
      //key: 'rzp_test_VM8Xkkd1wi5HN9',
      key:'rzp_test_W98ynmCs68Aee6',
      amount: amount,
      currency: 'INR',
      name: userName,
      description: 'Test Transaction',
      order_id: order,
      handler: function (response) {

        alert("Thank you for Shopping!");

        //add payment in db
        addPayment(response.razorpay_order_id,response.razorpay_payment_id);

        deleteCart();

        navigate('/customerhome');
        
      },
      prefill: {
        name: userName,
        email: email,
        contact: contact,
      },
      notes: {
        address: 'XYZ Apartment',
      },
      theme: {
        color: '#3399cc',
      },
    };

    try {
      const rzp1 = new Razorpay(options);
      rzp1.open();
    } catch (error) {
      console.error('Error initializing Razorpay:', error);
    }
  };



  return (
    <div>
      <NavbarCustomer />
      <div className="container">
        <h1>Add address to Checkout</h1>

        <div className="details">
          <b>Name: </b><p>{userName}</p>
          <b>Amount: </b><p>Rs.{amount / 100}</p>
          <b>Email: </b><p>{email}</p>
          <b>Mobile Number: </b><p>{contact}</p>
          <b>Delivery Address: </b>
          <input
            type="text"
            placeholder="Address"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            required
          />
          <br />
        </div>

        {error && <div className="error">{error}</div>}
        {loading ? (
          <div className="loading">Initiating Payment...</div>
        ) : (
          <div>
          <button className="payment-button" onClick={handleCancelPayment}>
           Cancel 
          </button>
          <span className="button-spacer"></span>
          <button className="payment-button" onClick={handlePayment}>
            Pay Now
          </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Payment;
