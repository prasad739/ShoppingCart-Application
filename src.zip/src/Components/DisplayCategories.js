import { Link } from "react-router-dom";
import { useState } from "react";
import Clothing from '../Images/Clothing.png';
import Cosmetic from '../Images/Cosmetic.png';
import Electronics from '../Images/Electronics.webp';
import Grocery from '../Images/Grocery.jpg';
import Heels from '../Images/Heels.jpg';
import Kids from '../Images/Kids.jpg';
import Kitchen from '../Images/Kitchen.jpeg';
import Stationary from '../Images/Stationary.jpg';
import Travel from '../Images/Travel.jpg';
import '../Styles/Images.css';
import '../Styles/NavbarHome.css';


function DisplayCategories() {

  const [searchQuery, setSearchQuery] = useState('');

  const handleSearchChange = (event) => {
    setSearchQuery(event.target.value);
  };

  const filteredCategories = [
    { name: "Fashion and Style", image: Clothing },
    { name: "Beauty and Cosmetic", image: Cosmetic },
    { name: "Electronics", image: Electronics },
    { name: "Food and Grocery", image: Grocery },
    { name: "Footware", image: Heels },
    { name: "Kids Toys", image: Kids },
    { name: "Appliances and Cookware", image: Kitchen },
    { name: "Stationary", image: Stationary },
    { name: "Travel", image: Travel },
  ].filter(category => category.name.toLowerCase().includes(searchQuery.toLowerCase()));


  return (
    <div>

      <div className="search-container" >
        <input
          type="text"
          placeholder="Search category.."
          value={searchQuery}
          onChange={handleSearchChange}
        />
      </div>
      <div className="product-container">
        {
          filteredCategories.map((category, index) => (
            <div className="product-card" key={index}>
              <Link to={`/products/${category.name}`}>
                <img src={category.image} alt={category.name} />
                <div>
                  <h3>{category.name}</h3>
                </div>
              </Link>
            </div>
          ))
        }
      </div>
    </div>
  );
}

export default DisplayCategories;

