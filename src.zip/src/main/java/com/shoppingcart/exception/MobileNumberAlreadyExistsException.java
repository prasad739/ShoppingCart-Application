package com.shoppingcart.exception;

public class MobileNumberAlreadyExistsException extends RuntimeException {
	
	public MobileNumberAlreadyExistsException(String msg) {
		super(msg);
	}

}
