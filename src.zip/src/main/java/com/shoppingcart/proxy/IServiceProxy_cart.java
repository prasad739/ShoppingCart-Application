package com.shoppingcart.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.shoppingcart.dto.CartDto;


@FeignClient(url="http://localhost:9095/cart",name="cart-service")
public interface IServiceProxy_cart {
	
	@PostMapping("/addToCart")
	public ResponseEntity<CartDto> addToCart(@RequestParam(name="cartId") String cartId,@RequestParam(name = "customerId") String customerId,@RequestParam(name = "productId") String productId,@RequestParam(name ="quantity") int quantity);
	
	@PutMapping("/updateCart/decreaseQuantity")
	public ResponseEntity<String> decreaseProductQuantity(@RequestParam(name="decreaseBy") int decreaseBy,@RequestParam(name = "customerId") String customerId,@RequestParam(name = "productId") String productId);
	
	@PutMapping("/updateCart/deleteProduct")
	public ResponseEntity<String> deleteProductFromCart(@RequestParam(name = "customerId") String customerId,@RequestParam(name = "productId") String productId);
	
	@DeleteMapping("/updateCart/deleteCart/{customerId}")
	public ResponseEntity<String> deleteCart(@PathVariable String customerId);
	
	@GetMapping("/getTotalPrice/{customerId}")
	public ResponseEntity<Double> calculateTotalPrice(@PathVariable String customerId);
	
	@GetMapping("/getCartItems/{customerId}")
	public ResponseEntity<CartDto> getCartItemsByCustomerId(@PathVariable String customerId);

}
