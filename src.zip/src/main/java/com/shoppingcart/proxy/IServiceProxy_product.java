package com.shoppingcart.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.shoppingcart.dto.ProductDto;
import com.shoppingcart.entity.Product;

import jakarta.validation.Valid;


@FeignClient(url="http://localhost:9091/product",name="product-service")
public interface IServiceProxy_product {
	
	//For Customer and Admin Access
	@GetMapping("/getAllProducts")
	public ResponseEntity<List<ProductDto>> getAllProducts();
	
	@GetMapping("/getProductById/{productId}")
	public ResponseEntity<ProductDto> getProductById(@PathVariable String productId);
	
	@GetMapping("/getProductByName/{productName}")
	public ResponseEntity<ProductDto> getProductByName(@PathVariable String productName);
	
	@GetMapping("/getProductByCategory/{category}")
	public ResponseEntity<List<ProductDto>> getProductByCategory(@PathVariable String category);
	
	
	//For Admin Access
	@PostMapping("/addProduct")
	public ResponseEntity<ProductDto> addProduct(@RequestBody @Valid Product product) ;
	
	@PutMapping("/updateProduct")
	public ResponseEntity<ProductDto> updateProduct(@RequestBody @Valid Product product);
	
	@DeleteMapping("/deleteProductById/{productId}")
	public ResponseEntity<String> deleteProductById(@PathVariable String productId);
	
	

}
