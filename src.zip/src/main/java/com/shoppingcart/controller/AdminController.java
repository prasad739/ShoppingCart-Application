package com.shoppingcart.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.shoppingcart.dto.ProductDto;
import com.shoppingcart.dto.RegistrationDto;
import com.shoppingcart.entity.Product;
import com.shoppingcart.entity.Registration;
import com.shoppingcart.service.AdminServiceImpl;
import com.shoppingcart.service.CustomerServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/admin")
public class AdminController {

	private static final Logger logger = LogManager.getLogger();

	@Autowired
	AdminServiceImpl adminImpl;
	
	@Autowired
	CustomerServiceImpl customerImpl;

	@PostMapping("/addAdmin")
	public ResponseEntity<RegistrationDto> addAdmin(@RequestBody @Valid Registration admin) {
		logger.info("Sending request to add a admin");
		RegistrationDto ad = adminImpl.addAdmin(admin);
		logger.info("Admin added successfully!");
		return new ResponseEntity<>(ad, HttpStatus.CREATED);
	}

	@PutMapping("/updateAdmin")
	public ResponseEntity<RegistrationDto> updateAdmin(@RequestBody @Valid Registration admin) {
		logger.info("Sending request to update a admin");
		RegistrationDto ad = adminImpl.updateAdmin(admin);
		logger.info("Admin updated successfully!");
		return new ResponseEntity<>(ad, HttpStatus.OK);

	}

	@DeleteMapping("/deleteAdminById/{adminId}")
	public ResponseEntity<String> deleteAdminById(@PathVariable String adminId) {
		logger.info("Sending request to delete a admin");
		String msg = adminImpl.deleteAdminById(adminId);
		logger.info("Admin deleted successfully!");
		return new ResponseEntity<>(msg, HttpStatus.OK);
	}

	@GetMapping("/getAllAdmins")
	public ResponseEntity<List<RegistrationDto>> getAllAdmins() {
		logger.info("Sending request to view all admins");
		List<RegistrationDto> allAdmins = adminImpl.getAllAdmins();
		logger.info("Admins fetched successfully!");
		return new ResponseEntity<>(allAdmins, HttpStatus.OK);
	}

	@GetMapping("/getAdminById/{registrationId}")
	public ResponseEntity<RegistrationDto> getAdminById(@PathVariable String registrationId) {
		logger.info("Sending request to view a admin by id");
		RegistrationDto admin = adminImpl.getAdminById(registrationId);
		logger.info("Admin fetched successfully!");
		return new ResponseEntity<>(admin, HttpStatus.OK);
	}

	@GetMapping("/getAdminByName/{adminName}")
	public ResponseEntity<RegistrationDto> getAdminByName(@PathVariable String adminName) {
		logger.info("Sending request to view a admin by name");
		RegistrationDto admin = adminImpl.getAdminByName(adminName);
		logger.info("Admin fetched successfully!");
		return new ResponseEntity<>(admin, HttpStatus.OK);
	}
	
	//------Customer------
	
	@GetMapping("/getAllCustomers")
	public ResponseEntity<List<RegistrationDto>> getAllCustomers() {
		logger.info("Sending request to view all customers");
		List<RegistrationDto> allCustomers = customerImpl.getAllCustomers();
		logger.info("Customers fetched successfully!");
		return new ResponseEntity<>(allCustomers, HttpStatus.OK);
	}
	
	@GetMapping("/getCustomerById/{registrationId}")
	public ResponseEntity<RegistrationDto> getCustomerById(@PathVariable String registrationId) {
		logger.info("Sending request to view a customer by id");
		RegistrationDto cus = customerImpl.getCustomerById(registrationId);
		logger.info("Customer fetched successfully!");
		return new ResponseEntity<>(cus, HttpStatus.OK);
	}

	@GetMapping("/getCustomerByName/{customerName}")
	public ResponseEntity<RegistrationDto> getCustomerByName(@PathVariable String customerName) {
		logger.info("Sending request to view a customer by name");
		RegistrationDto cus = customerImpl.getCustomerByName(customerName);
		logger.info("Customer fetched successfully!");
		return new ResponseEntity<>(cus, HttpStatus.OK);
	}

	@GetMapping("/getCustomerByMobileNumber/{mobileNumber}")
	public ResponseEntity<RegistrationDto> getCustomerByMobileNumber(@PathVariable String mobileNumber) {
		logger.info("Sending request to view a customer by mobile number");
		RegistrationDto cus = customerImpl.getCustomerByMobileNumber(mobileNumber);
		logger.info("Customer fetched successfully!");
		return new ResponseEntity<>(cus, HttpStatus.OK);
	}
	
	//-------Product------
	
	@PostMapping("/addProduct")
	public ResponseEntity<ProductDto> addProduct(@RequestBody @Valid Product product) {
		logger.info("Sending request to add a product");
		ProductDto prod = adminImpl.addProduct(product);
		logger.info("Product added successfully!");
		return new ResponseEntity<>(prod, HttpStatus.CREATED);
	}
	
	@PutMapping("/updateProduct")
	public ResponseEntity<ProductDto> updateProduct(@RequestBody @Valid Product product) {
		logger.info("Sending request to update a product");
	    ProductDto pro = adminImpl.updateProduct(product);
		logger.info("Product updated successfully!");
		return new ResponseEntity<>(pro, HttpStatus.OK);

	}

	@DeleteMapping("/deleteProductById/{productId}")
	public ResponseEntity<String> deleteProductById(@PathVariable String productId) {
		logger.info("Sending request to delete a product");
		String msg = adminImpl.deleteProductById(productId);
		logger.info("Product deleted successfully!");
		return new ResponseEntity<>(msg, HttpStatus.OK);
	}

	@GetMapping("/getAllProducts")
	public ResponseEntity<List<ProductDto>> getAllProducts() {
		logger.info("Sending request to view all products");
		List<ProductDto> allProducts = customerImpl.getAllProducts();
		logger.info("Products fetched successfully!");
		return new ResponseEntity<>(allProducts, HttpStatus.OK);
	}

	@GetMapping("/getProductById/{productId}")
	public ResponseEntity<ProductDto> getProductById(@PathVariable String productId) {
		logger.info("Sending request to view product by Id ");
		ProductDto pro = customerImpl.getProductById(productId);
		logger.info("Product fetched successfully!");
		return new ResponseEntity<>(pro, HttpStatus.OK);
	}
	
	@GetMapping("/getProductByName/{productName}")
	public ResponseEntity<ProductDto> getProductByName(@PathVariable String productName) {
		logger.info("Sending request to view product by name ");
		ProductDto pro = customerImpl.getProductByName(productName);
		logger.info("Product fetched successfully!");
		return new ResponseEntity<>(pro, HttpStatus.OK);
	}
	
	@GetMapping("/getProductByCategory/{category}")
	public ResponseEntity<List<ProductDto>> getProductByCategory(@PathVariable String category) {
		logger.info("Sending request to view product by category ");
		List<ProductDto> productList = customerImpl.getProductByCategory(category);
		logger.info("Products fetched successfully!");
		return new ResponseEntity<>(productList, HttpStatus.OK);
	}


}
