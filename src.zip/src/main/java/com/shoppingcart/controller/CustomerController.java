package com.shoppingcart.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.shoppingcart.dto.CartDto;
import com.shoppingcart.dto.ProductDto;
import com.shoppingcart.dto.RegistrationDto;
import com.shoppingcart.entity.Registration;
import com.shoppingcart.service.CustomerServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/customer")
public class CustomerController {

	private static final Logger logger = LogManager.getLogger();

	@Autowired
	CustomerServiceImpl customerImpl;
	
//	@Autowired
//	EmailServiceImpl esi;

	@PostMapping("/addCustomer")
	public ResponseEntity<RegistrationDto> addCustomer(@RequestBody @Valid Registration customer) {
		logger.info("Sending request to add a customer");
		RegistrationDto cus = customerImpl.addCustomer(customer);
		logger.info("Customer added successfully!");
		//esi.sendEmail(customer.getEmail(), "Sireesha ShoppingCart", "Registered successfully!");
		return new ResponseEntity<>(cus, HttpStatus.CREATED);
	}

	@PutMapping("/updateCustomer")
	@PreAuthorize("hasAuthority('ROLE_CUSTOMER')")
	public ResponseEntity<RegistrationDto> updateCustomer(@RequestBody @Valid Registration customer) {
		logger.info("Sending request to update a customer");
		RegistrationDto cus = customerImpl.updateCustomer(customer);
		logger.info("Customer updated successfully!");
		return new ResponseEntity<>(cus, HttpStatus.OK);
	}

	@DeleteMapping("/deleteCustomerById/{customerId}")
	public ResponseEntity<String> deleteCustomerById(@PathVariable String customerId) {
		logger.info("Sending request to delete a customer");
		String msg = customerImpl.deleteCustomerById(customerId);
		logger.info("Customer deleted successfully!");
		return new ResponseEntity<>(msg, HttpStatus.OK);
	}

	@GetMapping("/getAllCustomers")
	public ResponseEntity<List<RegistrationDto>> getAllCustomers() {
		logger.info("Sending request to view all customers");
		List<RegistrationDto> allCustomers = customerImpl.getAllCustomers();
		logger.info("Customers fetched successfully!");
		return new ResponseEntity<>(allCustomers, HttpStatus.OK);
	}

	@GetMapping("/getCustomerById/{registrationId}")
	public ResponseEntity<RegistrationDto> getCustomerById(@PathVariable String registrationId) {
		logger.info("Sending request to view a customer by id");
		RegistrationDto cus = customerImpl.getCustomerById(registrationId);
		logger.info("Customer fetched successfully!");
		return new ResponseEntity<>(cus, HttpStatus.OK);
	}

	@GetMapping("/getCustomerByName/{customerName}")
	public ResponseEntity<RegistrationDto> getCustomerByName(@PathVariable String customerName) {
		logger.info("Sending request to view a customer by name");
		RegistrationDto cus = customerImpl.getCustomerByName(customerName);
		logger.info("Customer fetched successfully!");
		return new ResponseEntity<>(cus, HttpStatus.OK);
	}

	@GetMapping("/getCustomerByMobileNumber/{mobileNumber}")
	public ResponseEntity<RegistrationDto> getCustomerByMobileNumber(@PathVariable String mobileNumber) {
		logger.info("Sending request to view a customer by mobile number");
		RegistrationDto cus = customerImpl.getCustomerByMobileNumber(mobileNumber);
		logger.info("Customer fetched successfully!");
		return new ResponseEntity<>(cus, HttpStatus.OK);
	}

	@GetMapping("/getAllProducts")
	public ResponseEntity<List<ProductDto>> getAllProducts() {
		logger.info("Sending request to view all products");
		List<ProductDto> allProducts = customerImpl.getAllProducts();
		logger.info("Products fetched successfully!");
		return new ResponseEntity<>(allProducts, HttpStatus.OK);
	}

	@GetMapping("/getProductById/{productId}")
	public ResponseEntity<ProductDto> getProductById(@PathVariable String productId) {
		logger.info("Sending request to view product by Id ");
		ProductDto pro = customerImpl.getProductById(productId);
		logger.info("Product fetched successfully!");
		return new ResponseEntity<>(pro, HttpStatus.OK);
	}
	
	@GetMapping("/getProductByName/{productName}")
	public ResponseEntity<ProductDto> getProductByName(@PathVariable String productName) {
		logger.info("Sending request to view product by name ");
		ProductDto pro = customerImpl.getProductByName(productName);
		logger.info("Product fetched successfully!");
		return new ResponseEntity<>(pro, HttpStatus.OK);
	}
	
	@GetMapping("/getProductByCategory/{category}")
	public ResponseEntity<List<ProductDto>> getProductByCategory(@PathVariable String category) {
		logger.info("Sending request to view product by category ");
		List<ProductDto> productList = customerImpl.getProductByCategory(category);
		logger.info("Products fetched successfully!");
		return new ResponseEntity<>(productList, HttpStatus.OK);
	}
	
	
	@PostMapping("/addToCart")
	@PreAuthorize("hasAuthority('ROLE_CUSTOMER')")
	public ResponseEntity<CartDto> addToCart(@RequestParam(name="cartId") String cartId,@RequestParam(name = "customerId") String customerId,@RequestParam(name = "productId") String productId,@RequestParam(name ="quantity") int quantity){
		logger.info("Sending request to get add item into the cart");
		CartDto cart = customerImpl.addtoCart(cartId, customerId, productId, quantity);
		logger.info("Product Added to cart successfully!");
		return new ResponseEntity<>(cart, HttpStatus.OK);
	}

	@PutMapping("/updateCart/decreaseQuantity")
	public ResponseEntity<String> decreaseProductQuantity(@RequestParam(name="decreaseBy") int decreaseBy,@RequestParam(name = "customerId") String customerId,@RequestParam(name = "productId") String productId){
		logger.info("Sending request to decrease the quantity of the product");
		String cart = customerImpl.decreaseProductQuantity(decreaseBy, customerId, productId);
		logger.info("Quantity decreased successfully!");
		return new ResponseEntity<>(cart, HttpStatus.OK);
	}
	
	@GetMapping("/getCartItemsByCustomerId/{customerId}")
	public ResponseEntity<CartDto> getCartItemsByCustomerId(@PathVariable String customerId){
		logger.info("Sending request to get the cart items of the customer");
		CartDto cart = customerImpl.getCartItemsByCustomerId(customerId);
		logger.info("Customer cart fetched successfully!");
		return new ResponseEntity<>(cart, HttpStatus.OK);
	}

	@PutMapping("/updateCart/deleteProduct")
	public ResponseEntity<String> deleteProductFromCart(@RequestParam(name = "customerId") String customerId,@RequestParam(name = "productId") String productId){
		logger.info("Sending request to delete a product from cart");
		String str = customerImpl.deleteProductFromCart(customerId, productId);
		logger.info("Product deleted from the cart successfully!");
		return new ResponseEntity<>(str,HttpStatus.OK);
	}
	
	@DeleteMapping("/updateCart/deleteCart/{customerId}")
	public ResponseEntity<String> deleteCart(@PathVariable String customerId){
		logger.info("Sending request to delete all items in the cart cart");
		String str = customerImpl.deleteCart(customerId);
		logger.info("Cart deleted successfully!");
		return new ResponseEntity<>(str,HttpStatus.OK);
	}
	
	@GetMapping("/getTotalPrice/{customerId}")
	public ResponseEntity<Double> calculateTotalPrice(@PathVariable String customerId){
		logger.info("Sending request to calculate the cost of items in the cart");
		double price=customerImpl.calculateTotalPrice(customerId);
		logger.info("Total Price calculated!");
		return new ResponseEntity<>(price,HttpStatus.OK);
	}
	
	
	
	
	
}
