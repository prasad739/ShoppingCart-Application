package com.shoppingcart.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;

@Document
public class Registration {

	@Id
	@NotEmpty(message = "Id should not be empty!")
	private String registrationId;

	@NotEmpty(message = "Name should not be empty!")
	private String name;

	@Pattern(regexp = "(?i)^(male|female)$", message = "Gender should be 'male' or 'female'")
	private String gender;

	@Pattern(regexp = "[a-zA-z0-9!#$%^&*_.]+@[a-zA-z0-9]+\\.[a-zA-Z]{2,}", message = "Email doesn't meet the requirement")
	private String email;

	@Pattern(regexp = "(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*_.]).{8,}", message = "Password doesn't meet the requirement")
	private String password;

	@Pattern(regexp = "[6-9][0-9]{9}", message = "Mobile number doesn't meet the requirement")
	private String mobileNumber;

	private String role;

	public Registration() {
		super();
	}

	public Registration(@NotEmpty(message = "Id should not be empty!") String registrationId,
			@NotEmpty(message = "Name should not be empty!") String name,
			@NotEmpty(message = "Gender should not be empty!") String gender,
			@NotEmpty(message = "Email should not be empty!") @Pattern(regexp = "[a-zA-z0-9!#$%^&*_.]+@[a-zA-z0-9]+\\.[a-zA-Z]{2,}", message = "Email doesn't meet the requirement") String email,
			@NotEmpty(message = "Password should not be empty!") @Pattern(regexp = "(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*_.]).{8,}", message = "Password doesn't meet the requirement") String password,
			@NotEmpty(message = "Mobile number should not be empty!") @Pattern(regexp = "[6-9][0-9]{9}", message = "Mobile number doesn't meet the requirement") String mobileNumber,
			String role) {
		super();
		this.registrationId = registrationId;
		this.name = name;
		this.gender = gender;
		this.email = email;
		this.password = password;
		this.mobileNumber = mobileNumber;
		this.role = role;
	}

	public String getRegistrationId() {
		return registrationId;
	}

	public void setRegistrationId(String registrationId) {
		this.registrationId = registrationId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	
	
}
