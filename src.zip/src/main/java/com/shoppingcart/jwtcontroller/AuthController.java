package com.shoppingcart.jwtcontroller;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.shoppingcart.jwt.JSONResponse;
import com.shoppingcart.jwt.JwtUtility;
import com.shoppingcart.jwt.LoginRequest;
import com.shoppingcart.jwtservice.UserDetailsImpl;

@RestController
@RequestMapping("/auth")
public class AuthController {

	@Autowired
	DaoAuthenticationProvider authProvider;
	
	@Autowired
	JwtUtility jwtUtility;
	
	@PostMapping("/generateToken")
	public ResponseEntity<?> validateUser(@RequestBody LoginRequest loginRequest) {
		Authentication authentication = authProvider.authenticate(
				new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword()));
		
		JSONResponse jsonResponse=null;
		if (authentication.isAuthenticated()) {
			
			String token = jwtUtility.generateToken(authentication);
			UserDetailsImpl userDetailsImpl = (UserDetailsImpl) authentication.getPrincipal();
			Collection<? extends GrantedAuthority> authorities = userDetailsImpl.getAuthorities();
			List<String> collect = authorities.stream().map(GrantedAuthority::getAuthority)
					.collect(Collectors.toList());

			jsonResponse = new JSONResponse(token, userDetailsImpl.getUsername(), collect);
		}

		return ResponseEntity.ok(jsonResponse);
	}

}
