package com.shoppingcart.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.shoppingcart.dto.CartDto;
import com.shoppingcart.dto.ProductDto;
import com.shoppingcart.dto.RegistrationDto;
import com.shoppingcart.entity.Registration;
import com.shoppingcart.exception.CustomerNotFoundException;
import com.shoppingcart.exception.EmailAlreadyExistsException;
import com.shoppingcart.exception.MobileNumberAlreadyExistsException;
import com.shoppingcart.proxy.IServiceProxy_cart;
import com.shoppingcart.proxy.IServiceProxy_product;
import com.shoppingcart.repository.ICustomerRepository;

@Service
public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	ICustomerRepository customerRepo;

	@Autowired
	ModelMapper modelMapper;
	
	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	IServiceProxy_product sp;

	@Autowired
	IServiceProxy_cart st;
	
	
	

	public RegistrationDto addCustomer(Registration customer) {
		Optional<Registration> customerByEmail = customerRepo.findByEmail(customer.getEmail());
		Optional<Registration> customerByMobileNo = customerRepo.findByMobileNumber(customer.getMobileNumber());

		if (customerByEmail.isPresent()) {
			throw new EmailAlreadyExistsException("Email " + customer.getEmail() + " already taken!");
		}
		if (customerByMobileNo.isPresent()) {
			throw new MobileNumberAlreadyExistsException(
					"Mobile number " + customer.getMobileNumber() + " already taken!");
		}

		customer.setPassword(passwordEncoder.encode(customer.getPassword()));
		customerRepo.save(customer);
		
		return modelMapper.map(customer, RegistrationDto.class);
	}

	public RegistrationDto updateCustomer(Registration customer) {
		Optional<Registration> customerById = customerRepo.findByRegistrationId(customer.getRegistrationId());

		if (!customerById.isPresent()) {
			throw new CustomerNotFoundException("Customer with id " + customer.getRegistrationId() + " not found.");
		}

		Optional<Registration> customerByEmail = customerRepo.findByEmail(customer.getEmail());
		Optional<Registration> customerByMobileNo = customerRepo.findByMobileNumber(customer.getMobileNumber());

		if (customerByEmail.isPresent()) {
			if (!customerByEmail.get().getRegistrationId().equals(customer.getRegistrationId())) {
				throw new EmailAlreadyExistsException("Email " + customer.getEmail() + " already taken!");
			}
		}
		if (customerByMobileNo.isPresent()) {
			if (!customerByMobileNo.get().getRegistrationId().equals(customer.getRegistrationId())) {
				throw new MobileNumberAlreadyExistsException(
						"Mobile number " + customer.getMobileNumber() + " already taken!");
			}

		}

		customerRepo.save(customer);

		return modelMapper.map(customer, RegistrationDto.class);
	}

	public String deleteCustomerById(String customerId) {
		Optional<Registration> customerById = customerRepo.findByRegistrationId(customerId);

		if (!customerById.isPresent()) {
			throw new CustomerNotFoundException("Customer with id " + customerId + " not found.");
		}
		customerRepo.delete(customerById.get());

		return "Customer Deleted Successfully!";
	}

	public List<RegistrationDto> getAllCustomers() {
		List<RegistrationDto> list = new ArrayList<>();
		for (Registration r : customerRepo.findByRole("ROLE_CUSTOMER")) {
			list.add(modelMapper.map(r, RegistrationDto.class));
		}
		return list;
	}

	public RegistrationDto getCustomerById(String customerId) {
		Optional<Registration> customerById = customerRepo.findByRegistrationId(customerId);
		if (!customerById.isPresent()) {
			throw new CustomerNotFoundException("Customer with id " + customerId + " not found.");
		}
		Registration cust = customerById.get();
		return modelMapper.map(cust, RegistrationDto.class);
	}

	public RegistrationDto getCustomerByName(String customerName) {
		Optional<Registration> customerByName = customerRepo.findByName(customerName);
		if (!customerByName.isPresent()) {
			throw new CustomerNotFoundException("Customer with name " + customerName + " not found.");
		}
		Registration cust = customerByName.get();
		return modelMapper.map(cust, RegistrationDto.class);
	}

	public RegistrationDto getCustomerByMobileNumber(String mobileNumber) {
		Optional<Registration> customerByMobileNo = customerRepo.findByMobileNumber(mobileNumber);
		if (!customerByMobileNo.isPresent()) {
			throw new CustomerNotFoundException("Customer with mobile number " + mobileNumber + " not found.");
		}
		Registration cust = customerByMobileNo.get();
		return modelMapper.map(cust, RegistrationDto.class);
	}

	public List<ProductDto> getAllProducts() {
		ResponseEntity<List<ProductDto>> allProducts = sp.getAllProducts();
		return allProducts.getBody();
	}

	public ProductDto getProductById(String productId) {
		ResponseEntity<ProductDto> productById = sp.getProductById(productId);
		return productById.getBody();
	}

	public ProductDto getProductByName(String productName) {
		ResponseEntity<ProductDto> productByName = sp.getProductByName(productName);
		return productByName.getBody();
	}

	public List<ProductDto> getProductByCategory(String category) {
		return sp.getProductByCategory(category).getBody();
	}

	public CartDto getCartItemsByCustomerId(String customerId) {
		return st.getCartItemsByCustomerId(customerId).getBody();
	}

	public CartDto addtoCart(String cartId, String customerId, String productId, int quantity) {
		return st.addToCart(cartId, customerId, productId, quantity).getBody();
	}

	public String decreaseProductQuantity(int decreaseBy, String customerId, String productId) {
		return st.decreaseProductQuantity(decreaseBy, customerId, productId).getBody();
	}

	public String deleteProductFromCart(String customerId, String productId) {
		return st.deleteProductFromCart(customerId, productId).getBody();
	}

	public String deleteCart(String customerId) {
		return st.deleteCart(customerId).getBody();
	}

	public Double calculateTotalPrice(String customerId) {
		return st.calculateTotalPrice(customerId).getBody();
	}

}
