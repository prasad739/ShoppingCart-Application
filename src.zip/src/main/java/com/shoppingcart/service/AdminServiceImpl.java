package com.shoppingcart.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shoppingcart.dto.ProductDto;
import com.shoppingcart.dto.RegistrationDto;
import com.shoppingcart.entity.Product;
import com.shoppingcart.entity.Registration;
import com.shoppingcart.exception.AdminNotFoundException;
import com.shoppingcart.exception.EmailAlreadyExistsException;
import com.shoppingcart.exception.MobileNumberAlreadyExistsException;
import com.shoppingcart.proxy.IServiceProxy_product;
import com.shoppingcart.repository.IAdminRepository;

@Service
public class AdminServiceImpl implements IAdminService {

	@Autowired
	IAdminRepository adminRepo;
	
	@Autowired
	IServiceProxy_product sp;

	@Autowired
	ModelMapper modelMapper;

	@Override
	public RegistrationDto addAdmin(Registration admin) {
		Optional<Registration> adminByEmail = adminRepo.findByEmail(admin.getEmail());
		Optional<Registration> adminByMobileNo = adminRepo.findByMobileNumber(admin.getMobileNumber());

		if (adminByEmail.isPresent()) {
			throw new EmailAlreadyExistsException("Email " + admin.getEmail() + " already taken!");
		}
		if (adminByMobileNo.isPresent()) {
			throw new MobileNumberAlreadyExistsException(
					"Mobile number " + admin.getMobileNumber() + " already taken!");
		}

		adminRepo.save(admin);
		return modelMapper.map(admin, RegistrationDto.class);
	}

	public RegistrationDto updateAdmin(Registration admin) {
		Optional<Registration> adminById = adminRepo.findByRegistrationId(admin.getRegistrationId());

		if (!adminById.isPresent()) {
			throw new AdminNotFoundException("Admin with id " + admin.getRegistrationId() + " not found.");
		}

		Optional<Registration> adminByEmail = adminRepo.findByEmail(admin.getEmail());
		Optional<Registration> adminByMobileNo = adminRepo.findByMobileNumber(admin.getMobileNumber());

		if (adminByEmail.isPresent()) {
			if (!adminByEmail.get().getRegistrationId().equals(admin.getRegistrationId())) {
				throw new EmailAlreadyExistsException("Email " + admin.getEmail() + " already taken!");
			}
		}
		if (adminByMobileNo.isPresent()) {
			if (!adminByMobileNo.get().getRegistrationId().equals(admin.getRegistrationId())) {
				throw new MobileNumberAlreadyExistsException(
						"Mobile number " + admin.getMobileNumber() + " already taken!");
			}

		}

		adminRepo.save(admin);

		return modelMapper.map(admin, RegistrationDto.class);
	}

	@Override
	public String deleteAdminById(String adminId) {
		Optional<Registration> adminById = adminRepo.findByRegistrationId(adminId);

		if (!adminById.isPresent()) {
			throw new AdminNotFoundException("Admin with id " + adminId + " not found.");
		}
		adminRepo.delete(adminById.get());

		return "Admin Deleted Successfully!";
	}

	public List<RegistrationDto> getAllAdmins() {
		List<RegistrationDto> list = new ArrayList<>();
		for (Registration r : adminRepo.findByRole("ROLE_ADMIN")) {
			list.add(modelMapper.map(r, RegistrationDto.class));
		}
		return list;
	}

	public RegistrationDto getAdminById(String adminId) {
		Optional<Registration> adminById = adminRepo.findByRegistrationId(adminId);
		if (!adminById.isPresent()) {
			throw new AdminNotFoundException("Admin with id " + adminId + " not found.");
		}
		Registration admin = adminById.get();
		return modelMapper.map(admin, RegistrationDto.class);
	}

	public RegistrationDto getAdminByName(String adminName) {
		Optional<Registration> adminByName = adminRepo.findByName(adminName);
		if (!adminByName.isPresent()) {
			throw new AdminNotFoundException("Admin with name " + adminName + " not found.");
		}
		Registration admin = adminByName.get();
		return modelMapper.map(admin, RegistrationDto.class);
	}
	
	//----------------------------------
	
	public ProductDto addProduct(Product product){
		return sp.addProduct(product).getBody();
	}
	
	public ProductDto updateProduct(Product product){
		return sp.updateProduct(product).getBody();
	}
	
	public String deleteProductById(String productId){
		return sp.deleteProductById(productId).getBody();
	}

}
