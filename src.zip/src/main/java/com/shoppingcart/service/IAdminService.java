package com.shoppingcart.service;

import java.util.List;

import com.shoppingcart.dto.RegistrationDto;
import com.shoppingcart.entity.Registration;

public interface IAdminService {

	RegistrationDto addAdmin(Registration admin);

	RegistrationDto updateAdmin(Registration admin);

	String deleteAdminById(String adminId);

	List<RegistrationDto> getAllAdmins();

	RegistrationDto getAdminById(String adminId);

	RegistrationDto getAdminByName(String adminName);

}
