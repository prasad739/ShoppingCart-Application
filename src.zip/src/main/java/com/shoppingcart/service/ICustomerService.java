package com.shoppingcart.service;

import java.util.List;

import com.shoppingcart.dto.RegistrationDto;
import com.shoppingcart.entity.Registration;

public interface ICustomerService {
	
	RegistrationDto addCustomer(Registration customer);
	RegistrationDto updateCustomer(Registration customer);
	String deleteCustomerById(String registrationId);
	List<RegistrationDto> getAllCustomers();
	
	RegistrationDto getCustomerById(String registrationId);
	RegistrationDto getCustomerByName(String customerName);
	RegistrationDto getCustomerByMobileNumber(String mobileNumber);
	

}
