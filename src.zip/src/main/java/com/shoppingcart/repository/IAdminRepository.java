package com.shoppingcart.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.shoppingcart.entity.Registration;

@Repository
public interface IAdminRepository extends MongoRepository<Registration, String> {

	Optional<Registration> findByRegistrationId(String adminId);

	Optional<Registration> findByName(String adminName);
	
	List<Registration> findByRole(String role);

	Optional<Registration> findByMobileNumber(String mobileNumber);

	Optional<Registration> findByEmail(String email);

}
