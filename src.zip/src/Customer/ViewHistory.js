import { useState, useEffect } from "react";
import axios from "axios";
import NavbarCustomer from "./NavbarCustomer";
import '../Styles/PurchaseHistory.css';
import '../Styles/DisplayWishlist.css'

function ViewHistory() {
    const [paymentDetails, setPaymentDetails] = useState([]);
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(true);

    let customerName = localStorage.getItem('username');
    let customer_Id = null;

    useEffect(() => {
        const fetchHistory = async () => {
            try {
                const response = await axios.get(`http://localhost:9093/customer/getCustomerByName/${customerName}`);
                customer_Id = response.data.registrationId;

                try {
                    const response2 = await axios.get(`http://localhost:9097/payment/getPayments/${customer_Id}`);
                    setPaymentDetails(response2.data);
                } catch (error) {
                    console.error('Error', error);
                    setError('Error fetching cart items.');
                }
                setLoading(false);
            } catch (error) {
                console.error('Error', error);
                setError('Error fetching purchased items.');
                setLoading(false);
            }
        };

        fetchHistory();
    }, [customerName]);

 
    return (
        <div className="purchase-history">
            <NavbarCustomer />

            <div>
                {loading ? (
                    <p>Loading purchase history...</p>
                ) : error ? (
                    <p>{error}</p>
                ) : paymentDetails.length === 0 ? (
                    <div className="no-history">
                        <h2>No purchase History</h2>
                        <a href="/customerhome" className='button-link'>
                            Click here to browse products!
                        </a>
                    </div>
                ) : (
                    <div>
                        <ul>
                            <div className="order-container">
                                <h3>Your Orders..</h3>
                                {paymentDetails.map((order) => (
                                    <div className="order-card" key={order.orderId}>
                                        <p><b>Order ID:</b> {order.orderId}</p>
                                        <p><b>Payment ID:</b> {order.paymentId}</p>
                                        {/* <p><b>Customer ID:</b> {order.customerId}</p> */}
                                        <p><b>Shipping Address:</b> {order.address}</p>
                                        <p><b>Purchased On:</b> {new Date(order.date).toLocaleString()}</p>
                                        <p><b>Total Billing Amount:</b> Rs.{(order.price / 100).toFixed(2)}</p>

                                        <div className="cart-items">
                                            {order.cart.itemList.map((item) => (
                                                <div className="purchased-card" key={item.product.productId}>
                                                    <img src={item.product.image} alt={item.product.productName} />
                                                    {/* <p><b>Product ID:</b> {item.product.productId}</p> */}
                                                    <p><b>Product: {item.product.productName} </b></p>
                                                    <p><b>Price:</b> Rs.{item.product.price.toFixed(2)}</p>
                                                    <p><b>Description:</b> {item.product.description}</p>
                                                    <p><b>Quantity:</b> {item.quantity}</p>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </ul>
                    </div>
                )}
            </div>
        </div>
    );
}

export default ViewHistory;