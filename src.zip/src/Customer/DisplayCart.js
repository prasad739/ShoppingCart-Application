import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import NavbarCustomer from './NavbarCustomer';
import CartImg from '../Images/CartImg.jpg';
import '../Styles/DisplayWishlist.css'

function DisplayCart() {
  const [cartItems, setCartItems] = useState({});
  const [loading, setLoading] = useState(true);
  const [isEmpty, setIsEmpty] = useState(false);
  const [error, setError] = useState(null);
  const navigate = useNavigate();
  const customerName = localStorage.getItem('username');
  const token = localStorage.getItem('token')
  let customer_Id = null;
 
  const [totalCartCost, setTotalCartCost] = useState(0);

  useEffect(() => {
    const fetchCartItems = async () => {
      try {
        const response = await axios.get(`http://localhost:9093/customer/getCustomerByName/${customerName}`);
        customer_Id = response.data.registrationId;

        try {
          const response2 = await axios.get(`http://localhost:9093/customer/getCartItemsByCustomerId/${customer_Id}`, {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          });
          setCartItems(response2.data);
          fetchTotalCartCost();
        } catch (error) {
          if (error.response && error.response.status === 500) {
            setIsEmpty(true);
          } else {
            console.error('Error', error);
            setError('Error fetching cart items.');
          }
        }
        setLoading(false);
      } catch (error) {
        console.error('Error', error);
        setError('Error fetching cart items.');
        setLoading(false);
      }
    };

    fetchCartItems();
  }, [customerName, token, cartItems]);

  async function handleDeleteFromCart(product_Id) {
    if (token === null) {
      navigate('/login');
    } else {
      const confirmed = window.confirm('Are you sure you want to delete the product from the cart?');
      if (confirmed) {
        try {

          const response2 = await axios.get(`http://localhost:9093/customer/getCustomerByName/${customerName}`);
          customer_Id = response2.data.registrationId;

          const apiUrl = 'http://localhost:9095/cart/updateCart/deleteProduct';
          const queryParams = {
            customerId: customer_Id,
            productId: product_Id,
          };
          const urlWithParams = `${apiUrl}?customerId=${queryParams.customerId}&productId=${queryParams.productId}`;

          const response = await axios.put(urlWithParams)

          if (response.status === 200) {
            alert('Product deleted from the cart successfully!');

          }

        } catch (error) {
          console.error('Error:', error);
        }
      }
    }
  }

  async function handleDecreaseQuantity(product_Id) {
    if (token === null) {
      navigate('/login');
    } else {

      try {
        const response = await axios.get(`http://localhost:9093/customer/getCustomerByName/${customerName}`);
        customer_Id = response.data.registrationId;
      } catch (error) {
        console.error('Error fetching Customer:', error);
      }


      const apiUrl = 'http://localhost:9095/cart/updateCart/decreaseQuantity';
      const queryParams = {
        decreaseBy: 1,
        customerId: customer_Id,
        productId: product_Id,
      };

      const urlWithParams = `${apiUrl}?customerId=${queryParams.customerId}&productId=${queryParams.productId}&decreaseBy=${queryParams.decreaseBy}`;

      const response = await axios.put(urlWithParams, null,)
        .then(response => {
          // alert("Product quantity decreased!")
        })
        .catch(error => {
          console.error('Error:', error);
        });
    }
  }

  const fetchTotalCartCost = async () => {
    try {
      const response = await axios.get(`http://localhost:9095/cart/getTotalPrice/${customer_Id}`);
      setTotalCartCost(response.data);
    } catch (error) {
      console.error('Error fetching total cart cost:', error);
    }
  };

  async function handleIncrementQuantity(product_Id) {
    if (token === null) {
      navigate('/login');
    } else {
      try {
        const response = await axios.get(`http://localhost:9093/customer/getCustomerByName/${customerName}`);
        customer_Id = response.data.registrationId;
      } catch (error) {
        console.error('Error fetching Customer:', error);
      }

      const apiUrl = 'http://localhost:8084/cart/addToCart';
      
      const queryParams = {
        cartId: customer_Id,
        customerId: customer_Id,
        productId: product_Id,
        quantity: 1
      };

      const urlWithParams = `${apiUrl}?customerId=${queryParams.customerId}&productId=${queryParams.productId}&cartId=${queryParams.cartId}&quantity=${queryParams.quantity}`;

      try {
        const response = await axios.post(urlWithParams, null);
      } catch (error) {
        console.error('Error:', error);
      }
    }
  }

  return (
    <div>
      <NavbarCustomer />
      {loading ? (
        <p>Loading cart items...</p>
      ) : error ? (
        <p>{error}</p>
      ) : isEmpty ? (
        <div style={{ textAlign: "center" }}>
          <img src={CartImg}></img>
          <h2><b>Your cart is Empty </b></h2>
          <a href="/customerhome" className='button-link'><h3>Click here to browse products!</h3></a></div>
      ) : (
        <div>
          <ul>
            <div className="product-container">
              {cartItems.itemList.map(item => (
                <div className="product-card" key={item.product.productId}>

                  <img src={item.product.image} alt={item.product.productName} />
                  <p>
                    <b>Product ID:</b> {item.product.productId}
                  </p>
                  <p>
                    <b>Product Name:</b> {item.product.productName}
                  </p>
                  <p>
                    <b>Product Price:</b> Rs.{item.product.price}
                  </p>
                  <p><b>Description:</b> {item.product.description}</p>
                  <p>
                    <b>Quantity:</b> <br></br>
                    <button className="product-button" onClick={() => handleIncrementQuantity(item.product.productId)}>+</button>
                    <span className="button-spacer"></span>{item.quantity}
                    <span className="button-spacer"></span>
                    <button className="product-button" onClick={() => handleDecreaseQuantity(item.product.productId)}>-</button>
                  </p>
                  <div className="button-container">
                    <button className="product-button" onClick={() => handleDeleteFromCart(item.product.productId)}>
                      Delete from Cart
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </ul>


          <div style={{ textAlign: "center" }}>
            <h3><b>Total Cart Cost:</b> Rs.{totalCartCost}</h3>
            <button
              className="checkout-button"
              onClick={() => {
                navigate('/payment');
              }}
            >
              Proceed to Payment
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default DisplayCart;
