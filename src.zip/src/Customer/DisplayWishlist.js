import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import NavbarCustomer from './NavbarCustomer';
import '../Styles/DisplayWishlist.css';

function DisplayWishlist() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const navigate = useNavigate();
  const customerName = localStorage.getItem('username');
  const token = localStorage.getItem('token')
  let customer_Id = null;

  useEffect(() => {
    const fetchWishlistProducts = async () => {
      try {
        const response = await axios.get(`http://localhost:9093/customer/getCustomerByName/${customerName}`);
        customer_Id = response.data.registrationId;

        const response2 = await axios.get(`http://localhost:9093/customer/getWishlistProducts/${customer_Id}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setProducts(response2.data);
        setLoading(false);
      } catch (error) {
        if (error.response.status === 500) {
          setLoading(false);
          setProducts([])
        } else {

          console.error('Error', error);
          setError('Error fetching wishlist products.');
          setLoading(false);
        }

      }
    };

    fetchWishlistProducts();
  }, [customerName, token, products]);



  async function handleWishlist(productId) {
    if (token === null) {
      navigate("/login");
    } else {
      const confirmed = window.confirm("Are you sure, you want to delete the product from wishlist?");
      if (confirmed) {
        try {
          const response = await axios.get(`http://localhost:9093/customer/getCustomerByName/${customerName}`);
          customer_Id = response.data.registrationId;
        } catch (error) {
          console.error('Error fetching Customer:', error);
        }

        try {
          const response2 = await axios.put(`http://localhost:9093/customer/deleteFromWishlist/${customer_Id}/${productId}`, null, {
            headers: {
              Authorization: `Bearer ${token}`
            }
          });

        } catch (error) {
          console.error('Error fetching Customer:', error);
        }
      }
    }
  }

  async function handleCart(product_Id) {
    if (token === null) {
      navigate("/login")
    } else {
      const confirmed = window.confirm("Are you sure, you want to add the product to cart?");
      if (confirmed) {

        try {
          const response = await axios.get(`http://localhost:9093/customer/getCustomerByName/${customerName}`);
          customer_Id = response.data.registrationId;
        } catch (error) {
          console.error('Error fetching Customer:', error);
        }

        let cart_Id = customer_Id;
        const apiUrl = 'http://localhost:9093/customer/addToCart';
        const queryParams = {
          cartId: cart_Id,
          customerId: customer_Id,
          productId: product_Id,
          quantity: 1
        };
        const urlWithParams = `${apiUrl}?cartId=${queryParams.cartId}&customerId=${queryParams.customerId}&productId=${queryParams.productId}&quantity=${queryParams.quantity}`;

        const response = await axios.post(urlWithParams, null, {
          headers: {
            Authorization: `Bearer ${token}`
          }
        })
          .then(response => {
            setProducts(prevProducts => prevProducts.filter(product => product.productId !== product_Id));
            alert("Product added to cart successfully!")

            //delte product from wl after adding to cart

            try {
              axios.put(`http://localhost:9093/customer/deleteFromWishlist/${customer_Id}/${product_Id}`, null, {
                headers: {
                  Authorization: `Bearer ${token}`
                }
              });

            } catch (error) {
              console.error('Error fetching Customer:', error);
            }
          })
          .catch(error => {
            console.error('Error:', error);
          });
      }
    }
  }



  return (
    <div>
      <NavbarCustomer />
      {loading ? (
        <p>Loading wishlist products...</p>
      ) : error ? (
        <p>{error}</p>
      ) : products.length === 0 ? ( 
        <div class="empty-wishlist" style={{ textAlign: "center" }}><br></br><br></br>
          <img src='https://i.pinimg.com/originals/f6/e4/64/f6e464230662e7fa4c6a4afb92631aed.png'></img><br></br>
          <a href="/customerhome" className='button-link'><h3>Click here to browse products!</h3></a>
          </div>
          
      ) : (

        <ul>
          <div className='product-container'>
            {products.map((product) => (
              <div className="product-card" key={product.productId}>
                <img src={product.image} alt={product.productName} />
                <p><b>Product id:</b> {product.productId}</p>
                <p><b>Product Name:</b> {product.productName}</p>
                <p><b>Price:</b> Rs.{product.price}</p>
                <p><b>Description:</b> {product.description}</p>

                 <div className="button-container">
                  <button className="product-button" onClick={() => handleWishlist(product.productId)}>Remove from Wishlist</button>
                  <span className="button-spacer"></span>
                  <button className="product-button" onClick={() => handleCart(product.productId)}>Add to Cart</button>
                </div>
              </div>
            ))}
          </div>
        </ul>
      )}
    </div>
  );
}

export default DisplayWishlist;
