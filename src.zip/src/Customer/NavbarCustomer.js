import React, { useState } from 'react';
import { FaHeart, FaShoppingCart, FaUser } from 'react-icons/fa';
import { Link } from 'react-router-dom';
import '../Styles/NavbarCustomer.css';

function NavbarCustomer() {
  const [isDropdownOpen, setDropdownOpen] = useState(false);

  const toggleDropdown = () => {
    setDropdownOpen(!isDropdownOpen);
  };

  const closeDropdown = () => {
    setDropdownOpen(false);
  };
 
  return (
    <div>
      <div className="navbar">
        <div className="side-menu">
          <ul>
            <li><a href="/customerHome">Home</a></li>
            <li><a href="/about">About</a></li>
            <li><a href="/contact">Contact</a></li>
          </ul>
        </div>
        <div className="heading">
          <h1>Online Shopping Cart</h1>
        </div>
        <div className="icons">
          <Link to="/wishlist"><FaHeart className="icon" /></Link>
          <Link to="/cart"><FaShoppingCart className="icon" /></Link>
          <div className="dropdown" onClick={toggleDropdown}>
            <FaUser className="icon" />
            {isDropdownOpen && (
              <div className="dropdown-content">
                <Link to="/customerProfile" onClick={closeDropdown}>View Profile</Link>
                <Link to="/purchasedProducts" onClick={closeDropdown}>View Purchased Products</Link>
                <Link to="/logout" onClick={closeDropdown}>Logout</Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default NavbarCustomer;


















// import React from 'react';
// import { FaHeart, FaShoppingCart, FaUser } from 'react-icons/fa';
// import { Link } from 'react-router-dom';
// import '../Styles/NavbarCustomer.css'

// function NavbarCustomer() {
//   return (
//     <div>
//       <div className="navbar">
//         <div className="side-menu">
//           <ul>
//             <li><a href="/customerHome">Home</a></li>
//             <li><a href="/about">About</a></li>
//             <li><a href="/contact">Contact</a></li>
//           </ul>
//         </div>
//         <div className="heading">
//           <h1>Online Shopping Cart</h1>
//         </div>
//         <div className="icons">
//          <Link to="/wishlist"> <FaHeart className="icon" /> </Link>
//          <Link to="/cart"> <FaShoppingCart className="icon" /> </Link>
//          <Link to="/customerProfile"> <FaUser className="icon" /> </Link>
//         </div>
//       </div>
//     </div>
//   );
// }

// export default NavbarCustomer;
