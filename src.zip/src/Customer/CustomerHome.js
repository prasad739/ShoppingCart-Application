import DisplayCategories from "../Components/DisplayCategories";
import NavbarCustomer from "./NavbarCustomer";

function CustomerHome(){
    return(
        <div>
            <NavbarCustomer />
           <DisplayCategories/>
        </div>
    );
}

export default CustomerHome; 