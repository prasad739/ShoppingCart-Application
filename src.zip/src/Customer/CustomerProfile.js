import React, { useEffect, useState } from 'react';
import axios from 'axios';
import NavbarCustomer from './NavbarCustomer';
import '../Styles/CustomerProfile.css';

const CustomerProfile = () => {
    const [customer, setCustomer] = useState({
        "registrationId": '',
        "name": '',
        "gender": '',
        "email": '',
        "password": '',
        "mobileNumber": ''
    });
    const [editMode, setEditMode] = useState(false);
    //const [disableRegistrationId, setDisableRegistrationId] = useState(true);
    const [updatedCustomer, setUpdatedCustomer] = useState({
        "name": '',
        "email": '',
        "password": '',
        "mobileNumber": ''
    });

    const token = localStorage.getItem('token');
    let customerName = localStorage.getItem('username');

    useEffect(() => {
        const fetchUser = async () => {
            try {
               
                const response = await axios.get(`http://localhost:9093/customer/getCustomerByName/${customerName}`, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                setCustomer(response.data);
            } catch (error) {
                console.error(error);
            }
        };

        if (customerName) {
            fetchUser();
        }
    }, [customerName, token]);

    const handleEdit = () => {
        //setDisableRegistrationId(true); 
        setUpdatedCustomer({ ...customer });
        setEditMode(true);
    };

    const handleChange = (e) => {
        setUpdatedCustomer({ ...updatedCustomer, [e.target.name]: e.target.value });
    };

    const handleUpdate = async () => {
        try {
            setUpdatedCustomer({
                ...customer, 
                email: updatedCustomer.email,
                password: updatedCustomer.password,
                mobileNumber: updatedCustomer.mobileNumber,
                name: updatedCustomer.name,
            });

            const response = await axios.put(`http://localhost:9093/customer/updateCustomer`, updatedCustomer, {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            });

            // Check if username or password has been updated
            if (customer.name !== updatedCustomer.name || customer.password !== updatedCustomer.password) {
                let apiUrl = 'http://localhost:9093/auth/generateToken';

                axios
                    .post(apiUrl, { "username": updatedCustomer.name, "password": updatedCustomer.password })
                    .then(response => {
                        const { username, roles, accessToken } = response.data;
                        // Update the local storage with new token and username
                        localStorage.setItem('username', username);
                        localStorage.setItem('token', accessToken);
                        localStorage.setItem('roles', roles);
                    })
                    .catch(error => {
                        console.error('Error:', error);
                    });
            }

            setCustomer(response.data);
            setEditMode(false);
        } catch (error) {
            console.error(error);
        }
    };

    if (!customer) {
        return <div>Loading user details...</div>;
    }

    return (
        <div>
            <NavbarCustomer />
<div className='customer-profile'>
            <div className="container">
                {editMode ? (
                    <div className="details">
                        <h3 style={{textAlign:"center"}}>Edit Your Profile</h3>
                        {/* <label><b>User Id:</b></label> <br></br> 
                         <input
                            type="text"
                            name="registrationId"
                            value={updatedCustomer.registrationId}
                            onChange={handleChange}
                            disabled={disableRegistrationId}
                        /> <br></br> */}

                        <label><b>Name:</b></label><br></br>
                        <input type="text" name="name" value={updatedCustomer.name} onChange={handleChange} /><br></br>

                        <label><b>Email:</b></label><br></br>
                        <input type="text" name="email" value={updatedCustomer.email} onChange={handleChange} /><br></br>

                        <label><b>Password:</b></label><br></br>
                        <input type="password" name="password" value={updatedCustomer.password} onChange={handleChange} /><br></br>

                        <label><b>Mobile Number:</b></label><br></br>
                        <input type="text" name="mobileNumber" value={updatedCustomer.mobileNumber} onChange={handleChange} /><br></br>

                        <button className="customer-edit-button" onClick={handleUpdate}>Save</button>
                    </div>
                ) : (
                    <div className='details-class'>
                        <h3>Your Details...</h3>
                        <div className="customer-card customer-user-details">
                            {/* <p><b>Id: </b>{customer.registrationId}</p> */}
                            <p><b>Name: </b>{customer.name}</p>
                            <p><b>Gender: </b>{customer.gender}</p>
                            <p><b>Email: </b>{customer.email}</p>
                            <p><b>Mobile Number: </b>{customer.mobileNumber}</p>
                            <button className="customer-edit-button" onClick={handleEdit}>Edit Details</button>
                        </div>
                    </div>
                )}
            </div>
        </div>
        </div>
    );
};

export default CustomerProfile;



































































// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import NavbarCustomer from './NavbarCustomer';


// const CustomerProfile = () => {
//   const [customer, setCustomer] = useState({
//     "registrationId": '',
//     "name": '',
//     "gender": '',
//     "email": '',
//     "password": '',
//     "mobileNumber": ''
//   });
//   const [editMode, setEditMode] = useState(false);
//   const [updatedCustomer, setUpdatedCustomer] = useState({
//     "name": '',
//     "email": '',
//     "password": '',
//     "mobileNumber": ''
//   });
//   // const[userId,setUserId]=useState('')

//   const token = localStorage.getItem('token');
//   let customerName = localStorage.getItem('username');

//   useEffect(() => {
//     const fetchUser = async () => {
//       try {
        
//         const response = await axios.get(`http://localhost:9093/customer/getCustomerByName/${customerName}`);
//         setCustomer(response.data);
//         // const user2 = response.data.userId;
//         // //console.log("user"+user);
//         // setUserId(user2);
//       } catch (error) {
//         console.error(error);
//       }
//     };

//     if (customerName) {
//       fetchUser();
//     }
//   }, [customer]);

//   const handleEdit = () => {
//     setEditMode(true);
//     //setUpdatedCustomer({ ...user });
//   };

//   const handleChange = (e) => {
//     setUpdatedCustomer({ ...updatedCustomer, [e.target.name]: e.target.value });
//   };

//   const handleUpdate = async () => {
//     try {
//       setUpdatedCustomer({...customer,"email":updatedCustomer.email,"password":updatedCustomer.password,"mobileNumber":updatedCustomer.mobileNumber,"name":updatedCustomer.name});
//       console.log(updatedCustomer);
//       const response = await axios.put(`http://localhost:9093/customer/updateCustomer`, updatedCustomer,{
//         headers: {
//           Authorization: `Bearer ${token}`,
//         },
//       });
//       if(customer.name!==updatedCustomer.name || customer.password!==updatedCustomer.password){
//         let apiUrl = 'http://localhost:9093/auth/generateToken';

//         axios
//             .post(apiUrl, {"username":updatedCustomer.name,"password":updatedCustomer.password})
//             .then(response => {
//                 const { username, roles ,accessToken } = response.data;
//                 // Save credentials and token in local storage
//                 localStorage.setItem('username', username);
//                 localStorage.setItem('token', accessToken);
//                 localStorage.setItem('roles',roles);
//                 // navigate('/customerhome');
//             })
//             .catch(error => {
//                 console.error('Error:', error);
//                 // alert('Bad Credentials: Login Failed! Please Try again.');
//             });
//       }
//       setCustomer(response.data);
//       //localStorage.setItem('username',updatedCustomer.name);
//       setEditMode(false);
//     } catch (error) {
//       console.error(error);
//     }
//   };


//   if (!customer) {
//     return <div>Loading user details...</div>;
//   }

//   return (
//     <div>
//       <NavbarCustomer />

//       <div className="container" >
//         {editMode ? (
//           <div className="details">
//             <label><b>Username:</b></label><br></br>
//             <input type="text" name="name" value={updatedCustomer.name} onChange={handleChange} /><br></br>

//             <label><b>Email:</b></label><br></br>
//             <input type="text" name="email" value={updatedCustomer.email} onChange={handleChange} /><br></br>

//             <label><b>Password:</b></label><br></br>
//             <input type="password" name="password" value={updatedCustomer.password} onChange={handleChange} /><br></br>

//             <label><b>Mobile Number:</b></label><br></br>
//             <input type="text" name="mobileNumber" value={updatedCustomer.mobileNumber} onChange={handleChange} /><br></br>

//             <button onClick={handleUpdate}>Save</button>
//           </div>
//         ) : (
//           <div style={{ textAlign: "center" }}>
//             <h3>Your Details..</h3>
//             <div className="details">
//             <p><b>Id: </b>{customer.registrationId}</p>
//             <p><b>Name: </b>{customer.name}</p>
//             <p><b>Gender: </b>{customer.gender}</p>
//             <p><b>Email: </b>{customer.email}</p>
//             <p><b>Mobile Number: </b>{customer.mobileNumber}</p>
//               <button className='product-button' onClick={handleEdit}>Edit Details</button>
//             </div>
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };

// export default CustomerProfile;
