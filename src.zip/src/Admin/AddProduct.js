import NavbarAdmin from "./NavbarAdmin";
import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';


function AddProduct() {
  const token = localStorage.getItem('token');
  const navigate = useNavigate();

  const [product, setProduct] = useState({
    productId: '',
    productName: '',
    category: '',
    price: 0,
    description: '',
    specification: {}, 
    image: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setProduct({
      ...product,
      [name]: value,
    });
  };

  const handleSpecificationChange = (key, value) => {
    const updatedSpecification = {
      ...product.specification,
      [key]: value,
    };
    setProduct({
      ...product,
      specification: updatedSpecification,
    });
  };

  const handleAddSpecification = () => {
    const newKey = prompt('Enter a new key for the specification');
    if (newKey) {
      handleSpecificationChange(newKey, '');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:9093/admin/addProduct', product, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      console.log('Product created:', response.data);
      alert("Product added!")
      navigate('/viewAllProducts')
    } catch (error) {
      console.error('Error creating product:', error);
      if(error.response.status===500){
        alert("Product already exists..");
      }else{
        alert("Product Addition Unsuccessful! Please try again")
      }
      }
     
  };

  return (
    <div>
      <NavbarAdmin />
      <div className="container">
        <h2>Add New Product</h2>

        <div className="form-container">
          <form onSubmit={handleSubmit}>
            <table className="form-table">
              <tbody>
                <tr>
                  <td><b>Product ID:</b></td>
                  <td>
                    <input
                      type="text"
                      name="productId"
                      value={product.productId}
                      onChange={handleChange}
                      required
                    />
                  </td>
                </tr>
                <tr>
                  <td><b>Product Name:</b></td>
                  <td>
                    <input
                      type="text"
                      name="productName"
                      value={product.productName}
                      onChange={handleChange}
                      required
                    />
                  </td>
                </tr>
                <tr>
                  <td><b>Category:</b></td>
                  <td>
                    <input
                      type="text"
                      name="category"
                      value={product.category}
                      onChange={handleChange}
                      required
                    />
                  </td>
                </tr>
                <tr>
                  <td><b>Price:</b></td>
                  <td>
                    <input
                      type="number"
                      name="price"
                      value={product.price}
                      onChange={handleChange}
                      required
                    />
                  </td>
                </tr>
                <tr>
                  <td><b>Description:</b></td>
                  <td>
                    <textarea
                      name="description"
                      value={product.description}
                      onChange={handleChange}
                      required
                    />
                  </td>
                </tr>
                <tr>
                  <td><b>Image URL:</b></td>
                  <td>
                    <input
                      type="text"
                      name="image"
                      value={product.image}
                      onChange={handleChange}
                      required
                    />
                  </td>
                </tr>
                <tr>
                  <td><b>Specification:</b></td>
                  <td>
                    {Object.keys(product.specification).map((key) => (
                      <div key={key}>
                        <input
                          type="text"
                          name={`specification.${key}`}
                          value={product.specification[key]}
                          onChange={(e) => {
                            handleSpecificationChange(key, e.target.value);
                          }}
                        />
                      </div>
                    ))}
                    <button className="product-button" type="button" onClick={handleAddSpecification}>
                      Add Specification
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
            <div className="button-container">
              <button className="product-button" type="submit">Create Product</button>

            </div>

          </form>
        </div>
      </div>
    </div>
  );
}

export default AddProduct;
