import React, { useState, useEffect } from 'react';
import axios from 'axios';
import NavbarAdmin from "./NavbarAdmin";
import '../Styles/CustomerFunctionalities.css'

const CustomerFunctionalities = () => {
  const token = localStorage.getItem('token');
  const [customers, setCustomers] = useState([]);
  const [search, setSearch] = useState('');
  const [filteredCustomers, setFilteredCustomers] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:9093/admin/getAllCustomers', {
      headers: {
        Authorization: `Bearer ${token}`
      }
    })
      .then(response => {
        setCustomers(response.data);
        setFilteredCustomers(response.data); 
      })
      .catch(error => {
        console.error('Error fetching customer data:', error);
      });
  }, [token]);

  const handleSearch = () => {
    const searchResults = customers.filter(customer => {
      return (
        customer.name.toLowerCase().includes(search.toLowerCase()) ||
        customer.email.toLowerCase().includes(search.toLowerCase()) ||
        customer.mobileNumber.toLowerCase().includes(search.toLowerCase()) ||
        customer.registrationId.toString().includes(search)
      );
    });

    setFilteredCustomers(searchResults);
  };

return (
  <div>
    <NavbarAdmin />
    <h2 style={{textAlign:"center",color:"#007BFF"}}>Our Customers</h2>
    <div className='customer-search-box'>
      <input
        type="text"
        placeholder="Search by name, email, phone, or registration ID"
        value={search}
        onChange={e => setSearch(e.target.value)}
      />
     <span className="button-spacer"></span>
      <button onClick={handleSearch}>Search</button>
    </div>

    <table className="my-table"> 
      <thead>
        <tr>
          <th className="my-table-header">Customer ID</th> 
          <th className="my-table-header">Name</th>
          <th className="my-table-header">Phone No</th>
          <th className="my-table-header">Email</th>
          <th className="my-table-header">Gender</th>
        </tr>
      </thead>
      <tbody>
        {filteredCustomers.map(customer => (
          <tr key={customer.registrationId} className="my-table-row"> 
            <td className="my-table-row">{customer.registrationId}</td>
            <td className="my-table-row">{customer.name}</td>
            <td className="my-table-row">{customer.mobileNumber}</td>
            <td className="my-table-row">{customer.email}</td>
            <td className="my-table-row">{customer.gender}</td>
          </tr>
        ))}
      </tbody>
    </table>
  </div>
);
};

export default CustomerFunctionalities;