import { Navigate, useNavigate, useParams } from "react-router-dom";
import { useState,useEffect } from "react";

import axios from "axios";
import NavbarAdmin from "./NavbarAdmin";

function UpdateProduct() {
    const {productId} = useParams();
    console.log("id "+productId);
    const token = localStorage.getItem('token');
    let adminName = localStorage.getItem('username');
    const navigate=useNavigate();
    const [product, setProduct] = useState({
        "productId": '',
        "productName": '',
        "category": '',
        "price": '',
        "description": '',
        "specification": {},
        "image": ''
    });

    const [editMode, setEditMode] = useState(false);
    const [disableProductId, setDisableProductId] = useState(true);
    const [updatedProduct, setUpdatedProduct] = useState({
        "productName": '',
        "category": '',
        "price": '',
        "description": '',
        "specification": {},
        "image": ''
    });

    useEffect(() => {
        const fetchProduct = async () => {
            try {
                const response = await axios.get(`http://localhost:9093/admin/getProductById/${productId}`, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                setProduct(response.data);
                console.log(product);
            } catch (error) {
                console.error(error);
            }
        };

        if (product) {
            fetchProduct();
        }
    }, [productId]);

    const handleUpdate = async () => {
        try {
            setUpdatedProduct({
                ...product, 
                "productName": updatedProduct.productName,
                "category": updatedProduct.category,
                "price": updatedProduct.price,
                "description": updatedProduct.description,
                "specification": updatedProduct.specification,
                "image": updatedProduct.image

            });

            const response = await axios.put(`http://localhost:9093/admin/updateProduct`, updatedProduct, {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            });


            setProduct(response.data);
            setEditMode(false);
            alert("Product updated Successfully!")
            navigate('/viewAllProducts')
        } catch (error) {
            console.error(error);
        }
    };

    const handleEdit = () => {
        setDisableProductId(true); 
        setUpdatedProduct({ ...product });
        setEditMode(true);
    };

    const handleChange = (e) => {
        setUpdatedProduct({ ...updatedProduct, [e.target.name]: e.target.value });
    };

    




    return (
        <div>
            <NavbarAdmin />
            <div className="container">
                {editMode ? (
                    <div className="details">
                        <h3 style={{ textAlign: "center" }}>Edit Product</h3>
                        <label><b>Product Id:</b></label> <br></br>
                        <input
                            type="text"
                            name="productId"
                            value={product.productId}
                            onChange={handleChange}
                            disabled={disableProductId}
                        /> <br></br>

                        <label><b>Product Name:</b></label><br></br>
                        <input type="text" name="productName" value={updatedProduct.productName} onChange={handleChange} /><br></br>

                        <label><b>Price:</b></label><br></br>
                        <input type="number" name="price" value={updatedProduct.price} onChange={handleChange} /><br></br>

                        <label><b>Category:</b></label><br></br>
                        <input type="text" name="category" value={updatedProduct.category} onChange={handleChange} /><br></br>

                        <label><b>Description:</b></label><br></br>
                        <input type="text" name="description" value={updatedProduct.description} onChange={handleChange} /><br></br>
                    
                        <label><b>Image:</b></label><br></br>
                        <input type="text" name="image" value={updatedProduct.image} onChange={handleChange} /><br></br>


                        <button className="customer-edit-button" onClick={handleUpdate}>Save</button>
                    </div>
                ) : (
                    <div style={{ textAlign: "center" }}>
                        <div className="admin-card admin-user-details">
                             <img src={product.image} height="180px" width="140px"></img> 
                            <p><b>Id: </b>{product.productId}</p>
                            <p><b>Name: </b>{product.productName}</p>
                            <p><b>Category: </b>{product.category}</p>
                            <p><b>Price: </b>Rs.{product.price}</p>
                            <p><b>Description: </b>{product.description}</p>
                            <button className="product-button" onClick={handleEdit}>Edit Details</button>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};
export default UpdateProduct;