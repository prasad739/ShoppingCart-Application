import React, { useState, useEffect } from 'react';
import axios from 'axios';
import NavbarAdmin from './NavbarAdmin';
import { useNavigate } from 'react-router-dom';

function DisplayAllProducts() {
    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState(''); // State for search query
    const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const navigate=useNavigate();
    const token = localStorage.getItem('token');

    useEffect(() => {
        async function fetchProducts() {
            try {
                const response = await axios.get('http://localhost:9091/product/getAllProducts', {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                setProducts(response.data);
                setLoading(false);
            } catch (error) {
                console.error('Error fetching products:', error);
                setLoading(false);
            }
        }

        fetchProducts();
    }, [token]);

    const fetchProductsInPriceRange = async () => {
        try {
          const response = await axios.get(`http://localhost:9091/productsInBetweenRange/${minPrice}/${maxPrice}`);
          setProducts(response.data);
          setLoading(false);
        } catch (error) {
          console.error('Error fetching products within the price range:', error);
          setLoading(false);
        }
      };

    const handleUpdateProduct = (productId) => {

      navigate(`/updateProduct/${productId}`)
        
    };

    const handleDeleteProduct = async (productId) => {
        const shouldDelete = window.confirm('Are you sure you want to delete this product?');
        if (shouldDelete) {
            try {
                await axios.delete(`http://localhost:9091/product/deleteProductById/${productId}`, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                // Update the products list after deletion.
                setProducts(products.filter((product) => product.productId !== productId));
            } catch (error) {
                console.error('Error deleting product:', error);
            }
        }
    };

    useEffect(() => {
        fetchProductsInPriceRange();
      }, [minPrice, maxPrice]);
    
      const handleSearchChange = (event) => {
        setSearchQuery(event.target.value);
      };
    
      const handleMinPriceChange = (event) => {
        setMinPrice(event.target.value);
      };
    
      const handleMaxPriceChange = (event) => {
        setMaxPrice(event.target.value);
      };

      const filteredProducts = products.filter(product => {
        const productPrice = parseFloat(product.price);
        const minPriceValue = parseFloat(minPrice);
        const maxPriceValue = parseFloat(maxPrice);
    
        return (
          (!minPrice || productPrice >= minPriceValue) &&
          (!maxPrice || productPrice <= maxPriceValue)
        ) && product.productName.toLowerCase().includes(searchQuery.toLowerCase());
      });

    return (
        <div>
            <NavbarAdmin/>
            <h1 style={{textAlign:"center"}}>All Products</h1>
            <div className="search-container">
        <input
          type="text"
          placeholder="Search by product name.."
          value={searchQuery}
          onChange={handleSearchChange}
        />
        </div>
        
        <div className="search-container">
          <h4>Search By Price: </h4>
          <div className="min-price">
        <input
          type="number"
          placeholder="Enter Min Price.."
          value={minPrice}
          onChange={handleMinPriceChange}
        />
        </div>
        <div className="max-price">

        <input
          type="number"
          placeholder="Enter Max Price.."
          value={maxPrice}
          onChange={handleMaxPriceChange}
        />
        </div>
      </div>
            {loading ? <p>Loading products...</p> : (
                <div className="product-card-container">
                    {filteredProducts.map((product) => (
                        <div className="product-card" key={product.productId}>
                            <img src={product.image} alt={product.productName} />
                            <h3>{product.productName}</h3>
                            <p>Price: Rs.{product.price}</p>
                            <p>Description: {product.description}</p>
                            <button  className="product-button" onClick={() => handleUpdateProduct(product.productId)}>Update Product</button>
                            <button  className="product-button" onClick={() => handleDeleteProduct(product.productId)}>Delete Product</button>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}

export default DisplayAllProducts;

