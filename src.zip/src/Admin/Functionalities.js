import NavbarAdmin from "./NavbarAdmin";
import { Link } from "react-router-dom";
import Product from '../Images/Product.jpg';
import Customer2 from '../Images/Customer2.jpg';

import '../Styles/Functionalities.css'

function Functionalities() {
    return (
        <div>
            <NavbarAdmin />

            <div className="functionalities">
                <div className="product-card-container">
                    <Link to="/productFunctions">
                        <div className="product-card" >
                            <img src={Product} alt="Product Image" />
                            <h3>Product Functionalities</h3>
                        </div>
                    </Link>

                    <Link to="/customerFunctions">
                        <div className="product-card" >
                            <img src={Customer2} alt="Customer Image" />
                            <h3>Customer Functionalities</h3>
                        </div>
                    </Link>

                </div>
            </div>

        </div>





    );
}

export default Functionalities;