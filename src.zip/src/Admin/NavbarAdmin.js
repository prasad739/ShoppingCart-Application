import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {  FaUser } from 'react-icons/fa';
import '../Styles/NavbarCustomer.css';


function NavbarAdmin(){
    const [isDropdownOpen, setDropdownOpen] = useState(false);

  const toggleDropdown = () => {
    setDropdownOpen(!isDropdownOpen);
  };

  const closeDropdown = () => {
    setDropdownOpen(false);
  };
    return (
        <div>
      <div className="navbar">
        <div className="side-menu">
          <ul>
            <li><a href="/adminHome">Home</a></li>
            <li><a href="/about">About</a></li>
            <li><a href="/contact">Contact</a></li>
          </ul>
        </div>
        <div className="heading">
          <h1>Online Shopping Cart</h1>
        </div>
        <div className="icons">
          <div className="dropdown" onClick={toggleDropdown}>
            <FaUser className="icon" />
            {isDropdownOpen && (
              <div className="dropdown-content">
                <Link to="/adminProfile" onClick={closeDropdown}>View Profile</Link>
                <Link to="/functionalities" onClick={closeDropdown}>View Functionalities</Link>
                <Link to="/logout" onClick={closeDropdown}>Logout</Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}


export default NavbarAdmin;