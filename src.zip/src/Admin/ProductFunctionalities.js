import NavbarAdmin from "./NavbarAdmin";
import { Link } from "react-router-dom";
import '../Styles/Functionalities.css'


function ProductFunctionalities() {
  return (
    <div >
      <NavbarAdmin />
<div className="functionalities">
      <div className="product-card-container" style={{alignItems:"center",padding:"150px"}} >
        <Link to="/addProduct">
          <div className="product-card" >
            <h3>Add Product</h3>
          </div>
        </Link>
        <Link to="/viewAllProducts">
          <div className="product-card" >
            <h3>View All Products</h3>
          </div>
        </Link>
        <Link to="/displayProductsByCategories">
          <div className="product-card" >
            <h3>View All Products By Category</h3>
          </div>
        </Link>

      </div>
      </div>
    </div>
  );
}

export default ProductFunctionalities;