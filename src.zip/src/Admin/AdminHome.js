import Admin from '../Images/Admin.webp'
import '../Styles/AdminHome.css'
import NavbarAdmin from './NavbarAdmin';

function AdminHome() {
    return (
        <div>
            <NavbarAdmin />
            <div className='admin-home-container'>
                <div className="left-home" >
                    <img src={Admin} height="400px" />
                </div>
                <div className="right-home" style={{ textAlign: "center" }}>
                    <div style={{ marginTop: "130px" }}>
                        <p>
                            <b>Welcome to the Admin Dashboard of our Online Shoppping Cart application! </b><br></br>
                            This is your control center for managing all aspects of your online store. Monitor sales, track orders, update product listings, and stay on top of your inventory effortlessly. With our comprehensive set of tools and features, you can efficiently run your e-commerce business and provide exceptional service to your customers. If you have any questions or need assistance, feel free to explore our help and support section. We're here to help you make your online shopping experience a success.
                        </p>
                    </div>
                </div>

            </div>
        </div>
    );
}

export default AdminHome;