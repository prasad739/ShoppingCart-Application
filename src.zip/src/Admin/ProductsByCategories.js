import DisplayCategories from "../Components/DisplayCategories";
import NavbarAdmin from "./NavbarAdmin";

function ProductsByCategories(){
    return (
        <div>
            <NavbarAdmin/>
            <DisplayCategories/>

        </div>
    );
}

export default ProductsByCategories;