import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './Components/Home';
import Login from './Components/Login';
import Registration from './Components/Registration';
import CustomerHome from './Customer/CustomerHome';
import DisplayProduct from './Components/DisplayProduct';
import DisplayWishlist from './Customer/DisplayWishlist';
import DisplayCart from './Customer/DisplayCart';
import About from './Components/About';
import Contact from './Components/Contact';
import Payment from './Components/Payment';
import CustomerProfile from './Customer/CustomerProfile';
import AdminHome from './Admin/AdminHome';
import Functionalities from './Admin/Functionalities';
import ProductFunctionalities from './Admin/ProductFunctionalities';
import AddProduct from './Admin/AddProduct';
import DisplayAllProducts from './Admin/DisplayAllProducts';
import ProductsByCategories from './Admin/ProductsByCategories';
import CustomerFunctionalities from './Admin/CustomerFunctionalities';
import AdminProfile from './Admin/AdminProfile';
import ViewHistory from './Customer/ViewHistory';
import Logout from './Components/Logout';
import UpdateProduct from './Admin/UpdateProduct';
import './App.css';


function App() {
  return (
    <div className="App">
      <Router>
        <Routes>
          <Route path="/" element={<Home />}></Route>
          <Route path="/login" element={<Login />}></Route>
          <Route path="/register" element={<Registration />}></Route>
          <Route path="/customerhome" element={<CustomerHome />} />
          <Route path="/products/:category" element={<DisplayProduct />} />
          <Route path="/wishlist" element={<DisplayWishlist />} />
          <Route path="/cart" element={<DisplayCart />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/payment" element={<Payment />} />
          <Route path="/customerProfile" element={<CustomerProfile />} />
          <Route path="/adminHome" element={<AdminHome />} />
          <Route path="/functionalities" element={<Functionalities />} />
          <Route path="/productFunctions" element={<ProductFunctionalities />} />
          <Route path="/addProduct" element={<AddProduct />} />
          <Route path="/viewAllProducts" element={<DisplayAllProducts />} />
          <Route path="/displayProductsByCategories" element={<ProductsByCategories />} />
          <Route path="/customerFunctions" element={<CustomerFunctionalities />} />
          <Route path="/adminProfile" element={<AdminProfile />} />
          <Route path="/purchasedProducts" element={<ViewHistory />} />
          <Route path="/updateProduct/:productId" element={<UpdateProduct />} />
          <Route path="/logout" element={<Logout />} />
        </Routes>
      </Router>
    </div>

  );
}

export default App;