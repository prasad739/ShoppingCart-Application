package com.shoppingcart;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.context.request.WebRequest;

import com.shoppingcart.controller.WishlistController;
import com.shoppingcart.dto.CartDto;
import com.shoppingcart.dto.Items;
import com.shoppingcart.dto.ProductDto;
import com.shoppingcart.dto.RegistrationDto;
import com.shoppingcart.dto.WishlistDto;
import com.shoppingcart.entity.Wishlist;
import com.shoppingcart.exception.AlreadyInWishlistException;
import com.shoppingcart.exception.CustomerNotFoundException;
import com.shoppingcart.exception.EmptyCartException;
import com.shoppingcart.exception.ExceptionResponse;
import com.shoppingcart.exception.GlobalExceptionHandler;
import com.shoppingcart.exception.ProductDoesNotExistException;
import com.shoppingcart.exception.WishlistEmptyException;
import com.shoppingcart.service.WishlistServiceImpl;

public class WishlistTest{

    GlobalExceptionHandler globalExceptionHandler;
    WebRequest webRequest;
    Items items;
    ProductDto product;

    WishlistController wishlistController;
    WishlistServiceImpl wishlistService;
    MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        globalExceptionHandler = new GlobalExceptionHandler();
        webRequest = mock(WebRequest.class);

        items = new Items();
        product = new ProductDto("123", "Test Product", "Electronics", 100.0f, "Description", null, "image.jpg");

    }

    @Test
    public void testWishlistGettersAndSetters() {
        Wishlist wishlist = new Wishlist();
        wishlist.setWishlistId("testWishlistId");
        wishlist.setCustomerId("testCustomerId");
        List<ProductDto> products = new ArrayList<>();
        wishlist.setProducts(products);

        assertEquals("testWishlistId", wishlist.getWishlistId());
        assertEquals("testCustomerId", wishlist.getCustomerId());
        assertEquals(products, wishlist.getProducts());
    }

    @Test
    public void testCartDtoGettersAndSetters() {
        CartDto cartDto = new CartDto();
        cartDto.setCartId("testCartId");
        cartDto.setCustomerId("testCustomerId");
        List<Items> itemList = new ArrayList<>();
        cartDto.setItemList(itemList);

        assertEquals("testCartId", cartDto.getCartId());
        assertEquals("testCustomerId", cartDto.getCustomerId());
        assertEquals(itemList, cartDto.getItemList());
    }

    @Test
    public void testItemsGettersAndSetters() {
        ProductDto productDto = new ProductDto();
        productDto.setProductId("testProductId");
        Items items = new Items(productDto, 5);

        assertEquals(productDto, items.getProduct());
        assertEquals(5, items.getQuantity());
    }

    @Test
    public void testProductDtoGettersAndSetters() {
        ProductDto productDto = new ProductDto();
        productDto.setProductId("testProductId");
        productDto.setProductName("testProductName");
        productDto.setCategory("testCategory");
        productDto.setPrice(100.0f);
        productDto.setDescription("testDescription");
        productDto.setImage("testImage");

        assertEquals("testProductId", productDto.getProductId());
        assertEquals("testProductName", productDto.getProductName());
        assertEquals("testCategory", productDto.getCategory());
        assertEquals(100.0f, productDto.getPrice(), 0.01);
        assertEquals("testDescription", productDto.getDescription());
        assertEquals("testImage", productDto.getImage());
    }

    @Test
    public void testWishlistConstructor() {
        List<ProductDto> products = new ArrayList<>();
        Wishlist wishlist = new Wishlist("wishlistId", "customerId", products);

        assertEquals("wishlistId", wishlist.getWishlistId());
        assertEquals("customerId", wishlist.getCustomerId());
        assertEquals(products, wishlist.getProducts());
    }

    @Test
    public void testCartDtoConstructor() {
        List<Items> itemList = new ArrayList<>();
        CartDto cartDto = new CartDto("cartId", "customerId", itemList);

        assertEquals("cartId", cartDto.getCartId());
        assertEquals("customerId", cartDto.getCustomerId());
        assertEquals(itemList, cartDto.getItemList());
    }

    @Test
    public void testItemsConstructor() {
        ProductDto product = new ProductDto("productId", "productName", "category", 100.0f, "description", Map.of(),
                "image");
        Items items = new Items(product, 5);

        assertEquals(product, items.getProduct());
        assertEquals(5, items.getQuantity());
    }

    @Test
    public void testProductDtoConstructor() {
        ProductDto productDto = new ProductDto("productId", "productName", "category", 100.0f, "description", Map.of(),
                "image");

        assertEquals("productId", productDto.getProductId());
        assertEquals("productName", productDto.getProductName());
        assertEquals("category", productDto.getCategory());
        assertEquals(100.0f, productDto.getPrice(), 0.01);
        assertEquals("description", productDto.getDescription());
        assertEquals("image", productDto.getImage());
    }

    @Test
    public void testWishlistDtoConstructor() {
        List<ProductDto> products = new ArrayList<>();
        WishlistDto wishlistDto = new WishlistDto("wishlistId", "customerId", products);

        assertEquals("wishlistId", wishlistDto.getWishlistId());
        assertEquals("customerId", wishlistDto.getCustomerId());
        assertEquals(products, wishlistDto.getProducts());
    }

    @Test
    public void testRegistrationDtoConstructor() {
        RegistrationDto registrationDto = new RegistrationDto("testRegistrationId", "TestName", "TestGender",
                "test@example.com", "password", "1234567890", "UserRole");

        assertEquals("testRegistrationId", registrationDto.getRegistrationId());
        assertEquals("TestName", registrationDto.getName());
        assertEquals("TestGender", registrationDto.getGender());
        assertEquals("test@example.com", registrationDto.getEmail());
        assertEquals("password", registrationDto.getPassword());
        assertEquals("1234567890", registrationDto.getMobileNumber());
        assertEquals("UserRole", registrationDto.getRole());
    }

    @Test
    public void testRegistrationDtoGettersAndSetters() {
        RegistrationDto registrationDto = new RegistrationDto();

        registrationDto.setRegistrationId("testRegistrationId");
        registrationDto.setName("TestName");
        registrationDto.setGender("TestGender");
        registrationDto.setEmail("test@example.com");
        registrationDto.setPassword("password");
        registrationDto.setMobileNumber("1234567890");
        registrationDto.setRole("UserRole");

        assertEquals("testRegistrationId", registrationDto.getRegistrationId());
        assertEquals("TestName", registrationDto.getName());
        assertEquals("TestGender", registrationDto.getGender());
        assertEquals("test@example.com", registrationDto.getEmail());
        assertEquals("password", registrationDto.getPassword());
        assertEquals("1234567890", registrationDto.getMobileNumber());
        assertEquals("UserRole", registrationDto.getRole());
    }

    @Test
    public void testSpecificationGetter() {
        ProductDto productDto = new ProductDto();
        Map<String, String> specification = new HashMap<>();
        specification.put("key1", "value1");
        specification.put("key2", "value2");
        productDto.setSpecification(specification);

        Map<String, String> retrievedSpecification = productDto.getSpecification();

        assertEquals(specification, retrievedSpecification);
    }

    @Test
    public void testSpecificationSetter() {
        ProductDto productDto = new ProductDto();
        Map<String, String> specification = new HashMap<>();
        specification.put("key1", "value1");
        specification.put("key2", "value2");

        productDto.setSpecification(specification);

        Map<String, String> retrievedSpecification = productDto.getSpecification();

        assertEquals(specification, retrievedSpecification);
    }

    @Test
    public void testSetWishlistId() {
        WishlistDto wishlistDto = new WishlistDto();
        wishlistDto.setWishlistId("testWishlistId");

        assertEquals("testWishlistId", wishlistDto.getWishlistId());
    }

    @Test
    public void testSetCustomerId() {
        WishlistDto wishlistDto = new WishlistDto();
        wishlistDto.setCustomerId("testCustomerId");

        assertEquals("testCustomerId", wishlistDto.getCustomerId());
    }

    @Test
    public void testSetProducts() {
        WishlistDto wishlistDto = new WishlistDto();
        List<ProductDto> products = new ArrayList<>();
        products.add(new ProductDto("productId1", "productName1", "category1", 100.0f, "description1", null, "image1"));
        products.add(new ProductDto("productId2", "productName2", "category2", 200.0f, "description2", null, "image2"));

        wishlistDto.setProducts(products);

        List<ProductDto> retrievedProducts = wishlistDto.getProducts();

        assertEquals(products, retrievedProducts);
    }

    @Test
    void handleAllException() {
        Exception exception = new Exception("Test Exception");
        ResponseEntity<ExceptionResponse> response = globalExceptionHandler.handleAllException(exception, webRequest);

        assertEquals(response.getStatusCode(), HttpStatus.INTERNAL_SERVER_ERROR);

        ExceptionResponse exceptionResponse = response.getBody();
        assertEquals(exceptionResponse.getHttpCodeMessage(), "Internal Server Error");
        assertEquals(exceptionResponse.getMessage(), "Test Exception");
    }

    @Test
    void handleCustomerNotFoundException() {
        CustomerNotFoundException exception = new CustomerNotFoundException("Customer not found");
        ResponseEntity<ExceptionResponse> response = globalExceptionHandler.handleCustomerNotFoundException(exception,
                webRequest);

        assertEquals(response.getStatusCode(), HttpStatus.NOT_FOUND);

        ExceptionResponse exceptionResponse = response.getBody();
        assertEquals(exceptionResponse.getHttpCodeMessage(), "Not Found");
        assertEquals(exceptionResponse.getMessage(), "Customer not found");
    }

    @Test
    void handleEmptyCartException() {
        EmptyCartException exception = new EmptyCartException("Empty cart");
        ResponseEntity<ExceptionResponse> response = globalExceptionHandler.handleEmptyCartException(exception,
                webRequest);

        assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);

        ExceptionResponse exceptionResponse = response.getBody();
        assertEquals(exceptionResponse.getHttpCodeMessage(), "Bad Request");
        assertEquals(exceptionResponse.getMessage(), "Empty cart");
    }

    @Test
    void handleAlreadyInWishlistException() {
        AlreadyInWishlistException exception = new AlreadyInWishlistException("Product already in wishlist");
        ResponseEntity<ExceptionResponse> response = globalExceptionHandler.handleAlreadyInWishlistException(exception,
                webRequest);

        assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);

        ExceptionResponse exceptionResponse = response.getBody();
        assertEquals(exceptionResponse.getHttpCodeMessage(), "Bad Request");
        assertEquals(exceptionResponse.getMessage(), "Product already in wishlist");
    }

    @Test
    void handleProductDoesNotExistException() {
        ProductDoesNotExistException exception = new ProductDoesNotExistException("Product not found");
        ResponseEntity<ExceptionResponse> response = globalExceptionHandler
                .handleProductDoesNotExistException(exception, webRequest);

        assertEquals(response.getStatusCode(), HttpStatus.NOT_FOUND);

        ExceptionResponse exceptionResponse = response.getBody();
        assertEquals(exceptionResponse.getHttpCodeMessage(), "Not Found");
        assertEquals(exceptionResponse.getMessage(), "Product not found");
    }

    @Test
    void testHandleMethodArgumentNotValid() {
        GlobalExceptionHandler handler = new GlobalExceptionHandler(); // Instantiate your exception handler

        // Create a mock MethodArgumentNotValidException and associated objects
        MethodArgumentNotValidException ex = mock(MethodArgumentNotValidException.class);
        BindingResult bindingResult = mock(BindingResult.class);
        FieldError fieldError1 = new FieldError("objectName", "field1", "Error message 1");
        FieldError fieldError2 = new FieldError("objectName", "field2", "Error message 2");

        when(ex.getBindingResult()).thenReturn(bindingResult);
        when(bindingResult.getFieldErrors()).thenReturn(List.of(fieldError1, fieldError2));

        WebRequest request = mock(WebRequest.class);

        // Call the handleMethodArgumentNotValid method
        ResponseEntity<Object> responseEntity = handler.handleMethodArgumentNotValid(ex, null, null, request);

        // Verify the response
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());

        // Verify the response body (ExceptionResponse)
        ExceptionResponse exceptionResponse = (ExceptionResponse) responseEntity.getBody();
        assertEquals("Validation fails", exceptionResponse.getMessage());
        assertEquals("Bad Request", exceptionResponse.getHttpCodeMessage());

        // Verify the details
        String expectedDetails = "field1: Error message 1. field2: Error message 2. ";
        assertEquals(expectedDetails, exceptionResponse.getDetails());

    }

    @Test
    void testSetProduct() {
        items.setProduct(product);

        assertNotNull(items.getProduct());
        assertEquals(product, items.getProduct());
    }

    @Test
    void testSetQuantity() {
        int quantity = 5;
        items.setQuantity(quantity);

        assertEquals(quantity, items.getQuantity());
    }

    @Test
    public void testExceptionResponseConstructor() {
        LocalDate timestamp = LocalDate.now();
        String message = "Test Message";
        String details = "Test Details";
        String httpCodeMessage = "HTTP 404 Not Found";

        ExceptionResponse exceptionResponse = new ExceptionResponse(timestamp, message, details, httpCodeMessage);

        assertEquals(timestamp, exceptionResponse.getTimestamp());
        assertEquals(message, exceptionResponse.getMessage());
        assertEquals(details, exceptionResponse.getDetails());
        assertEquals(httpCodeMessage, exceptionResponse.getHttpCodeMessage());
    }

    @Test
    public void testWishlistEmptyException() {
        // Define a custom message
        String customMessage = "Custom error message";

        // Create an instance of WishlistEmptyException with the custom message
        WishlistEmptyException exception = new WishlistEmptyException(customMessage);

        // Verify that the exception message matches the custom message
        assertEquals(customMessage, exception.getMessage());
    }

}