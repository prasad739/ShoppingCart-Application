package com.shoppingcart.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.shoppingcart.dto.CartDto;
import com.shoppingcart.dto.ProductDto;
import com.shoppingcart.dto.WishlistDto;
import com.shoppingcart.service.WishlistServiceImpl;

@RestController
@RequestMapping("/wishlist")
@CrossOrigin("*")
public class WishlistController {
	
//	arpitha.sinha@blk
	private static final Logger logger=LogManager.getLogger();
	
	@Autowired
	WishlistServiceImpl wishlistImpl;
	
	@PostMapping("/addToWishlist/{customerId}/{productId}")
	public ResponseEntity<WishlistDto> addToWishlist(@PathVariable String customerId,@PathVariable String productId){
		logger.info("Sending request to add product to a wishlist!");
		WishlistDto wishList = wishlistImpl.addToWishlist(customerId, productId);
		logger.info("Product added to wishlist successfully!");
		return new ResponseEntity<>(wishList,HttpStatus.CREATED);
	}
	
	@PutMapping("/deleteFromWishlist/{customerId}/{productId}")
	public ResponseEntity<WishlistDto> deleteFromWishlist(@PathVariable String customerId,@PathVariable String productId){
		logger.info("Sending request to delete product to a wishlist!");
		WishlistDto wishList = wishlistImpl.deleteFromWishlist(customerId, productId);
		logger.info("Product deleted from wishlist successfully!");
		return new ResponseEntity<>(wishList,HttpStatus.OK);
	}
	
	
	@GetMapping("/getWishlistProducts/{customerId}")
	public ResponseEntity<List<ProductDto>> getWishlistProducts(@PathVariable String customerId){
		logger.info("Sending request to fetch product list of a customer!");
		List<ProductDto> wishlistProducts = wishlistImpl.getWishlistProducts(customerId);
		logger.info("Product added to wishlist successfully!");
		return new ResponseEntity<>(wishlistProducts,HttpStatus.OK);
	}
	
	@PostMapping("/addToCart")
	public ResponseEntity<String> addToCart(@RequestParam(name="cartId") String cartId,@RequestParam(name = "customerId") String customerId,@RequestParam(name = "productId") String productId,@RequestParam(name ="quantity") int quantity) {
		logger.info("Sending request to add a product to a cart");
		String str=wishlistImpl.addToCart(cartId,customerId, productId, quantity);
		logger.info("Product added to cart successfully!");
		
		return new ResponseEntity<>(str,HttpStatus.CREATED);
	}
}
