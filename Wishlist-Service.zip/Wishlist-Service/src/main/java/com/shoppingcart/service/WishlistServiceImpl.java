package com.shoppingcart.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shoppingcart.dto.ProductDto;
import com.shoppingcart.dto.RegistrationDto;
import com.shoppingcart.dto.WishlistDto;
import com.shoppingcart.entity.Wishlist;
import com.shoppingcart.exception.AlreadyInWishlistException;
import com.shoppingcart.exception.CustomerNotFoundException;
import com.shoppingcart.exception.ProductDoesNotExistException;
import com.shoppingcart.exception.WishlistEmptyException;
import com.shoppingcart.repository.IWishlistRepository;
import com.shoppingcart.service.proxy.ICustomer_proxy;
import com.shoppingcart.service.proxy.IProduct_proxy;
import com.shoppingcart.service.proxy.IServiceProxy_cart;

@Service
public class WishlistServiceImpl implements IWishlistService {

	@Autowired
	IWishlistRepository wishlistRepo;

	@Autowired
	IProduct_proxy pp;

	@Autowired
	ICustomer_proxy cp;

	@Autowired
	IServiceProxy_cart scp;

	@Autowired
	ModelMapper modellMapper;

	public WishlistDto addToWishlist(String customerId, String productId) {

		RegistrationDto customer = cp.getCustomerById(customerId).getBody();
		if (customer == null) {
			throw new CustomerNotFoundException("Customer with id " + customerId + " not found!");
		}

		ProductDto product = pp.getProductById(productId).getBody();
		if (product == null) {
			throw new ProductDoesNotExistException("Product with id " + productId + " not found!");
		}

		Optional<Wishlist> wishlist = wishlistRepo.findByCustomerId(customerId);

		if (wishlist.isPresent()) {
			for (ProductDto pd : wishlist.get().getProducts()) {
				if (pd.getProductId().equals(productId)) {
					throw new AlreadyInWishlistException("Product already in wishlist!");
				}
			}

			Wishlist wishlist_customer = wishlist.get();
			List<ProductDto> products = wishlist_customer.getProducts();
			products.add(product);

			wishlistRepo.save(wishlist_customer);
			return modellMapper.map(wishlist_customer, WishlistDto.class);

		}

		List<ProductDto> list = new ArrayList<>();
		Wishlist wishlistNew = new Wishlist();
		wishlistNew.setWishlistId(customerId);
		wishlistNew.setCustomerId(customerId);
		list.add(product);
		wishlistNew.setProducts(list);

		wishlistRepo.save(wishlistNew);

		return modellMapper.map(wishlistNew, WishlistDto.class);
	}

	public WishlistDto deleteFromWishlist(String customerId, String productId) {

		RegistrationDto customer = cp.getCustomerById(customerId).getBody();
		if (customer == null) {
			throw new CustomerNotFoundException("Customer with id " + customerId + " not found!");
		}

		ProductDto product = pp.getProductById(productId).getBody();
		if (product == null) {
			throw new ProductDoesNotExistException("Product with id " + productId + " not found!");
		}

		Optional<Wishlist> wishlist = wishlistRepo.findByCustomerId(customerId);
		if (wishlist.isEmpty()) {
			throw new WishlistEmptyException("There is no wishlist for the given cutomer id: " + customerId);
		}
		List<ProductDto> products = wishlist.get().getProducts();
		ProductDto productToBeRemoved = null;
		for (ProductDto p : products) {
			if (p.getProductId().equals(productId)) {
				productToBeRemoved = p;
				break;
			}
		}

		if (productToBeRemoved == null) {
			throw new ProductDoesNotExistException(
					"There is no product with product id: " + productId + " in the wishlist");
		}

		products.remove(productToBeRemoved);
		wishlist.get().setProducts(products);
		wishlistRepo.save(wishlist.get());
		return modellMapper.map(wishlist.get(), WishlistDto.class);
	}

	public String addToCart(String cartId, String customerId, String productId, int quantity) {
		
		RegistrationDto customer = cp.getCustomerById(customerId).getBody();
		if (customer == null) {
			throw new CustomerNotFoundException("Customer with id " + customerId + " not found!");
		}

		ProductDto product = pp.getProductById(productId).getBody();
		if (product == null) {
			throw new ProductDoesNotExistException("Product with id " + productId + " not found!");
		}
		
		Optional<Wishlist> customerWishlist = wishlistRepo.findByCustomerId(customerId);
		if(customerWishlist.isEmpty()) {
			throw new WishlistEmptyException("There is no wishlist for the given cutomer id: " + customerId);
		}
		List<ProductDto> products = customerWishlist.get().getProducts();
		ProductDto productDto=null;
		for(ProductDto p:products) {
			if(productId.equals(p.getProductId())) {
				productDto=p;
				break;
			}
		}
		
		if(productDto==null) {
			throw new ProductDoesNotExistException(
					"There is no product with product id: " + productId + " in the wishlist");
		}
		
		
		scp.addToCart(cartId, customerId, productId, quantity);
		products.remove(productDto);
		customerWishlist.get().setProducts(products);
		wishlistRepo.save(customerWishlist.get());
		return "Added to cart successfully!";
	}

	public List<ProductDto> getWishlistProducts(String customerId) {

		RegistrationDto customer = cp.getCustomerById(customerId).getBody();
		if (customer == null) {
			throw new CustomerNotFoundException("Customer with id " + customerId + " not found!");
		}

		Optional<Wishlist> wishlist = wishlistRepo.findByCustomerId(customerId);

		if (wishlist.isEmpty()) {
			throw new WishlistEmptyException("Your wishlist is empty!");
		}

		return wishlist.get().getProducts();
	}

}
