package com.shoppingcart.service;

import java.util.List;

import com.shoppingcart.dto.ProductDto;
import com.shoppingcart.dto.WishlistDto;

public interface IWishlistService {
	
	WishlistDto addToWishlist(String customerId, String productId);
	
	WishlistDto deleteFromWishlist(String customerId, String productId);
	
	String addToCart(String cartId, String customerId, String productId, int quantity);
	
	List<ProductDto> getWishlistProducts(String customerId);

}
