package com.shoppingcart.service.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.shoppingcart.dto.RegistrationDto;

@FeignClient(url="http://localhost:9093/customer",name="registry-service")
public interface ICustomer_proxy {
	
	@GetMapping("/getCustomerById/{registrationId}")
	public ResponseEntity<RegistrationDto> getCustomerById(@PathVariable String registrationId);

}
