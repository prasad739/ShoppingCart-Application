package com.shoppingcart.service.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.shoppingcart.dto.ProductDto;

@FeignClient(url="http://localhost:9091/product",name="product-service")
public interface IProduct_proxy {
	
	@GetMapping("/getProductById/{productId}")
	public ResponseEntity<ProductDto> getProductById(@PathVariable String productId);

}
