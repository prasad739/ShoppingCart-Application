package com.shoppingcart.dto;

import java.util.List;

public class WishlistDto {

	private String wishlistId;
	private String customerId;

	private List<ProductDto> products;

	public WishlistDto() {
		super();
	}

	public WishlistDto(String wishlistId, String customerId, List<ProductDto> products) {
		super();
		this.wishlistId = wishlistId;
		this.customerId = customerId;
		this.products = products;
	}

	public String getWishlistId() {
		return wishlistId;
	}

	public void setWishlistId(String wishlistId) {
		this.wishlistId = wishlistId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public List<ProductDto> getProducts() {
		return products;
	}

	public void setProducts(List<ProductDto> products) {
		this.products = products;
	}

}
