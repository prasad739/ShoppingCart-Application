package com.shoppingcart.entity;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.shoppingcart.dto.ProductDto;

@Document
public class Wishlist {
	
	@Id
	private String wishlistId;
	private String customerId;
	
	private List<ProductDto> products;

	public Wishlist() {
		super();
	}

	public Wishlist(String wishlistId, String customerId, List<ProductDto> products) {
		super();
		this.wishlistId = wishlistId;
		this.customerId = customerId;
		this.products = products;
	}

	public String getWishlistId() {
		return wishlistId;
	}

	public void setWishlistId(String wishlistId) {
		this.wishlistId = wishlistId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public List<ProductDto> getProducts() {
		return products;
	}

	public void setProducts(List<ProductDto> products) {
		this.products = products;
	}

}
