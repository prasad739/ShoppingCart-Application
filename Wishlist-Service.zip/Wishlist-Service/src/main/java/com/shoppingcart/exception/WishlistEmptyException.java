package com.shoppingcart.exception;

public class WishlistEmptyException extends RuntimeException {

	public WishlistEmptyException(String msg) {
		super(msg);
	}

}
