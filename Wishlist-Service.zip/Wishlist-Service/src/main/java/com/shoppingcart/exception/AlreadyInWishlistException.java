package com.shoppingcart.exception;

public class AlreadyInWishlistException extends RuntimeException {
	
	public AlreadyInWishlistException(String msg) {
		super(msg);
	}

}
